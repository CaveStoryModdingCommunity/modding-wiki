#pragma once
#ifndef PARTICLE_H
#define PARTICLE_H

class Particle
{
   public:
//constructors/destructors
      Particle();
//vars
      char inUse;
      char scriptState;
      int xPos;
      int yPos;
      int xVel;
      int yVel;
      short int scriptTimer;
      char sheetX;
      char sheetY;
      char frameSize;
//functions
      void setParticle(int size, int x, int y, int xVel, int yVel, int sheetX, int sheetY, int Behaviour);
};
//functions
      void doParticles();
      //CheckTile();
      void particleInit(int numParticles);
      bool particleCreate(int size, int x, int y, int xVel, int yVel, int sheetX, int sheetY, int Behaviour);
      int countParticles();
      void drawParticles();
      void updateParticles();
#endif
