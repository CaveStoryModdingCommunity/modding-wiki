#pragma once
#ifndef TIMERS_H
#define TIMERS_H
// timers.h
// I don't know who wrote this but thank you random guy

volatile int timer_1;
volatile int timer_2;
volatile int timer_3;
volatile int timer_4;
volatile int timer_5;
volatile int timer_6;

void timer_f1()
{
    ++timer_1;
}
END_OF_FUNCTION  (timer_f1)

void timer_f2()
{
    ++timer_2;
}
END_OF_FUNCTION  (timer_f2)

void timer_f3()
{
    ++timer_3;
}
END_OF_FUNCTION  (timer_f3)

void timer_f4()
{
    ++timer_4;
}
END_OF_FUNCTION  (timer_f4)

void timer_f5()
{
    ++timer_5;
}
END_OF_FUNCTION  (timer_f5)

void timer_f6()
{
    ++timer_6;
}
END_OF_FUNCTION  (timer_f6)

LOCK_VARIABLE(timer_1);
LOCK_VARIABLE(timer_2);
LOCK_VARIABLE(timer_4);
LOCK_VARIABLE(timer_6);
LOCK_FUNCTION(timer_f1);
LOCK_FUNCTION(timer_f2);
LOCK_FUNCTION(timer_f3);
LOCK_FUNCTION(timer_f4);
LOCK_FUNCTION(timer_f5);
LOCK_FUNCTION(timer_f6);

void install_timers()
{
    install_int_ex(timer_f1,BPS_TO_TIMER(1));      //once per second
    install_int_ex(timer_f2,BPS_TO_TIMER(16));     //16 times p/s
    install_int_ex(timer_f3,BPS_TO_TIMER(40));     //and so on
    install_int_ex(timer_f4,BPS_TO_TIMER(50));
    install_int_ex(timer_f5,BPS_TO_TIMER(100));
    install_int_ex(timer_f6,BPS_TO_TIMER(400));
}

void set_timers()                //initialize timers to zero before using them
{
    timer_1 = 0;
    timer_2 = 0;
    timer_3 = 0;
    timer_4 = 0;
    timer_5 = 0;
    timer_6 = 0;
}

void timerMain()
{
    install_timers();
    set_timers();
}
#endif
