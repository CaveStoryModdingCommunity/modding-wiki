#pragma once
#ifndef MUSIC_H
#define MUSIC_H
int musicInit(unsigned int newVol); //Prepares the music engine stuff
void playSong(int n); //Play the song
void resumeSong(); //resume last playback
void stopSong(); //Stop playing the song
void musicClose(); //Release the pxtone system
void musicError(int x, int y); //Display the Error Message
void setSong(int SongNum); //Set song #
int getSong(); //Returns song number
int getMusicVol();
void setMusicVol(int newVol);
void toggleMusic();
int isMusicMuted();
#endif
