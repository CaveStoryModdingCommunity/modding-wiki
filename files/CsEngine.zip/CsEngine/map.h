#pragma once
#ifndef MAP_H
#define MAP_H
void loadMapdata();
void saveMapData();
void loadMap(unsigned int mapNum);
void saveMap();
void drawTiles(int layer);
void drawMNA();
void updateTileAnim();
int getMapNum(); //return current map number
int getTile(int x, int y, unsigned int layer);
int getType(int tileNum);
int getType(int x, int y);
void softQuake(int duration);
void hardQuake(int duration);
void setMapNameTimer(int time);
void setTile(unsigned char tile, int x, int y, unsigned int layer);

#ifdef EDITOR_MODE
void drawTileTypes();
void drawTilesetTypes();
void setType(unsigned char tileNum, unsigned char tileType);
unsigned char *copyLayer(int layer);
char *getMapFilename(int mapNum);
#endif

typedef struct {
    char tileset[16];
    char filename[16];
    char scrollType;
    char bgName[16];
    char npc1[16];
    char npc2[16];
    char bossNum;
    char mapName[34];
} MapData;
#endif
