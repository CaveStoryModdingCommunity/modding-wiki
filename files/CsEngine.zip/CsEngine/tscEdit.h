#pragma once

void tscEditLoop();
void doTscGuiLogic();
