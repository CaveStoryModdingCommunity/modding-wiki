#pragma once
#ifndef TSC_H
#define TSC_H

#include <vector>

void renderTextbox();
void renderInvoFrame();
void renderFade();
void renderImgOverlay();

void fadeLogic();

void fillFlags(unsigned char *flagData);
void clearFlags();

int checkFlag(unsigned int flagNum);
void setFlag(unsigned int flagNum);
void removeFlag(unsigned int flagNum);

void runEvent(int tscNum);
void gotoEvent(int eventNum);
int scriptParser();

void loadGlobalTsc();
void loadScript(const char *filepath);

class TscCommand
{
public:
    int command;
    char *string;
    int* parameters;

    TscCommand(unsigned char *data, int maxLen, int &offset);
    TscCommand(const TscCommand &other);
    TscCommand& operator=(const TscCommand &other);
};

class ScriptEvent
{
public:
    int eventNum;
    std::vector<TscCommand> commandList;

    ScriptEvent();
    ScriptEvent(unsigned char *data, int maxLen, int &offset);
};

#define TSC_NO 0
#define TSC_AE_PLUS 1
#define TSC_AM_PLUS 2
#define TSC_AM_MINUS 3
#define TSC_AMJ 4
#define TSC_ANP 5
#define TSC_BOA 6
#define TSC_BSL 7
#define TSC_CAT 8
#define TSC_CIL 9
#define TSC_CLO 10
#define TSC_CLR 11
#define TSC_CMP 12
#define TSC_CMU 13
#define TSC_CNP 14
#define TSC_CPS 15
#define TSC_CRE 16
#define TSC_CSS 17
#define TSC_DIE 18
#define TSC_DNA 19
#define TSC_DNP 20
#define TSC_ECJ 21
#define TSC_END 22
#define TSC_EQ_PLUS 23
#define TSC_EQ_MINUS 24
#define TSC_ESC 25
#define TSC_EVE 26
#define TSC_FAC 27
#define TSC_FAI 28
#define TSC_FAO 29
#define TSC_FL_PLUS 30
#define TSC_FL_MINUS 31
#define TSC_FLA 32
#define TSC_FLJ 33
#define TSC_FMU 34
#define TSC_FOB 35
#define TSC_FOM 36
#define TSC_FON 37
#define TSC_FRE 38
#define TSC_GIT 39
#define TSC_HMC 40
#define TSC_IMG 41
#define TSC_INI 42
#define TSC_INP 43
#define TSC_IT_PLUS 44
#define TSC_IT_MINUS 45
#define TSC_ITJ 46
#define TSC_KEY 47
#define TSC_LDP 48
#define TSC_LIV 49
#define TSC_LI_PLUS 50
#define TSC_ML_PLUS 51
#define TSC_MLP 52
#define TSC_MM0 53
#define TSC_MNA 54
#define TSC_MNP 55
#define TSC_MOV 56
#define TSC_MPJ 57
#define TSC_MP_PLUS 58
#define TSC_MS2 59
#define TSC_MS3 60
#define TSC_MSG 61
#define TSC_MYB 62
#define TSC_MYD 63
#define TSC_NCJ 64
#define TSC_NOD 65
#define TSC_NUM 66
#define TSC_PRI 67
#define TSC_PS_PLUS 68
#define TSC_QUA 69
#define TSC_RMU 70
#define TSC_SAT 71
#define TSC_SIL 72
#define TSC_SK_PLUS 73
#define TSC_SK_MINUS 74
#define TSC_SKJ 75
#define TSC_SLP 76
#define TSC_SMC 77
#define TSC_SMP 78
#define TSC_SNP 79
#define TSC_SOU 80
#define TSC_SPS 81
#define TSC_SSS 82
#define TSC_STC 83
#define TSC_SVP 84
#define TSC_TAM 85
#define TSC_TRA 86
#define TSC_TUR 87
#define TSC_UNI 88
#define TSC_UNJ 89
#define TSC_VAR 90
#define TSC_VAJ 91
#define TSC_VAO 92
#define TSC_VAZ 93
#define TSC_RND 94
#define TSC_WAI 95
#define TSC_WAS 96
#define TSC_YNJ 97
#define TSC_ZAM 98
#define TSC_CTB 99
#define TSC_CIN 100
#define TSC_STR 101

#endif
