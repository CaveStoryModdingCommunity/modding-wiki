
#include "defines.h"
#include "numobj.h"
#include "graphics.h"

#include <list>
using namespace std;

list<NumberObject> numList;

NumberObject::NumberObject()
{

}

NumberObject::NumberObject(int *x, int *y, int val)
{
    xBase = x;
    yBase = y;
    xPos = 0;
    yPos = 0;
    gfxNum = BMP_TEXTBOX;
    frameRect.left = 0;
    frameRect.up = 0;
    frameRect.right = 0;
    frameRect.down = 0;
    num = val;
    timer = 0;
}

void NumberObject::draw(int digits)
{
    int rectSub = 0;
    if (timer >= 72)
        rectSub = (72 - timer)*2;
    Rect plusRect = {64, 96, 80, 112};
    Rect numRect;
    int lNum;
    char isNeg;
    if (num < 0) {
        plusRect.left += 16;
        plusRect.right += 16;
        lNum = -num;
        isNeg = 1;
    } else {
        lNum = num;
        isNeg = 0;
    }
    //draw plus or minus
    plusRect.down += rectSub;
    cameraBlit(BMP_TEXTBOX, plusRect, *xBase - 0x1000, yPos + *yBase);
    //draw the numbers
    int xOff = 0;
    if(digits<=0)
        digits = 1;
    while (digits != 0) {
        int n;
        if (lNum >= 1000||digits == 4) {
            n = lNum / 1000;
            lNum %= 1000;
            digits=3;
        } else if (lNum >= 100||digits == 3) {
            n = lNum / 100;
            lNum %= 100;
            digits=2;
        } else if (lNum >= 10||digits == 2) {
            n = lNum / 10;
            lNum %= 10;
            digits=1;
        } else {
            n = lNum;
            lNum = 0;
            digits=0;
        }
        numRect.left = 352 + n%5*0x10;
        numRect.up = 160 + isNeg*0x20 + n/5*0x10;
        numRect.right = numRect.left + 0x10;
        numRect.down = numRect.up + 0x10;
        numRect.down += rectSub;
        cameraBlit(BMP_TEXTBOX, numRect, *xBase + xOff, yPos + *yBase);
        xOff += 0x1000;
    }

}

void numObjInit()
{

}

void updateAllNumObj()
{
    list<NumberObject>::iterator nIt;
    for (nIt = numList.begin(); nIt != numList.end(); nIt++) {
        NumberObject &thisNum = *nIt;
        thisNum.timer++;
        if (thisNum.timer <= 32)
            thisNum.yPos -= 256;
    }
    numList.remove_if(numExpired);
}

void drawAllNumObj()
{
    list<NumberObject>::iterator nIt;
    for (nIt = numList.begin(); nIt != numList.end(); nIt++) {
        NumberObject &thisNum = *nIt;
        thisNum.draw(4);
    }
}

void clearAllNumObj()
{
    numList.clear();
}

void createNumber(int *pX, int *pY, int v)
{
    numList.push_back(NumberObject(pX, pY, v));
}

bool numExpired(const NumberObject &n)
{
    return n.timer >= 80;
}
