
#include "graphics.h"
#include "particle.h"

//global vars

int numParticles;
Particle *particleArrayPointer;

void Particle::setParticle(int size, int x, int y, int xVelIn, int yVelIn, int sheetXIn, int sheetYIn, int Behaviour)
{
   xPos = x;
   yPos = y;
   xVel = xVelIn;
   yVel = yVelIn;
   frameSize = size;
   sheetX = sheetXIn;
   sheetY = sheetYIn;
   inUse = 80;
}

Particle::Particle()
{
   xPos = yPos = xVel = yVel = frameSize = sheetX = sheetY = inUse = scriptState = scriptTimer = 0;
}

void particleInit(int number)
{
   Particle *localPointer;
   numParticles = number;
   particleArrayPointer = new Particle[number];
   for (int i = 0; i < number; i++)
   {
      localPointer = new Particle;
      particleArrayPointer[i] = *localPointer;
      delete localPointer;
   }
}

bool particleCreate(int size, int x, int y, int xVel, int yVel, int sheetX, int sheetY, int Behaviour)
{
   int localCounter = 0;
   Particle *localPointer;
   for (;localCounter <= numParticles; localCounter++)
   {
      if (particleArrayPointer[localCounter].inUse == 0)
         break;
   }
   if (localCounter >= numParticles)
      return false;
   particleArrayPointer[localCounter].setParticle(size, x, y, xVel, yVel, sheetX, sheetY, Behaviour);
   return true;
}

int countParticles()
{
   int result = 0;
   for (int i = 0; i < numParticles; i++)
   {
      if (particleArrayPointer[i].inUse != 0)
         result++;
   }
   return result;
}

void drawParticles()
{
   Rect displayRect;
   int size;
   for (int i = 0; i < numParticles; i++)
   {
      if (particleArrayPointer[i].inUse != 0)
      {
         size = particleArrayPointer[i].frameSize;
         displayRect.left = particleArrayPointer[i].sheetX;
         displayRect.up = particleArrayPointer[i].sheetY;
         displayRect.right = displayRect.left + size;
         displayRect.down = displayRect.up + size;
         cameraBlit(BMP_PARTICLE, displayRect, particleArrayPointer[i].xPos, particleArrayPointer[i].yPos);
      }
   }
}

void updateParticles()
{
   Particle *currentParticle;
   for (int i = 0; i < numParticles; i++)
   {
      if (particleArrayPointer[i].inUse != 0)
      {
         currentParticle = &particleArrayPointer[i];
         currentParticle->xPos += currentParticle->xVel;
         currentParticle->yPos += currentParticle->yVel;
         currentParticle->scriptTimer++;
         if (currentParticle->scriptTimer > 0x100)
            currentParticle->inUse = 0;
      }
   }
}
