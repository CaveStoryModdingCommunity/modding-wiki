#pragma once
#ifndef WEAPON_H
#define WEAPON_H

#define NUMWEAPON 8
#define LEVELPERWEAPON 3

class Weapon
{
public:
    int ID;
    int level;
    int energy;
    int maxAmmo;
    int currentAmmo;
	int reloadTimer;
	int triggerTimer;
	static int noAmmoTimer;

    Weapon();

    void draw(int x, int y, int dir);
    void renderIcon_large(int x, int y);
    void renderIcon_small(int x, int y, bool highlighted);

	bool subtractAmmo(int amt);
	void addAmmo(int amt);

    void act();
    void noWeapon();
    void bubbler();
    void pBlaster();
    int getEnergyToLevel();
};
#endif
