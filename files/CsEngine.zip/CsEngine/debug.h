#pragma once
#ifndef DEBUG_H
#define DEBUG_H

#include <allegro.h>
#include <list>
#include "player.h"
void updateFramePos();
void drawDebugFrame();
void debugInit();
void do_dbg1();
void forceCloseDialog();

void setFrameTarget(int target);
void drawCheatParts();

int setx_button_proc(int msg, DIALOG *d, int c);
int sety_button_proc(int msg, DIALOG *d, int c);
int song_button_proc(int msg, DIALOG *d, int c);
int sfx_button_proc(int msg, DIALOG *d, int c);
int giveWep_button_proc(int msg, DIALOG *d, int c);
int takeWep_button_proc(int msg, DIALOG *d, int c);
int setFlag_button_proc(int msg, DIALOG *d, int c);
int unFlag_button_proc(int msg, DIALOG *d, int c);
int healthM_button_proc(int msg, DIALOG *d, int c);
int healthC_button_proc(int msg, DIALOG *d, int c);
int tsc_button_proc(int msg, DIALOG *d, int c);
int itemAdd_button_proc(int msg, DIALOG *d, int c);
int itemRem_button_proc(int msg, DIALOG *d, int c);
int equip_button_proc(int msg, DIALOG *d, int c);
int unequip_button_proc(int msg, DIALOG *d, int c);
int entity_button_proc(int msg, DIALOG *d, int c);
int map_button_proc(int msg, DIALOG *d, int c);
int custom_edit_proc(int msg, DIALOG *d, int c);

#include <list>
class DebugState
{
public:
    int dbgMode;
    int frameLeft;
    int frameT;

    int mapNum;
    unsigned char *mapCopy[4];
    unsigned char *typeCopy;

    int gameState;
    Player pcCopy;

    std::list<Entity> eList0;
    std::list<Entity> eList1;
    std::list<Entity> eList2;
    std::list<Entity> eList3;

    unsigned char flagCopy[1000];

    //functions
    DebugState();
    ~DebugState();
    void getState();
    void setState();
};
#endif
