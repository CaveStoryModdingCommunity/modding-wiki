
#include "object.h"
#include "graphics.h"
#include "defines.h"

Object::Object()
{
    xPos = 0;
    yPos = 0;
    gfxNum = 0;
    Rect frameRect = {0,0,0,0};
}

void Object::draw()
{
    cameraBlit(gfxNum, frameRect, xPos, yPos);
}

void PhysicalObject::tileSolid(int x, int y)
{
    int result = 0;
    int scaleFactor = 0x200;
    int pxPerTile = 0x10;

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos - hitRect.left) < ((x * pxPerTile + 8) * scaleFactor)) &&
            ((xPos - hitRect.right) > ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile + 8) * scaleFactor) + hitRect.right;
        result |= LEFT;
    }

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 8) * scaleFactor)) &&
            ((xPos + hitRect.right) < ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile - 8) * scaleFactor) - hitRect.right;
        result |= RIGHT;
    }

    if (((xPos - hitRect.right) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos - hitRect.up) < ((y * pxPerTile + 8) * scaleFactor)) &&
            ((yPos - hitRect.up) > ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile + 8) * scaleFactor) + hitRect.up;
        result |= UP;
    }

    if (((xPos - hitRect.left) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 8) * scaleFactor)) &&
            ((yPos + hitRect.down) < ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile - 8) * scaleFactor) - hitRect.down;
        result |= DOWN;
    }
    collision |= result;
}

void PhysicalObject::tileSlopeFloor(int x, int y, int type)
{
    int tileLeft = ((x << 4) -8) << 9;
    int tileRight = ((x << 4) +8) << 9;
    int dBound = yPos + hitRect.down;
    int flags = 0;
    int bottom = ((y << 4) + 8) << 9;

    if (xPos < tileLeft)
        return;
    if (xPos > tileRight)
        return;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type) {
    case 2:
        difference = -0x2000;
    case 1:
        difference -= xPos - tileLeft;
        difference /= 2;
        flags |= 0x10;
        break;
    case 3:
        difference = (xPos - tileLeft) / 2;
        flags |= 0x10;
        break;
    case 4:
        difference = -0x2000;
    case 5:
        difference -= tileRight - xPos;
        difference /= 2;
        flags |= 0x20;
        break;
    case 6:
        difference = (tileRight - xPos) / 2;
        flags |= 0x20;
        break;
    case 0:
        break;
    }
    if (type == 0) {

    } else if ((bottom + difference) < dBound) {
        yPos = bottom + difference - hitRect.down;
        flags |= 8;
        collision |= flags;
    }
}

void PhysicalObject::tileSlopeRoof(int x, int y, int type)
{
    int tileLeft = ((x << 4) -8) << 9;
    int tileRight = ((x << 4) +8) << 9;
    int uBound = yPos - hitRect.up;
    int flags = 0;
    int top = ((y << 4) - 8) << 9;

    if (xPos < tileLeft)
        return;
    if (xPos > tileRight)
        return;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type) {
    case 1:
        difference = 0x2000;
    case 2:
        difference += tileRight - xPos;
        difference /= 2;
        flags |= 0x40;
        break;
    case 3:
        difference = tileRight - xPos;
        flags |= 0x40;
        break;
    case 5:
        difference = 0x2000;
    case 4:
        difference += xPos - tileLeft;
        difference /= 2;
        flags |= 0x80;
        break;
    case 6:
        difference = xPos - tileLeft;
        flags |= 0x80;
        break;
    }
    if ((difference + top) > uBound) {
        yPos = top + difference + hitRect.up;
        flags |= UP;
        collision |= flags;
    }
}

void PhysicalObject::tileWater(int x, int y)
{
    if ((xPos - hitRect.right < (0x10 * x + 6) << 9) &&
            (xPos + hitRect.right > (0x10 * x - 6) << 9) &&
            (yPos - hitRect.up < (0x10 * y + 6) << 9) &&
            (yPos + hitRect.down > (0x10 * y - 6) << 9))
        collision |= 0x100;
}
