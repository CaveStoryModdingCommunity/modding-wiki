//This class stores information for the events in a nim file
#include <allegro.h>

class NimEvent
{
	public:
   int colour;
	short length;
	
	NimEvent (int colourIn, int lengthIn)
	{
		colour = colourIn;
		length = (short) lengthIn;
		length &= 0xFF;
	}
   NimEvent() {}
};

class NimFile
{
   private:
      //variables
      char imgTag[4];
      short flags;
      char BPP;
      char transBits;
      int nimWidth;
      int nimHeight;
      RGB *palette;
      int numEvents;
      NimEvent *eventData;
      //functions
      
   public:
      inline int getBPP() {return (int) BPP;}
      inline int getWidth() {return nimWidth;}
      inline int getHeight() {return nimHeight;}
      RGB* getPalette() {return palette;}
      inline int getNumEvents() {return numEvents;}
      inline int getEventColour(int eventNum) {return eventData[eventNum].colour;}
      inline int getEventLength(int eventNum) {return eventData[eventNum].length;}
      inline int getFlags() {return flags;}
      int getFileSize();
      NimFile(const char *filename);
      ~NimFile();
};
