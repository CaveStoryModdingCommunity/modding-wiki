#pragma once
#ifndef NUMOBJ_H
#define NUMOBJ_H

#include "object.h"

class NumberObject: public Object
{
   public:
	int *xBase;
	int *yBase;
	int timer;
	int num;

	NumberObject();
	NumberObject(int *x, int *y, int val);

	void draw(int nDigits);
};

void numObjInit();
void drawAllNumObj();
void updateAllNumObj();
void clearAllNumObj();
void createNumber(int *xPointer, int *yPointer, int val);

bool numExpired(const NumberObject &ent);
#endif
