#pragma once
#ifndef RECT_H
#define RECT_H

typedef struct {
    int left, up, right, down;
} Rect;

#endif
