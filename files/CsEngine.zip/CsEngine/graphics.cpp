
#include <allegro.h>
#include <loadpng.h>
#include <alfont.h>
#include <stdio.h>
#include <vector>

#include "defines.h"
#include "graphics.h"
#include "general.h"

using namespace std;
extern vector<char> fadeVec;

int textColour = 0xFFFFFF;
int cameraX = 0;
int cameraY = 0;
int focusSpeed = 16;
int leftLimit = 0;
int topLimit = 0;
int rightLimit = 0x28000;
int lowerLimit = 0x1E000;

int bgMode = 0;
int getBgMode()
{
    return bgMode;
}

int *focusX = NULL;
int *focusY = NULL;
ALFONT_FONT *mainFont;
BITMAP* Buffer;
BITMAP* BitmapArray[NUMBITMAP] = {NULL}; //Define an array to hold various bitmap objects

void mainBlit (int GfxNum, Rect &Rect, int Xpos, int Ypos)
{
    int Width = Rect.right - Rect.left;
    int Height = Rect.down - Rect.up;
    masked_blit(BitmapArray[GfxNum], Buffer, Rect.left, Rect.up, Xpos, Ypos, Width, Height);
}

void clipBlit (int gfxNum, Rect &srcRect, int xPos, int yPos, Rect &clipRect)
{
    //check l and u positions against clip
    int srcX = srcRect.left;
    int lDif = clipRect.left - xPos;
    if (lDif > 0) {
        xPos = clipRect.left;
        srcX += lDif;
    }
    int srcY = srcRect.up;
    int uDif = clipRect.up - yPos;
    if (uDif > 0) {
        yPos = clipRect.up;
        srcY += uDif;
    }
    //check r and d against clip
    int width = srcRect.right - srcX;
    int height = srcRect.down - srcY;
    int rDif = xPos + width - clipRect.right;
    if (rDif > 0) {
        width -= rDif;
    }
    int dDif =  yPos + height - clipRect.down;
    if (dDif > 0) {
        height -= dDif;
    }
    masked_blit(BitmapArray[gfxNum], Buffer, srcX, srcY, xPos, yPos, width, height);
}

void screenBlit (int GfxNum, Rect &Rect, int Xpos, int Ypos)
{
    int Width = Rect.right - Rect.left;
    int Height = Rect.down - Rect.up;
    masked_blit(BitmapArray[GfxNum], screen, Rect.left, Rect.up, Xpos, Ypos, Width, Height);
}

void cameraBlit (int gfxNum, Rect &rect, int xPos, int yPos)
{
    xPos &= -256;
    yPos &= -256;
    xPos -= cameraX;
    if (xPos < 0)
        xPos -= 0xFF;
    yPos -= cameraY;
    if (yPos < 0)
        yPos -= 0xFF;
    xPos /= 0x100;
    yPos /= 0x100;
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;

    masked_blit(BitmapArray[gfxNum], Buffer, rect.left, rect.up, xPos, yPos, width, height);
}
//* Unfinished
void clipCameraBlit (int gfxNum, Rect &rect, int xPos, int yPos)
{
    xPos &= -256;
    yPos &= -256;
    xPos -= cameraX;
    if (xPos < 0)
        xPos -= 0xFF;
    yPos -= cameraY;
    if (yPos < 0)
        yPos -= 0xFF;
    xPos /= 0x100;
    yPos /= 0x100;
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;

    masked_blit(BitmapArray[gfxNum], Buffer, rect.left, rect.up, xPos, yPos, width, height);
}

void cameraBlit_scale (int gfxNum, Rect &rect, int xPos, int yPos, float scale)
{
    xPos &= -256;
    yPos &= -256;
    xPos -= cameraX;
    if (xPos < 0)
        xPos -= 0xFF;
    yPos -= cameraY;
    if (yPos < 0)
        yPos -= 0xFF;
    xPos /= 0x100;
    yPos /= 0x100;
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;

    int dest_w = (int)(scale * (float)width);
    int dest_h = (int)(scale * (float)height);

    if ((rect.right <= BitmapArray[gfxNum]->w) &&
            (rect.down <= BitmapArray[gfxNum]->h)) {
        masked_stretch_blit(BitmapArray[gfxNum], Buffer,
                            rect.left, rect.up, width, height,
                            xPos, yPos, dest_w, dest_h);
    }
}

void cameraBlit_trans_scale (int gfxNum, Rect &rect, int xPos, int yPos, int alpha, float scale)
{
    xPos &= -256;
    yPos &= -256;
    xPos -= cameraX;
    if (xPos < 0)
        xPos -= 0xFF;
    yPos -= cameraY;
    if (yPos < 0)
        yPos -= 0xFF;
    xPos /= 0x100;
    yPos /= 0x100;
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;
    if (  ((xPos + width) <= 0) ||
            ((yPos + height) <= 0) ||
            (xPos >= SCREEN_W) ||
            (yPos >= SCREEN_H) )
        return;

    int dest_w = (int)(scale * (float)width);
    int dest_h = (int)(scale * (float)height);

    //check clipping
    if ((rect.right <= BitmapArray[gfxNum]->w) &&
            (rect.down <= BitmapArray[gfxNum]->h)) {
        BITMAP *tempBitmap = create_bitmap(dest_w, dest_h);
        stretch_blit(BitmapArray[gfxNum], tempBitmap,
                     rect.left, rect.up, width, height,
                     0, 0, dest_w, dest_h);

        set_trans_blender(alpha, alpha, alpha, alpha);
        draw_trans_sprite(Buffer, tempBitmap, xPos, yPos);

        destroy_bitmap(tempBitmap);
    }
}

void transBlit (int gfxNum, Rect &rect, int xPos, int yPos, int alpha) //translucent blit
{
    set_trans_blender(alpha, alpha, alpha, alpha);
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;
    BITMAP *tempSprite = create_sub_bitmap(BitmapArray[gfxNum], rect.left, rect.up, width, height);
    draw_trans_sprite(Buffer, tempSprite, xPos, yPos);
    destroy_bitmap(tempSprite);
}

void cameraBlit_trans (int gfxNum, Rect &rect, int xPos, int yPos, int alpha) //translucent blit w/ camera
{
    xPos &= -256;
    yPos &= -256;
    xPos -= cameraX;
    if (xPos < 0)
        xPos -= 0xFF;
    yPos -= cameraY;
    if (yPos < 0)
        yPos -= 0xFF;
    xPos /= 0x100;
    yPos /= 0x100;
    int width = rect.right - rect.left;
    int height = rect.down - rect.up;
    if (  ((xPos + width) <= 0) ||
            ((yPos + height) <= 0) ||
            (xPos >= SCREEN_W) ||
            (yPos >= SCREEN_H) )
        return;
    transBlit(gfxNum, rect, xPos, yPos, alpha);
}

void noMaskBlit (int gfxNum, Rect &rect, int xPos, int yPos) //blit w/ fake mask colour
{
    int Width = rect.right - rect.left;
    if (Width > BitmapArray[gfxNum]->w)
        Width = BitmapArray[gfxNum]->w;
    int Height = rect.down - rect.up;
    if (Height > BitmapArray[gfxNum]->h)
        Height = BitmapArray[gfxNum]->h;
    rectfill(Buffer, xPos, yPos, xPos + Width - 1, yPos + Height - 1, 0x182041);
    masked_blit(BitmapArray[gfxNum], Buffer, rect.left, rect.up, xPos, yPos, Width, Height);
}
// Draw Background
void renderBG()
{
    if (BitmapArray[28]) {
        switch (bgMode) {
        case 0: { //static no scroll
            int numX = (SCREEN_W/BitmapArray[28]->w);
            int numY = (SCREEN_H/BitmapArray[28]->h);
            for (int y = 0; y <= numY; y++) {
                for (int x = 0; x <= numX; x++) {
                    draw_sprite(Buffer, BitmapArray[28], x*BitmapArray[28]->w, y*BitmapArray[28]->h);
                }//for x
            }//for y
        }
        break;
        case 1: { // move slow
            int slowX = -(cameraX >> 10);
            int slowY = -(cameraY >> 10);
            int bmW = BitmapArray[28]->w;
            int bmH = BitmapArray[28]->h;
            slowX %= bmW;
            slowY %= bmH;
            slowX -= bmW;
            slowY -= bmH;
            int numX = ((SCREEN_W - slowX) / bmW);
            int numY = ((SCREEN_H - slowY) / bmH);
            for (int y = 0; y <= numY; y++) {
                for (int x = 0; x <= numX; x++) {
                    draw_sprite(Buffer, BitmapArray[28], x*bmW + slowX, y*bmH + slowY);
                }//for x
            }//for y
        }
        break;
        case 2: { // follow foreground
            int xOff = -(cameraX >> 8);
            int yOff = -(cameraY >> 8);
            int bmW = BitmapArray[28]->w;
            int bmH = BitmapArray[28]->h;
            xOff %= bmW;
            yOff %= bmH;
            xOff -= bmW;
            yOff -= bmH;
            int numX = ((SCREEN_W - xOff) / bmW);
            int numY = ((SCREEN_H - yOff) / bmH);
            for (int y = 0; y <= numY; y++) {
                for (int x = 0; x <= numX; x++) {
                    draw_sprite(Buffer, BitmapArray[28], x*bmW + xOff, y*bmH + yOff);
                }//for x
            }//for y
        }
        break;
        case 3: //hide
            break;
        case 4: //hide
            break;
        case 5: //scroll fast left
            break;
        case 6: //scroll left (layered)
        case 7:
            break;
        default:
            break;
        }; //switch
    }//if (bitmapArray)
}

void setBgMode(int mode)
{
    bgMode = mode;
}

void drawFade(int out, int fadeDirection, int fadeTimer)
{
    Rect fadeRect = {0, 0, 32, 32};
    int fadeCol = fadeDirection / 100 % 10;
    int fadeProfile = fadeDirection / 10 % 10;
    int fadeDir = fadeDirection % 10;
    int drawColour = 0;
    switch (fadeCol) {
    case 0:
        drawColour = COL_BLACK;
        break;
    case 1:
        drawColour = COL_WHITE;
        break;
    case 2:
        drawColour = 0x606080;
        break;
    case 3:
        drawColour = 0x400000;
    }
    if (out == 2) {
        rectfill(Buffer, 0, 0, 640, 480, fadeCol);
    }

    switch (fadeProfile) {
    case 0:
    case 1: { //classic fade; circle and diamond type
        if (fadeProfile == 1) {
            fadeRect.up += 32;
            fadeRect.down += 32;
        }
        fadeRect.up += fadeCol * 64;
        fadeRect.down += fadeCol * 64;
        for (int y = 0; y < VISIBLE_TILES_Y; y++)
            for (int x = 0; x < VISIBLE_TILES_X; x++) {
                int frameNum;
                if (!out)
                    frameNum = (fadeTimer/2 - fadeVec[y*VISIBLE_TILES_X +x]);
                else
                    frameNum = 15 + fadeVec[y*VISIBLE_TILES_X +x] - fadeTimer/2; //highest numbers = highest frame num
                if (frameNum > 15)
                    frameNum = 15;
                fadeRect.left = frameNum * 32;
                fadeRect.right = fadeRect.left + 32;
                mainBlit(BMP_FADE, fadeRect, x*32, y*32);
            }
    } //classic fade case
    break;
    case 2: { //bars fade
        //vadeVec holds variable bar lens +- 30px
        for (int i = 0; i < fadeVec.size(); i++) {
            int x1 = 0, x2 = 0, y1 = 0, y2 = 0;
            switch (fadeDir) {
            case 0: //bars come from left
                if (!out) {
                    x2 = fadeVec[i]*fadeTimer;
                } else {
                    x1 = fadeVec[i]*fadeTimer;
                    x2 = 640;
                }
                y1 = i*16;
                y2 = (i+1)*16;
                break;
            case 1: //bars come from top
                if (!out) {
                    y2 = fadeVec[i]*fadeTimer;
                } else {
                    y1 = fadeVec[i]*fadeTimer;
                    y2 = 480;
                }
                x1 = i*16;
                x2 = (i+1)*16;
                break;
            case 2: //bars come from right
                if (out) {
                    x2 = 640 - fadeVec[i]*fadeTimer;
                } else {
                    x1 = 640 - fadeVec[i]*fadeTimer;
                    x2 = 640;
                }
                y1 = i*16;
                y2 = (i+1)*16;
                break;
            case 3: //barse come from bottom
                if (out) {
                    y2 = 480 - fadeVec[i]*fadeTimer;
                } else {
                    y1 = 480 - fadeVec[i]*fadeTimer;
                    y2 = 480;
                }
                x1 = i*16;
                x2 = (i+1)*16;
                break;
            default:
                break;
            }//fadeDir switch
            drawRectangle(x1, y1, x2, y2, drawColour);
        } //for each bar
    } //bars fade case
    default:
        break;
    }//fadeProfile switch
}

//Draws some white text to the buffer at the specified location.
void writeText(const char* words, int X, int Y)
{
    alfont_textout_ex(Buffer, mainFont, words, X, Y, textColour, -1);
}

void writeTextTo(int bmpNum, const char *string, int x, int y) //write text to another memory bitmap
{
    alfont_textout_ex(BitmapArray[bmpNum], mainFont, string, x, y, textColour, -1);
    alfont_textout_ex(BitmapArray[bmpNum], mainFont, string, x+1, y, textColour, -1);
}

//writes a number to the screen
void writeNum_l(int x, int y, int value)
{
    alfont_textprintf_ex(Buffer, mainFont, x, y, textColour, -1, "%d", value);
}
void writeNum_r(int x, int y, int value)
{
    alfont_textprintf_right_ex(Buffer, mainFont, x, y, textColour, -1, "%d", value);
}

//Draws some white text to the buffer at the specified location.
void writeText_al(const char* words, int X, int Y)
{
    if (words)
        if (strlen(words))
            textout_ex(Buffer, font, words, X, Y, textColour, -1);
}

//writes a number to the screen
void writeNum_l_al(int x, int y, int value)
{
    textprintf_ex(Buffer, font, x, y, textColour, -1, "%d", value);
}
void writeNum_r_al(int x, int y, int value)
{
    textprintf_right_ex(Buffer, font, x, y, textColour, -1, "%d", value);
}

void writeNum_l_al_hex(int x, int y, int value)
{
    textprintf_ex(Buffer, font, x, y, textColour, -1, "%#X", value);
}

void drawNumb2(int x, int y, int lNum, int isNeg, int digits)
{
    int xOff = 0;
    Rect numRect;
    if(digits<=0)
        digits = 1;
    while (digits != 0) {
        int n;
        if (lNum >= 1000||digits == 4) {
            n = lNum / 1000;
            lNum %= 1000;
            digits=3;
        } else if (lNum >= 100||digits == 3) {
            n = lNum / 100;
            lNum %= 100;
            digits=2;
        } else if (lNum >= 10||digits == 2) {
            n = lNum / 10;
            lNum %= 10;
            digits=1;
        } else {
            n = lNum;
            lNum = 0;
            digits=0;
        }
        numRect.left = n*0x10;
        numRect.up = 112 + isNeg*0x10;
        numRect.right = numRect.left + 0x10;
        numRect.down = numRect.up + 0x10;
        mainBlit(BMP_TEXTBOX, numRect, x + xOff,y);
        xOff += 16;
    }

}

//changes text colour
void fontCol(int colour)
{
    textColour = colour;
}
// Makes BG Black
void blackBuffer()
{
    clear_to_color(Buffer, COL_BLACK);
}

void clearBitmap(int bmpNum)
{
    if (bmpNum < 0)
        clear_to_color(Buffer, 0xFF00FF);
    else if (bmpNum < NUMBITMAP)
        clear_to_color(BitmapArray[bmpNum], 0xFF00FF);
}

//Count the FPS and display
void renderFPS(int x, int y, int ShowFPS)
{
    textprintf_ex(Buffer, font, x, y, textColour, -1, "%d", ShowFPS);
}

void setCamLimit(int tileX, int tileY)
{
    rightLimit = --tileX * 0x2000;
    lowerLimit = --tileY * 0x2000;
}

void getCamera(int &x, int &y)
{
    x = cameraX;
    y = cameraY;
}

bool isCamera(int *x, int *y)
{
    if ((x == focusX) || (y == focusY))
        return true;
    else
        return false;
}

//set camera (absolute)
void setCamera(int x, int y)
{
    if (x >= 0)
        cameraX = x;
    if (y >= 0)
        cameraY = y;
}

//set camera (pointers to focus spot)
void setCamera(int *x, int *y, int speed)
{
    focusX = x;
    focusY = y;
    //setCamera(*focusX, *focusY);
    focusSpeed = speed;
}

//set the object for the camera to follow
void setCamera (Object *obj, int speed)
{
    if (obj) {
        focusX = &obj->xPos;
        focusY = &obj->yPos;
        //setCamera(*focusX, *focusY);
    }
    focusSpeed = speed;
}
//update camera position from object
void updateCamera()
{
//focusX is a pointer to an integer (the point to focus on
    if (focusX) {
        cameraX += (*focusX - SCREENHALFW - cameraX) / focusSpeed;
    }
//likewise for focusY
    if (focusY) {
        cameraY += (*focusY - SCREENHALFH - cameraY) / focusSpeed;
    }
    if ((cameraX + SCREENW) > rightLimit)
        cameraX = rightLimit - SCREENW;
    if (cameraX < 0)
        cameraX = 0;
    if ((cameraY + SCREENH) > lowerLimit)
        cameraY = lowerLimit - SCREENH;
    if (cameraY < 0)
        cameraY = 0;
}

//Update Screen w/ Buffer
void updateScreen()
{
    //textout_ex(Buffer, font, "Press ESC to stop, or in emergency CTRL-ALT-END", 0, 470, makecol(255,0,0), 0);
    if ((Buffer) && (screen)) {
#ifdef EDITOR_MODE
        scare_mouse();
        acquire_screen();
        draw_sprite(screen, Buffer, 0, 0);
        release_screen();
        unscare_mouse();
#else
        acquire_screen();
        draw_sprite(screen, Buffer, 0, 0);
        release_screen();
#endif
    }
}

//Clear Graphics memory used
void destroyGraphics()
{
    destroy_bitmap (Buffer);
    if (mainFont)
        alfont_destroy_font(mainFont);
    for (int i = 0; i < NUMBITMAP; i++) {
        if (BitmapArray[i])
            destroy_bitmap(BitmapArray[i]);
    }
    alfont_exit();
}

//Initialize graphics stuff
void initializeGraphics()
{
    char *nameBuf = new char[128];
    memset(nameBuf, 0, 128);
    strcpy(nameBuf, dataDir);
    char *filenamePtr = &nameBuf[strlen(nameBuf)];
    //register_bitmap_file_type("nim", load_nim, NULL);
    BITMAP *loading;
    strcpy(filenamePtr, "Loading.bmp");
    printf("%s\n", nameBuf);
    loading = load_bitmap(nameBuf, NULL);
    if (!loading) {
        fatalError("Couldn't load loading.bmp!");
    }
    acquire_screen();
    draw_sprite(screen, loading, 240, 210);
    release_screen();
    destroy_bitmap(loading);
    Buffer = create_bitmap(SCREEN_W, SCREEN_H);
    //font
    alfont_init();
    mainFont = alfont_load_font("C:\\Windows\\Fonts\\simsun.ttc");
    if (mainFont == NULL) {
        mainFont = alfont_load_font("data\\coure.fon");
        if (mainFont == NULL)
            fatalError("Can't load the font!");
    }
    alfont_set_language(mainFont, "jpn");
    alfont_set_convert(mainFont, 2);
    alfont_set_font_size(mainFont, 20);
    strcpy(filenamePtr, "Title.png");
    loadImgSlot(0, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "Particle.png");
    loadImgSlot(1, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(2, "data/Title.png", IMGTYPE_PNG);
#ifdef EDITOR_MODE
    strcpy(filenamePtr, "DEBUG/frame.png");
    loadImgSlot(3, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "DEBUG/parts.png");
    loadImgSlot(4, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "DEBUG/CE_Tiles32.png");
    loadImgSlot(5, nameBuf, IMGTYPE_PNG);
    BitmapArray[7] = create_bitmap(452, 279); //pxe entity display box buffer
#endif
    strcpy(filenamePtr, "Fade.png");
    loadImgSlot(6, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "ItemImage.png");
    loadImgSlot(8, nameBuf, IMGTYPE_PNG);
    BitmapArray[9] = create_bitmap(SCREEN_W, SCREEN_H); //for map system
    BitmapArray[10] = create_bitmap(SCREEN_W, SCREEN_H); //2nd buffer
    strcpy(filenamePtr, "Arms.png");
    loadImgSlot(11, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "ArmsImage.png");
    loadImgSlot(12, nameBuf, IMGTYPE_PNG);
    BitmapArray[13] = create_bitmap(SCREEN_W, 17); //MNA
    strcpy(filenamePtr, "StageImage.png");
    loadImgSlot(14, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(15, "data/Title.png", IMGTYPE_PNG);
    strcpy(filenamePtr, "MyChar.png");
    loadImgSlot(16, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "Bullet.png");
    loadImgSlot(17, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(18, "data/Title.png", IMGTYPE_PNG);
    strcpy(filenamePtr, "Caret.png");
    loadImgSlot(19, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "npc/NpcSym.png");
    loadImgSlot(20, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(21, "data/Title.png", IMGTYPE_PNG);
    //loadImgSlot(22, "data/Title.png", IMGTYPE_PNG);
    strcpy(filenamePtr, "npc/NpcRegu.png");
    loadImgSlot(23, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(24, "data/Title.png", IMGTYPE_PNG);
    //loadImgSlot(25, "data/Title.png", IMGTYPE_PNG);
    strcpy(filenamePtr, "TextBox.png");
    loadImgSlot(26, nameBuf, IMGTYPE_PNG);
    strcpy(filenamePtr, "Face.png");
    loadImgSlot(27, nameBuf, IMGTYPE_PNG);
    //loadImgSlot(28, "data/Title.png", IMGTYPE_PNG);
    //loadImgSlot(29, "data/Title.png", IMGTYPE_PNG);
    BitmapArray[30] = create_bitmap(460, 20); //textbox line 1
    BitmapArray[31] = create_bitmap(460, 20); //textbox line 2
    BitmapArray[32] = create_bitmap(460, 20); //textbox line 3
    BitmapArray[33] = create_bitmap(460, 20); //textbox line 4
}

void loadImgSlot(int slot, const char *filename, int format)
{
#ifdef VERBOSE
    printf("Loading bitmap slot %d, %s\n", slot, filename);
#endif
    if (BitmapArray[slot]) {
        destroy_bitmap(BitmapArray[slot]);
        BitmapArray[slot] = NULL;
    }

    if (format == IMGTYPE_BMP)
        BitmapArray[slot] = load_bitmap(filename, NULL);
    else if (format == IMGTYPE_PNG)
        BitmapArray[slot] = load_png(filename, NULL);
    else
        fatalError("Invalid img format number");

    if (!BitmapArray[slot]) {
        char buf[64] = "Can't find image ";
        strcat(buf, filename);
        fatalError(buf);
    }
}

void loadTileset(const char *filename)
{
#ifdef VERBOSE
    printf("Loading tileset, %s\n", filename);
#endif
    if (BitmapArray[2])
        destroy_bitmap(BitmapArray[2]);
    BitmapArray[2] = load_png(filename, NULL);
}

void loadBG (const char *filename)
{
#ifdef VERBOSE
    printf("Loading background, 28, %s\n", filename);
#endif
    if (BitmapArray[28])
        destroy_bitmap(BitmapArray[28]);
    BitmapArray[28] = load_png(filename, NULL);
}

void loadNpcSets(const char *file1, const char *file2)
{
#ifdef VERBOSE
    printf("Loading bitmap NPC1, %s\nLoading bitmap NPC2, %s\n", file1, file2);
#endif
    if (BitmapArray[21])
        destroy_bitmap(BitmapArray[21]);
    BitmapArray[21] = load_png(file1, NULL);
    if (BitmapArray[22])
        destroy_bitmap(BitmapArray[22]);
    BitmapArray[22] = load_png(file2, NULL);
}

void loadOverlayImage(const char *filename)
{
#ifdef VERBOSE
    printf("Loading <IMG file %s.png\n", filename);
#endif
    char fBuf[32] = {0};
    sprintf(fBuf, "%s%s.png", dataDir, filename);
    if (BitmapArray[BMP_IMG])
        destroy_bitmap(BitmapArray[BMP_IMG]);
    BitmapArray[BMP_IMG] = load_png(fBuf, NULL);
}

void drawCircle(int x, int y, int radius, int col)
{
    circle(Buffer, x, y, radius, col);
}

void drawRectangle(int x, int y, int x2, int y2, int col)
{
    rectfill(Buffer, x, y, x2, y2, col);
}

#ifdef EDITOR_MODE
void drawMapBounds(int grid)
{
    extern int dbgScale;
    int effectiveR = rightLimit * dbgScale / 32;
    int effectiveL = lowerLimit * dbgScale / 32;
    int offset = 0x100 * dbgScale - 1;
    int xPixels = (effectiveR + offset) >> 8;
    int yPixels = (effectiveL + offset) >> 8;
    xPixels -= cameraX >> 8;
    yPixels -= cameraY >> 8;

    hline(Buffer, 0, yPixels, xPixels, 0x00FF00);
    vline(Buffer, xPixels, 0, yPixels, 0x00FF00);
    if (grid) {
        for (int x = xPixels - dbgScale; x > 0; x -= dbgScale) {
            vline(Buffer, x + 1, 0, yPixels, 1);
            vline(Buffer, x, 0, yPixels, 0xFF49FB);
        }
        for (int y = yPixels - dbgScale; y > 0; y -= dbgScale) {
            hline(Buffer, 0, y + 1, xPixels, 1);
            hline(Buffer, 0, y, xPixels, 0xFF49FB);
        }
    }
}


void drawMapCursor(Rect &theRect)
{
    extern int dbgScale;
    int x1, y1, x2, y2;
    x1 = (theRect.left * dbgScale) - (cameraX >> 8);
    y1 = (theRect.up * dbgScale) - (cameraY >> 8);
    x2 = x1 + (theRect.right - theRect.left) * dbgScale;
    y2 = y1 + (theRect.down - theRect.up) * dbgScale;
    if (x2 < x1)
        x1 += dbgScale;
    if (y2 < y1)
        y1 += dbgScale;

    rect(Buffer, x1+1, y1+1, x2+1, y2+1, 1);
    rect(Buffer, x1, y1, x2, y2, 0xFFFFFF);

}

int getTilesetHeight()
{
    return BitmapArray[BMP_TILESET]->h / 32;
}

#endif
