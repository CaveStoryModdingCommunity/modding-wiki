#pragma once
#ifndef EFFECT_H
#define EFFECT_H

#include "object.h"
class Effect: public Object
{
public:
    //object variables
    char inUse;
    int ID;
    int xVel;
    int yVel;
    int direction;
    int scriptState;
    //int scriptTimer;
    int frameNum;
    int frameTimer;

    //class utility functions
    Effect();
    Effect(int x, int y, int dir, int ID);
    ~Effect();
    void draw();

    //bullet AI functions
    void ePulseDisk();
    void eRisingDisk_Diamond();
    void eStar();
    void eFireballImpact();
    void eZZZ();
    void eBoostSmoke();
    void eDrownSprite();
    void eExclaimation();
    void eLevelUD();
    void eDamageDisk();
    void eSplosion();
    void eBonkDot();
    void eXX();
    void eWhiteCirclePop();
    void eEmpty();
};
//bullet use methods
void effectInit();
void createEffect(int x, int y, int ID, int mode);
void clearAllEffect();
void drawAllEffect();
void updateAllEffect();
bool effectExpired(const Effect &b);
int countEffects();
#endif
