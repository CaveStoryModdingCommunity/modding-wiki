#pragma once
#ifndef MAIN_H
#define MAIN_H

#include <allegro.h>
#include <winalleg.h>
void updateKeys();
void updateKeys_a();
int initialize();
//int titleMain();
DWORD WINAPI titleMain(LPVOID lpParam);
int gameMain(Profile *prof);
int main();
int oneFrame();
void drawAll();
void invoMain();
void invoDraw();
void optionsMenu();
void drawOptionsMenu(int cursorPos);
void close_button_handler();

#endif
