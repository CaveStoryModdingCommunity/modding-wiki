
#include "defines.h"
#ifdef EDITOR_MODE

#include <allegro.h>
#include <list>
#include <vector>
#include <string>
#include <stdio.h>

#include "weapon.h"
#include "profile.h"
#include "music.h"
#include "graphics.h"
#include "player.h"
#include "tsc.h"
#include "map.h"
#include "sfx.h"
#include "entity.h"
#include "debug.h"
#include "particle.h"
#include "main.h"
#include "general.h"
#include "mapEdit.h"
#include "pxeEdit.h"

extern int keyPressed;
extern int keyHeld;
extern int mousePressed;
extern int mouseHeld;
extern int alphaPressed;

extern int closeFlag;
extern int debugMode;
extern int timer_4, timer_2;
extern int escHack;
extern BITMAP *Buffer;

int selectedTile = 0;
int selectingTiles = 0;
int selectionX = 1;
int selectionY = 1;
int currentLayer = 2;

#define MODE_DRAW 0
#define MODE_FILL 1
#define MODE_REPLACE 2
#define MODE_RECT 3
#define MODE_COPY 4
#define MODE_PASTE 5
int drawMode = 0;
int dbgScale = 32;

Rect mapSelect = {0};
int showMapCursor = 0;
int selectingMap = 0;

using namespace std;
list<TileBlock> mapHistory;
list<TileBlock>::iterator mapIterator;

unsigned char dummy[] = {0};
TileBlock currentSelection(1,1,dummy);

DIALOG *focusObj = NULL;
DIALOG *mouseObj = NULL;

char *mapStr[] = {
    "Visible Layers", "Active Layer", "Draw Mode", "Misc",
    "Layer 1", "Layer 2", "Layer 3", "Layer 4",
    "Draw", "Fill", "Replace", "Rectangle", "Copy", "Do Nothing",
    "Show Tile Types", "Entities", "Grid",
    "0.25x", "0.5x", "1x", "2x", "Scale",
    "Edit Mapdata", "Save"
};
Rect mapBound[] = {
    {768, 512, 1280, 800}, //gui buttons zone
    {768, 0, 1280, 512}, //map tiles zone
    {258, 0, 768, 512}, //tile type selector
    {0, 784, 752, 800}, //bottom scrollbar
    {752, 0, 768, 784}, //right scrollbar
    {0, 0, 752, 784} //map area
};

DIALOG mapEditDialog[] = {
    /* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags) (d1)  (d2)  (dp)(dp2) (dp3) */
    //labels
    {d_ctext_proc,       1028, 520,  0,    0,    0, -1,0,    0,       0,    0,    mapStr[0], NULL, NULL},
    {d_ctext_proc,       1028, 560,  0,    0,    0, -1,0,    0,       0,    0,    mapStr[1], NULL, NULL},
    {d_ctext_proc,       1028, 600,  0,    0,    0, -1,0,    0,       0,    0,    mapStr[2], NULL, NULL},
    {d_ctext_proc,       1028, 660,  0,    0,    0, -1,0,    0,       0,    0,    mapStr[3], NULL, NULL},
    {d_ctext_proc,       1028, 700,  0,    0,    0, -1,0,    0,       0,    0,    mapStr[21], NULL, NULL},

#define LAYER_VISIBLE 5
    //layer buttons
    {custom_check_proc,  850,  540,  80,   16,   0, 0, 0, D_SELECTED, 0,    0,    mapStr[4], NULL, NULL},
    {custom_check_proc,  950,  540,  80,   16,   0, 0, 0, D_SELECTED, 0,    0,    mapStr[5], NULL, NULL},
    {custom_check_proc,  1050, 540,  80,   16,   0, 0, 0, D_SELECTED, 0,    0,    mapStr[6], NULL, NULL},
    {custom_check_proc,  1150, 540,  80,   16,   0, 0, 0, D_SELECTED, 0,    0,    mapStr[7], NULL, NULL},
    //layer buttons (radio)
#define LAYER_ACTIVE 9
    {custom_radio_proc,  850,  580,  80,   16,   0, 0, 0,    0,       0,    1,    mapStr[4], NULL, NULL},
    {custom_radio_proc,  950,  580,  80,   16,   0, 0, 0,    0,       0,    1,    mapStr[5], NULL, NULL},
    {custom_radio_proc,  1050, 580,  80,   16,   0, 0, 0, D_SELECTED, 0,    1,    mapStr[6], NULL, NULL},
    {custom_radio_proc,  1150, 580,  80,   16,   0, 0, 0,    0,       0,    1,    mapStr[7], NULL, NULL},
    //draw mode buttons (radio)
#define DRAW_MODE 13
    {custom_radio_proc,  850,  620,  80,   16,   0, 0, 0, D_SELECTED, 1,    1,    mapStr[8], NULL, NULL},
    {custom_radio_proc,  950,  620,  80,   16,   0, 0, 0,    0,       1,    1,    mapStr[9], NULL, NULL},
    {custom_radio_proc,  1050, 620,  80,   16,   0, 0, 0,    0,       1,    1,    mapStr[10], NULL, NULL},
    {custom_radio_proc,  1150, 620,  80,   16,   0, 0, 0,    0,       1,    1,    mapStr[11], NULL, NULL},
    {custom_radio_proc,  950,  640,  80,   16,   0, 0, 0,    0,       1,    1,    mapStr[12], NULL, NULL},
    {custom_radio_proc,  1050, 640,  80,   16,   0, 0, 0,    0,       1,    1,    mapStr[13], NULL, NULL},
    //misc stuff
#define PROC_MISC 19
    {custom_check_proc,  850,  680,  160,  16,   0, 0, 0,    0,       0,    0,    mapStr[14], NULL, NULL},
    {custom_check_proc,  1050, 680,  80,   16,   0, 0, 0,    0,       0,    0,    mapStr[15], NULL, NULL},
    {custom_check_proc,  1150, 680,  80,   16,   0, 0, 0,    0,       0,    0,    mapStr[16], NULL, NULL},
    //scale buttons (radio)
#define SCALE 22
    {custom_radio_proc,  850,  720,  80,   16,   0, 0, 0,    0,       2,    1,    mapStr[17], NULL, NULL},
    {custom_radio_proc,  950,  720,  80,   16,   0, 0, 0,    0,       2,    1,    mapStr[18], NULL, NULL},
    {custom_radio_proc,  1050, 720,  80,   16,   0, 0, 0, D_SELECTED, 2,    1,    mapStr[19], NULL, NULL},
    {custom_radio_proc,  1150, 720,  80,   16,   0, 0, 0,    0,       2,    1,    mapStr[20], NULL, NULL},

    //sliders
#define SCROLL 26
    {custom_slider_proc, 0,    784,  752,  16,   0, 0, 0,    0,       0,    1000, NULL, NULL, NULL},
    {custom_slider_proc, 752,  0,    16,  784,   0, 0, 0,    0,       0,    1000, NULL, NULL, NULL},

    //editable text obj. proc

    //button proc
    {save_button_proc,   900,  750,  80,   20,   0, 0, 0,    0,       0,    0,    mapStr[23], NULL, NULL},
    {mapdata_button_proc,1050, 750,  110,  20,   0, 0, 0,    0,       0,    0,    mapStr[22], NULL, NULL}
    //{custom_edit_proc,   1050, 750,  120,  20,   0, 0, 0,    0,       5,    0,    editTest, NULL, NULL}
};


vector<string> backgrounds;
vector<string> npcSheets;
vector<string> tilesets;

void getImageStrings()
{
    al_ffblk info;
    string strBuf;
    //find background images
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/bk*.png", dataDir);
    if (al_findfirst(filebuf, &info, FA_ALL) == 0) {
        do {
            replace_extension(info.name, info.name, "", 80);
            strBuf = get_filename(info.name);
            strBuf.erase(0, 2);
            strBuf.erase(strBuf.size()-1);
            backgrounds.push_back(strBuf);
        } while (al_findnext(&info) == 0);
    }
    al_findclose(&info);

    //find npc sheets
    sprintf(filebuf, "%s/Npc/npc*.png\0", dataDir);
    if (al_findfirst(filebuf, &info, FA_ALL) == 0) {
        do {
            replace_extension(info.name, info.name, "", 80);
            strBuf = get_filename(info.name);
            strBuf.erase(0, 3);
            strBuf.erase(strBuf.size()-1);
            npcSheets.push_back(strBuf);
        } while (al_findnext(&info) == 0);
    }
    al_findclose(&info);

    //find tilesets
    sprintf(filebuf, "%s/Stage/Prt*.png\0", dataDir);
    if (al_findfirst(filebuf, &info, FA_ALL) == 0) {
        do {
            replace_extension(info.name, info.name, "", 80);
            strBuf = get_filename(info.name);
            strBuf.erase(0, 3);
            strBuf.erase(strBuf.size()-1);
            tilesets.push_back(strBuf);
        } while (al_findnext(&info) == 0);
    }
    al_findclose(&info);
}

const char *bgList_proc(int index, int *list_size)
{
    if (index >= 0)
        return backgrounds[index].c_str();
    if (list_size)
        *list_size = backgrounds.size();
    return "NULL";
}

const char *npcList_proc(int index, int *list_size)
{
    if (index >= 0)
        return npcSheets[index].c_str();
    if (list_size)
        *list_size = npcSheets.size();
    return "NULL";
}

const char *prtList_proc(int index, int *list_size)
{
    if (index >= 0)
        return tilesets[index].c_str();
    if (list_size)
        *list_size = tilesets.size();
    return "NULL";
}

char *mapdataStr[] = {
    "BgName", "Boss #", "Filename", //list, edit, edit
    "Map name", "Npc1", "Npc2", //edit, list, list
    "Scroll type", "Tileset", "Confirm", //list, list, button
    "Fixed", "Move Slow", "Follow FG", "Hide",
    "Hide", "Fast Left", "Left Parallax Wind", "Left Parallax"
};

char *scrollList_proc(int index, int *list_size)
{
    if (index >= 0)
        return mapdataStr[index+9];
    if (list_size)
        *list_size = 8;
    return "NULL";
}

char field_mapname[34];
char field_filename[16];
char field_bossnum[3];

DIALOG mapdataDialog[] = {
    /* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags) (d1)  (d2)  (dp)(dp2) (dp3) */
    //labels
    {d_text_proc,        800,  530,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[0], NULL, NULL}, //"BgName"
    {d_text_proc,        920,  530,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[7], NULL, NULL}, //"Tileset"
    {d_text_proc,        1040, 530,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[4], NULL, NULL}, //"NpcSheet1"
    {d_text_proc,        1180, 530,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[5], NULL, NULL}, //"NpcSheet2"
    {d_rtext_proc,       865,  650,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[3], NULL, NULL}, //"MapName"
    {d_rtext_proc,       1130, 650,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[1], NULL, NULL}, //"Boss#"
    {d_rtext_proc,       865,  670,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[2], NULL, NULL}, //"Filename"
    {d_ctext_proc,       900,  700,  0,    0,    0, 0,    0,    0,    0,    0,    mapdataStr[6], NULL, NULL}, //"Scroll type"

    //lists
#define MAPDAT_LIST 8
    {d_list_proc,        790,  540,  100,  100,  0, 0,    0,    0,    0,    0,    (void*)bgList_proc, NULL, NULL},
    {d_list_proc,        910,  540,  100,  100,  0, 0,    0,    0,    0,    0,    (void*)prtList_proc, NULL, NULL},
    {d_list_proc,        1030, 540,  100,  100,  0, 0,    0,    0,    0,    0,    (void*)npcList_proc, NULL, NULL},
    {d_list_proc,        1170, 540,  100,  100,  0, 0,    0,    0,    0,    0,    (void*)npcList_proc, NULL, NULL},
    {d_list_proc,        840,  720,  200,  50,   0, 0,    0,    0,    0,    0,    (void*)scrollList_proc, NULL, NULL},

    //edit
#define MAPDAT_EDIT 13
    {d_edit_proc,        870,  650,   200,  10,   0, 0,    0,    0,   33,   0,    field_mapname, NULL, NULL},
    {d_edit_proc,        870,  670,   200,  10,   0, 0,    0,    0,   15,   0,    field_filename, NULL, NULL},
    {custom_edit_proc,   1135, 650,   120,  20,   0, 0,    0,    0,   2,    0,    field_bossnum, NULL, NULL},

    //button
    {d_button_proc,      1160, 750,  80,   20,   0, 0,    0,   D_EXIT,0,    0,    mapdataStr[8], NULL, NULL },
    {d_keyboard_proc,    0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL},
    {d_yield_proc,       0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL},
    {NULL,               0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL}
};

void mapdataDialog_init()
{
    extern MapData *mapdata;
    extern int currentMap;
    int i = 0;

    //init bg list
    string checkStr = mapdata[currentMap].bgName;
    checkStr.erase(0,2);
    for (i = 0; checkStr.compare(backgrounds[i]); i++);
    mapdataDialog[MAPDAT_LIST].d1 = i;

    //init tileset list
    checkStr = mapdata[currentMap].tileset;
    for (i = 0; checkStr.compare(tilesets[i]); i++);
    mapdataDialog[MAPDAT_LIST+1].d1 = i;

    //init npc1 list
    checkStr = mapdata[currentMap].npc1;
    for (i = 0; checkStr.compare(npcSheets[i]); i++);
    mapdataDialog[MAPDAT_LIST+2].d1 = i;

    //init npc2 list
    checkStr = mapdata[currentMap].npc2;
    for (i = 0; checkStr.compare(npcSheets[i]); i++);
    mapdataDialog[MAPDAT_LIST+3].d1 = i;

    //init fields
    memcpy(field_mapname, mapdata[currentMap].mapName, 34);
    memcpy(field_filename, mapdata[currentMap].filename, 16);
    sprintf(field_bossnum, "%d", mapdata[currentMap].bossNum);

    //init scroll type
    mapdataDialog[MAPDAT_LIST+4].d1 = mapdata[currentMap].scrollType;
}

void mapdataDialog_commit()
{
    extern MapData *mapdata;
    extern int currentMap;

    memset(mapdata[currentMap].bgName, 0, 34);
    sprintf(mapdata[currentMap].bgName, "bk");
    memcpy(&mapdata[currentMap].bgName[2],
           backgrounds[mapdataDialog[MAPDAT_LIST].d1].c_str(),
           backgrounds[mapdataDialog[MAPDAT_LIST].d1].length());

    memset(mapdata[currentMap].tileset, 0, 16);
    memcpy(mapdata[currentMap].tileset,
           tilesets[mapdataDialog[MAPDAT_LIST+1].d1].c_str(),
           tilesets[mapdataDialog[MAPDAT_LIST+1].d1].length());

    memset(mapdata[currentMap].npc1, 0, 16);
    memcpy(mapdata[currentMap].npc1,
           npcSheets[mapdataDialog[MAPDAT_LIST+2].d1].c_str(),
           npcSheets[mapdataDialog[MAPDAT_LIST+2].d1].length());

    memset(mapdata[currentMap].npc2, 0, 16);
    memcpy(mapdata[currentMap].npc2,
           npcSheets[mapdataDialog[MAPDAT_LIST+3].d1].c_str(),
           npcSheets[mapdataDialog[MAPDAT_LIST+3].d1].length());

    memcpy(mapdata[currentMap].filename, field_filename, 15);
    memcpy(mapdata[currentMap].mapName, field_mapname, 33);
    mapdata[currentMap].bossNum = str2num(field_bossnum);
    mapdata[currentMap].scrollType = mapdataDialog[MAPDAT_LIST+4].d1;
}
/*****************************************************************
                     Custom GUI functions
*****************************************************************/

int custom_check_proc(int msg, DIALOG *d, int c)
{
    switch (msg) {
    case MSG_DRAW: {
        Rect boxRect = {0x80, 0, 0x90, 0x10};
        if (d->flags & D_SELECTED) {
            boxRect.left += 0x10;
            boxRect.right += 0x10;
        }
        mainBlit(BMP_DBG2, boxRect, d->x, d->y);
        writeText((char*)d->dp, d->x + 0x14, d->y);
    }
    break;
    case MSG_LPRESS: {
        if ((mouse_x > d->x) &&
                (mouse_x < d->x + d->w)  &&
                (mouse_y > d->y) &&
                (mouse_y < d->y + d->h))
            d->flags ^= D_SELECTED;
    }
    break;
    default:
        return D_O_K;
    };
    return D_O_K;
}

int custom_radio_proc(int msg, DIALOG *d, int c)
{
    switch (msg) {
    case MSG_DRAW: {
        Rect boxRect = {0x80, 0, 0x90, 0x10};
        if (d->flags & D_SELECTED) {
            boxRect.left += 0x10;
            boxRect.right += 0x10;
        }
        boxRect.up += d->d2 * 0x10;
        boxRect.down += d->d2 * 0x10;
        mainBlit(BMP_DBG2, boxRect, d->x, d->y);
        writeText((char*)d->dp, d->x + 0x14, d->y);
    }
    break;
    case MSG_LPRESS: {
        if ((mouse_x > d->x) &&
                (mouse_x < d->x + d->w)  &&
                (mouse_y > d->y) &&
                (mouse_y < d->y + d->h)) {
            sendMapMessage(MSG_RADIO, d->d1);
            d->flags |= D_SELECTED;
        }
    }
    break;
    case MSG_RADIO:
        if (d->d1 == c)
            d->flags &= !D_SELECTED;
        break;
    default:
        break;
    };
    return D_O_K;
}

//d1 = slider pos
//flags & D_USER
int custom_slider_proc(int msg, DIALOG *d, int c)
{
    extern int rightLimit, lowerLimit;
    switch (msg) {
    case MSG_DRAW: {
        if (d->w > d->h) { //if horizontal mode
            Rect tempRect = {0, 20, 16, 36};
            mainBlit(BMP_DBG2, tempRect, d->x, d->y); //draw left arrow marker
            //draw the bar
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            for (int i = d->x + 0x10; i < (d->x + d->w); i+=16)
                mainBlit(BMP_DBG2, tempRect, i, d->y);
            //draw the right arrow marker
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            mainBlit(BMP_DBG2, tempRect, d->x + d->w - 0x10, d->y);
            //draw the position marker
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            mainBlit(BMP_DBG2, tempRect, d->x + 0x10 + d->d1, d->y);
        } else {
            Rect tempRect = {0x40, 20, 0x50, 36};
            mainBlit(BMP_DBG2, tempRect, d->x, d->y); //draw left arrow marker
            //draw the bar
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            for (int i = d->y + 0x10; i < (d->y + d->h); i+=16)
                mainBlit(BMP_DBG2, tempRect, d->x, i);
            //draw the right arrow marker
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            mainBlit(BMP_DBG2, tempRect, d->x, d->y + d->h - 0x10);
            //draw the position marker
            tempRect.left += 0x10;
            tempRect.right += 0x10;
            mainBlit(BMP_DBG2, tempRect, d->x, d->y + 0x10 + d->d1);

        }
    }
    break;
    case MSG_START: {
        int camX, camY;
        getCamera(camX, camY);
        camX >>= 8;
        camY >>= 8;
        int effectiveR = rightLimit * dbgScale / 32;
        int effectiveL = lowerLimit * dbgScale / 32;
        if (d->w > d->h) { //if horizontal mode
            d->d1 = camX * d->w / ((effectiveR - SCREENHALFW) >> 8);
            if (d->d1 > (d->w - 0x30))
                d->d1 = d->w - 0x30;
        } else {
            d->d1 = camY * d->h / ((effectiveL - SCREENHALFH) >> 8);
            if (d->d1 > (d->h - 0x30))
                d->d1 = d->h - 0x30;
        }
    }
    break;
    case MSG_CLICK: {
        if (d->w > d->h) { //if horizontal mode
            //set nubGrabbed flag
            if (mousePressed &&
                    (mouse_x > (d->x + d->d1 + 0x10)) &&
                    (mouse_x < (d->x + d->d1 + 0x20)) &&
                    (mouse_y > d->y) &&
                    (mouse_y < (d->y + d->h)) ) {
                d->flags |= D_USER;
            } else if (mousePressed) {
                d->flags &= !D_USER;
                if (c) {
                    focusObj = NULL;
                    return D_O_K;
                }
            }

            if (d->flags & D_USER) {
                d->d1 = mouse_x - d->x - 0x18;
            } else {
                if ((mouse_y > d->y) && (mouse_y < (d->y + d->h))) {
                    if ((mouse_x < (d->x + 0x10) && (mouse_x > d->x))) {
                        d->d1 -= 2;
                    } else if ((mouse_x > (d->x + d->w - 0x10)) &&
                               (mouse_x < (d->x + d->w))) {
                        d->d1 += 2;
                    } else if ((mouse_x < (d->x + 0x10 + d->d1)) &&
                               (mouse_x > (d->x + 0x10))) {
                        d->d1 -= 8;
                    } else if ((mouse_x > (d->x + d->d1 + 0x20)) &&
                               (mouse_x < (d->x + d->w - 0x10))) {
                        d->d1 += 8;
                    }
                } //if mouse in Y-range
            }
            //check bounds
            if (d->d1 < 0)
                d->d1 = 0;
            if (d->d1 > (d->w - 0x30))
                d->d1 = d->w - 0x30;
            //update camera position
            int effectiveR = rightLimit * dbgScale / 32;
            setCamera((effectiveR - SCREENHALFW) * d->d1 / d->w, -1);

        } else { //else vertical mode
            //set nubGrabbed flag
            if (mousePressed &&
                    (mouse_y > (d->y + d->d1 + 0x10)) &&
                    (mouse_y < (d->y + d->d1 + 0x20)) &&
                    (mouse_x > d->x) &&
                    (mouse_x < (d->x + d->w)) ) {
                d->flags |= D_USER;
            } else if (mousePressed) {
                d->flags &= !D_USER;
                if (c) {
                    focusObj = NULL;
                    return D_O_K;
                }
            }//else !nubGrabbed

            if (d->flags & D_USER) {
                d->d1 = mouse_y - d->y - 0x18;
            } else {
                if ((mouse_x > d->x) && (mouse_x < (d->x + d->w))) {
                    if ((mouse_y < (d->y + 0x10) && (mouse_y > d->y))) {
                        d->d1 -= 2;
                    } else if ((mouse_y > (d->y + d->h - 0x10)) &&
                               (mouse_y < (d->y + d->h))) {
                        d->d1 += 2;
                    } else if ((mouse_y < (d->y + 0x10 + d->d1)) &&
                               (mouse_y > (d->y + 0x10))) {
                        d->d1 -= 8;
                    } else if ((mouse_y > (d->y + d->d1 + 0x20)) &&
                               (mouse_y < (d->y + d->h - 0x10))) {
                        d->d1 += 8;
                    }
                } //if mouse in x-range
            } //else !D_USER
            //check bounds
            if (d->d1 < 0)
                d->d1 = 0;
            if (d->d1 > (d->h - 0x30))
                d->d1 = d->h - 0x30;
            //update camera pos
            int effectiveL = lowerLimit * dbgScale / 32;
            setCamera(-1, (effectiveL - SCREENHALFH) * d->d1 / d->h);
        }//else vertical mode
        if (d->flags & D_USER)
            focusObj = d;
        else
            focusObj = NULL;
    }
    break;
    case MSG_WHEEL: {
        d->d1 -= c;
        if (d->d1 < 0)
            d->d1 = 0;
        //update positons
        if (d->w > d->h) {
            if (d->d1 > (d->w - 0x30))
                d->d1 = d->w - 0x30;
            int effectiveR = rightLimit * dbgScale / 32;
            setCamera((effectiveR - SCREENHALFW) * d->d1 / d->w, -1);
        } else {
            if (d->d1 > (d->h - 0x30))
                d->d1 = d->h - 0x30;
            int effectiveL = lowerLimit * dbgScale / 32;
            setCamera(-1, (effectiveL - SCREENHALFH) * d->d1 / d->h);
        }
    }
    break;
    case MSG_LOSTFOCUS:
        return D_WANTFOCUS;
    default:
        break;
    };
    return D_O_K;
}

int mapdata_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_LPRESS) {
        d->flags |= D_SELECTED;
        //add action code here
        rectfill(screen, 784, 515, 1279, 790, gui_bg_color);
        gui_set_screen(screen);
        mapdataDialog_init();
        popup_dialog(mapdataDialog, 0);
        mapdataDialog_commit();
        extern int timer_1;
        timer_1 = 1;
        timer_4 = 1;
        timer_2 = 1;
        gui_set_screen(Buffer);
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else if (msg == MSG_DRAW) {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int save_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_LPRESS) {
        d->flags |= D_SELECTED;
        //add action code here
        saveMap();

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else if (msg == MSG_DRAW) {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

/*************************************************************************
                     Map editor stuff
*************************************************************************/

void mapEditLoop()
{
    //setup map edit stuff
    setFrameTarget(766);
    debugMode = DBG_MAP;
    gui_set_screen(Buffer);
    timer_2 = 0;
    mapIterator = mapHistory.begin();
    addUndo_map();
    //set fg/bg colours
    for (int i = 0; i < (sizeof mapEditDialog / sizeof mapEditDialog[0]); i++) {
        mapEditDialog[i].fg = gui_fg_color;
        mapEditDialog[i].bg = gui_bg_color;
        if (mapEditDialog[i].proc == d_ctext_proc) {
            mapEditDialog[i].fg = 0xFFFFFF;
            mapEditDialog[i].bg = -1;
        }
        mapEditDialog[i].proc(MSG_START, &mapEditDialog[i], 0);
    }

    while (!(keyPressed & KEYESC) && (!closeFlag)) {
        while (timer_2) {
            mapDraw();
            timer_2--;
            if (timer_2 > 10) {
                timer_2 = 0;
                setError("Can't keep up!(mapEdit2)");
                break;
            }
        }

        while (timer_4) {
            updateKeys();
            updateKeys_a();
            updateFramePos();
            doMapGuiLogic();
            updateTileAnim();
            checkTabs();
            timer_4--;
            if (timer_4 > 10) {
                setError("Can't keep up!(mapEdit4)");
                timer_4 = 0;
                break;
            }
        }
        rest(1);
    }
    //close map edit stuff
    mapHistory.clear();
    gui_set_screen(screen);
    debugMode = DBG_DEFAULT;
    focusObj = NULL;
    mouseObj = NULL;
    setFrameTarget(0);
    escHack = 50;
}

void tileTypeLoop()
{
    timer_2 = 0;
    timer_4 = 0;
    int escFlag = 0;
    debugMode = DBG_MAP_TYPE;
    while (!(keyPressed & KEYESC) && (!closeFlag) && !escFlag) {
        while (timer_2) {
            mapDraw();
            timer_2--;
        }
        while (timer_4) {
            updateKeys();
            updateKeys_a();
            updateFramePos();
            updateTileAnim();
            //check if we've selected our tile
            if (mousePressed & LEFT) {
                if ((mouse_x > mapBound[2].left) &&
                        (mouse_x < mapBound[2].right) &&
                        (mouse_y > mapBound[2].up) &&
                        (mouse_y < mapBound[2].down)) {
                    //within type region
                    int x = (mouse_x - mapBound[2].left) / 32;
                    int y = mouse_y / 32;
                    setType(selectedTile, y*16 + x);

                }
                escFlag = 1;
            }
            timer_4--;
        }
        rest(1);
    } //while in tile selecting mode
    debugMode = DBG_MAP;
    timer_4 = 1;
    mousePressed = 0;
}

void mapDraw()
{
    blackBuffer();
    renderBG();

    if (mapEditDialog[LAYER_VISIBLE].flags & D_SELECTED)
        drawTiles(0);
    if (mapEditDialog[LAYER_VISIBLE + 1].flags & D_SELECTED)
        drawTiles(1);
    if (mapEditDialog[LAYER_VISIBLE + 2].flags & D_SELECTED)
        drawTiles(2);
    if (mapEditDialog[LAYER_VISIBLE + 3].flags & D_SELECTED)
        drawTiles(3);
    if (mapEditDialog[PROC_MISC].flags & D_SELECTED)
        drawTileTypes();
    if (mapEditDialog[PROC_MISC+1].flags & D_SELECTED)
        renderEntityIcons();
    if (mapEditDialog[PROC_MISC+2].flags & D_SELECTED)
        drawMapBounds(1);
    else
        drawMapBounds(0);
    if (showMapCursor)
        drawMapCursor(mapSelect);

    drawDebugFrame();
    sendMapMessage(MSG_DRAW, 0);
    if (debugMode == DBG_MAP_TYPE) {
        Rect typeRect = {0,0,512,512};
        mainBlit(BMP_DBG3, typeRect, 258, 0);
    }
    drawTabs();
    updateScreen();
}

void doMapGuiLogic()
{
    //calculate active layer
    if (mapEditDialog[LAYER_ACTIVE].flags & D_SELECTED)
        currentLayer = 0;
    else if (mapEditDialog[LAYER_ACTIVE+1].flags & D_SELECTED)
        currentLayer = 1;
    else if (mapEditDialog[LAYER_ACTIVE+2].flags & D_SELECTED)
        currentLayer = 2;
    else if (mapEditDialog[LAYER_ACTIVE+3].flags & D_SELECTED)
        currentLayer = 3;

    //scale
    if (mapEditDialog[SCALE].flags & D_SELECTED)
        dbgScale = 8;
    else if (mapEditDialog[SCALE+1].flags & D_SELECTED)
        dbgScale = 16;
    else if (mapEditDialog[SCALE+2].flags & D_SELECTED)
        dbgScale = 32;
    else if (mapEditDialog[SCALE+3].flags & D_SELECTED)
        dbgScale = 64;

    //draw mode
    for (int i = 0; i < 6; i++)
        if (mapEditDialog[DRAW_MODE+i].flags & D_SELECTED)
            drawMode = i;


    if (mousePressed & (LEFT_REL | RIGHT_REL)) {
        if (selectingTiles) {
            selectingTiles = 0;
            tileSelection();
        }
        if (selectingMap) {
            selectingMap = 0;
            mapCommit();
        }
    }
    //general GUI
    if ((mouse_x > mapBound[0].left) &&
            (mouse_x < mapBound[0].right) &&
            (mouse_y > mapBound[0].up) &&
            (mouse_y < mapBound[0].down)) {
        int wasMouse = 0; //for mouse
        for (int i = 0; i < (sizeof mapEditDialog / sizeof mapEditDialog[0]); i++) {

            if ((mouse_x > mapEditDialog[i].x) &&
                    (mouse_x < mapEditDialog[i].x + mapEditDialog[i].w) &&
                    (mouse_y > mapEditDialog[i].y) &&
                    (mouse_y < mapEditDialog[i].y + mapEditDialog[i].h)) {
                wasMouse = 1; //the mouse was over an object
                DIALOG *thisObj = &mapEditDialog[i];
                if (mouseObj != thisObj) { //got/lost mouse messages
                    if (mouseObj)
                        mouseObj->proc(MSG_LOSTMOUSE, mouseObj, 0);
                    if (thisObj->proc(MSG_GOTMOUSE, thisObj, 0) == D_WANTFOCUS) { //got/lost focus messages?
                        thisObj->proc(MSG_GOTFOCUS, thisObj, 0);
                        if (focusObj)
                            focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
                        focusObj = thisObj;
                    }
                    mouseObj = thisObj;
                }
                if (mouseHeld & LEFT) {
                    if (mousePressed & LEFT) {
                        thisObj->proc(MSG_LPRESS, thisObj, 0); //click message
                        if (thisObj->proc(MSG_WANTFOCUS, thisObj, 0) == D_WANTFOCUS) {
                            thisObj->proc(MSG_GOTFOCUS, thisObj, 0);
                            if (focusObj)
                                focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
                            focusObj = thisObj;
                        }
                    }
                    thisObj->proc(MSG_CLICK, thisObj, 0); //click message
                }
                if (mousePressed & LEFT_REL)
                    thisObj->proc(MSG_LRELEASE, thisObj, 0); //release mouse button message
            }//if mouse within current object region
        }//for each dialog object
        if (!wasMouse) {
            if (mouseObj)
                mouseObj->proc(MSG_LOSTMOUSE, mouseObj, 0);
            mouseObj = NULL;
            if (mousePressed & LEFT) {
                if (focusObj)
                    focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
                focusObj = NULL;
            } //if left pressed
        }//if !mouse
    }//if mouse in region

    //tileset region
    if ((mouseHeld || mousePressed) &&
            (mouse_x > mapBound[1].left) &&
            (mouse_x < mapBound[1].right) &&
            (mouse_y > mapBound[1].up) &&
            (mouse_y < mapBound[1].down)) {
        tileSelection();
    }
    //bottom scrollbar region
    if ((mouseHeld || mousePressed) &&
            (mouse_x > mapBound[3].left) &&
            (mouse_x < mapBound[3].right) &&
            (mouse_y > mapBound[3].up) &&
            (mouse_y < mapBound[3].down) &&
            !focusObj) {
        mapEditDialog[SCROLL].proc(MSG_CLICK, &mapEditDialog[SCROLL], 0);
    }
    //right scrollbar region
    if ((mouseHeld || mousePressed) &&
            (mouse_x > mapBound[4].left) &&
            (mouse_x < mapBound[4].right) &&
            (mouse_y > mapBound[4].up) &&
            (mouse_y < mapBound[4].down) &&
            !focusObj) {
        mapEditDialog[SCROLL+1].proc(MSG_CLICK, &mapEditDialog[SCROLL+1], 0);
    }

    //scroll wheel
    if (mouse_z) {
        mapEditDialog[SCROLL+1].proc(MSG_WHEEL, &mapEditDialog[SCROLL+1], mouse_z * 0x20);
        position_mouse_z (0);
    }

    //map region
    if ((mouse_x > mapBound[5].left) &&
            (mouse_x < mapBound[5].right) &&
            (mouse_y > mapBound[5].up) &&
            (mouse_y < mapBound[5].down)&&
            !focusObj) {
        mapSelection();
        showMapCursor = 1;
    } else {
        showMapCursor = 0;
    }
    //focus object
    if (focusObj) {
        if (mousePressed || mouseHeld)
            focusObj->proc(MSG_CLICK, focusObj, 0);
        if (alphaPressed) {
            focusObj->proc(MSG_CHAR, focusObj, getAlphaChar());
        }
    }

    //undo
    if (!mousePressed &&
            !mouseHeld &&
            key[KEY_LCONTROL] &&
            (alphaPressed & KEYZ)) {
        if (mapIterator != mapHistory.begin()) {
            mapIterator--;
            ((TileBlock*)&*mapIterator)->set();
        }
    }

    //redo
    if (!mousePressed &&
            !mouseHeld &&
            key[KEY_LCONTROL] &&
            (alphaPressed & KEYY)) {
        if (mapIterator != --mapHistory.end()) {
            mapIterator++;
            ((TileBlock*)&*mapIterator)->set();
        }
    }
}

//lazy lazy lazy
void addUndo_map()
{
    while (mapIterator != --mapHistory.end())
        mapHistory.pop_back();
    if (mapHistory.size() >= MAX_REDO)
        mapHistory.pop_front();
    extern int mapX, mapY;
    unsigned char *array = copyLayer(currentLayer);
    TileBlock *tempBlock = new TileBlock(mapX, mapY, array);
    delete[] array;
    tempBlock->layer = currentLayer;
    //xPos and yPos automatically 0
    mapHistory.push_back(*tempBlock);
    mapIterator++;
}



void tileSelection()
{
    if (mousePressed & (LEFT|RIGHT)) {
        selectedTile = mouse_y / 32 * 0x10;
        selectedTile += (mouse_x - mapBound[1].left) / 32;
        selectionX = 1;
        selectionY = 1;
        selectingTiles = 1;
        //make sure we're not out of bounds
        if ((selectedTile / 0x10) >= getTilesetHeight())
            selectedTile = ((getTilesetHeight() - 1) * 0x10) + (selectedTile % 0x10);
        if (mousePressed & RIGHT) {
            tileTypeLoop();
        }
    } else if (selectingTiles) {
        int baseX = 768 + (selectedTile % 0x10) * 32;
        int baseY = (selectedTile / 0x10) * 32;
        int xDif = mouse_x - baseX;
        int yDif = mouse_y - baseY;

        if (xDif >= 0)
            xDif += 32;
        else if (xDif < 0)
            xDif -= 32;
        selectionX = xDif / 32;

        if (yDif >= 0)
            yDif += 32;
        else if (yDif < 0)
            yDif -= 32;
        selectionY = yDif / 32;

        //make sure we're not out of bounds
        if ((selectedTile / 0x10 + selectionY) > getTilesetHeight())
            selectionY = getTilesetHeight() - (selectedTile / 0x10);

    } else if (mousePressed & (LEFT_REL | RIGHT_REL)) {
        int localX, localY, localW, localH;
        localX = selectedTile % 0x10;
        localY = selectedTile / 0x10;
        if (selectionX > 0) {
            localW = selectionX;
        } else {
            localW = -selectionX + 1;
            localX += selectionX;
        }
        if (selectionY > 0) {
            localH = selectionY;
        } else {
            localH = -selectionY + 1;
            localY += selectionY;
        }

        currentSelection.width = localW;
        currentSelection.height = localH;
        unsigned char *array = new unsigned char[localW * localH];

        int currentX = localX;
        int currentY = localY;
        for (int i = 0; i < (localW * localH); i++) {
            array[i] = (currentY * 0x10) + currentX;
            currentX++;
            if (currentX >= (localX + localW)) {
                currentX = localX;
                currentY++;
            }
        } //setup array

        if (currentSelection.tileArray)
            delete[] currentSelection.tileArray;
        currentSelection.tileArray = array;
    }
}


void mapSelection()
{
    int camX, camY;
    getCamera(camX, camY);
    camX = camX / 0x100;
    camY = camY / 0x100; //convert to px

    int mouse_tileX = (mouse_x + camX) / dbgScale;
    int mouse_tileY = (mouse_y + camY) / dbgScale;

    if (mousePressed & (LEFT | RIGHT)) {
        selectingMap = 1;
        if ((drawMode == MODE_RECT) ||
                (drawMode == MODE_COPY)) { //"Rectangle or Copy"
            mapSelect.left = mouse_tileX;
            mapSelect.up = mouse_tileY;
            mapSelect.right = mapSelect.left + 1;
            mapSelect.down = mapSelect.up + 1;
        }
    } else if (selectingMap) {
        switch (drawMode) {
        case MODE_DRAW:
        case MODE_REPLACE:
            mapSelect.left = mouse_tileX;
            mapSelect.up = mouse_tileY;
            mapSelect.right = mapSelect.left + currentSelection.width;
            mapSelect.down = mapSelect.up + currentSelection.height;

            currentSelection.xPos = mapSelect.left;
            currentSelection.yPos = mapSelect.up;
            currentSelection.layer = currentLayer;
            if (drawMode == MODE_DRAW)
                currentSelection.set();
            break;
        case MODE_RECT: //rectangle
        case MODE_COPY: {
            if (mapSelect.left <= mouse_tileX)
                mapSelect.right = ++mouse_tileX;
            else
                mapSelect.right = mouse_tileX;

            if (mapSelect.up <= mouse_tileY)
                mapSelect.down = ++mouse_tileY;
            else
                mapSelect.down = mouse_tileY;
        }
        break;
        case MODE_FILL: {

        }
        break;
        default:
            break;
        };
    } else {
        mapSelect.left = mouse_tileX;
        mapSelect.up = mouse_tileY;
        mapSelect.right = mapSelect.left + currentSelection.width;
        mapSelect.down = mapSelect.up + currentSelection.height;
    }
}

void mapCommit()
{
    switch (drawMode) {
    case MODE_DRAW:
        addUndo_map();
        break;
    case MODE_REPLACE: { //like fill, but ignores boundaries
        int currentTile = getTile(mapSelect.left, mapSelect.up, currentLayer);
        if (currentTile == -1)
            break;
        extern int mapX, mapY;
        //offset the selection and mask-overlay the whole map
        int startX = mapX % currentSelection.width;
        if (startX > 0)
            startX -= currentSelection.width;
        int startY = mapY % currentSelection.height;
        if (startY > 0)
            startY -= currentSelection.height;
        int blockX = 0, blockY = 0;
        for (int y = startY; y < mapY; y++) {
            for (int x = startX; x < mapX; x++) {
                if (getTile(x, y, currentLayer) == currentTile) {
                    setTile(currentSelection.getTile(blockX, blockY), x, y, currentLayer);
                }
                blockX++;
                if (blockX >= currentSelection.width)
                    blockX = 0;
            }//for x
            blockX = 0;
            blockY++;
            if (blockY >= currentSelection.height)
                blockY = 0;
        }//for y
        addUndo_map();
    }//mode_replace
    break;
    case MODE_RECT: {
        currentSelection.layer = currentLayer;
        int temp;
        if (mapSelect.left > mapSelect.right) { //convert to +ve block
            temp = mapSelect.left;
            mapSelect.left = mapSelect.right;
            mapSelect.right = ++temp;
        }

        if (mapSelect.up > mapSelect.down) {
            temp = mapSelect.up;
            mapSelect.up = mapSelect.down;
            mapSelect.down = ++temp;
        }

        for (int y = mapSelect.up; y < mapSelect.down; y += currentSelection.height) {
            for (int x = mapSelect.left; x < mapSelect.right; x += currentSelection.width) {
                currentSelection.xPos = x;
                currentSelection.yPos = y;
                currentSelection.set(mapSelect.right - x, mapSelect.down - y);
            }//for x
        }//for y
    }
    addUndo_map();
    break;
    case MODE_COPY: {
        int temp;
        if (mapSelect.left > mapSelect.right) { //convert to +ve block
            temp = mapSelect.left;
            mapSelect.left = mapSelect.right;
            mapSelect.right = ++temp;
        }

        if (mapSelect.up > mapSelect.down) {
            temp = mapSelect.up;
            mapSelect.up = mapSelect.down;
            mapSelect.down = ++temp;
        }
        int w = currentSelection.width = mapSelect.right - mapSelect.left;
        int h = currentSelection.height = mapSelect.down - mapSelect.up;
        delete[] currentSelection.tileArray;
        currentSelection.tileArray = new unsigned char[w*h];
        int numTiles = 0;
        for (int y = mapSelect.up; y < mapSelect.down; y++) {
            for (int x = mapSelect.left; x < mapSelect.right; x++) {
                currentSelection.tileArray[numTiles] = getTile(x, y, currentLayer);
                numTiles++;
            }//for x
        }//for y
    }//copy
    break;
    case MODE_FILL:
        mapFill(mapSelect.left, mapSelect.up, getTile(mapSelect.left, mapSelect.up, currentLayer));
        addUndo_map();
        break;
    };
}

void mapFill(int x, int y, int tile)
{
    if (tile < 0)
        return; //if the tile selection is invalid..
    int difX = abs(mapSelect.left - x);
    int difY = abs(mapSelect.up - y);
    int blockTile = currentSelection.getTile(difX % currentSelection.width, difY % currentSelection.height);
    if (blockTile == tile)
        return; //avoid the infinite loop stack overflow
    setTile(blockTile, x, y, currentLayer);
    if (getTile(x-1, y, currentLayer) == tile)
        mapFill(x-1, y, tile); //left
    if (getTile(x, y-1, currentLayer) == tile)
        mapFill(x, y-1, tile); //up
    if (getTile(x+1, y, currentLayer) == tile)
        mapFill(x+1, y, tile); //right
    if (getTile(x, y+1, currentLayer) == tile)
        mapFill(x, y+1, tile); //down
}

void sendMapMessage(int message, int c)
{
    for (int i = 0; i < (sizeof mapEditDialog / sizeof mapEditDialog[0]); i++) {
        mapEditDialog[i].proc(message, &mapEditDialog[i], c);
    }
}

int isShowingTypes()
{
    if (mapEditDialog[PROC_MISC].flags & D_SELECTED)
        return 1;
    else
        return 0;
}

void putMapBlock()
{

    /*
    //if -ve convert to a positive-based block
    int tileset_x, tileset_y, map_x, map_y;
    int difX, difY;
    tileset_x = selectedTile % 0x10;
    if (selectionX < 0)
       tileset_x += selectionX;
    tileset_y = selectedTile / 0x10;
    if (selectionY < 0)
       tileset_y += selectionY;

    if (mapSelect.left > mapSelect.right)
    {
       map_x = mapSelect.right;
       difX = mapSelect.left - mapSelect.right + 1;
    } else {
       map_x = mapSelect.left;
       difX = mapSelect.right - mapSelect.left;
    }

    if (mapSelect.up > mapSelect.down)
    {
       map_y = mapSelect.down;
       difY = mapSelect.up - mapSelect.down + 1;
    } else {
       map_y = mapSelect.up;
       difY = mapSelect.down - mapSelect.up;
    }



    for (int y = 0; y < difY; y++)
    {
       for (int x = 0; x < difX; x++)
       {
          unsigned char currentTile = ((tileset_y + y) * 0x10) + tileset_x + x;
          setTile(currentTile, map_x + x, map_y + y, currentLayer);
       }
    }
    */
}

void mapedit_init()
{
    getImageStrings();
    set_dialog_color(mapdataDialog, gui_fg_color, gui_bg_color);
    mapdataDialog[MAPDAT_EDIT].fg = 1;
    mapdataDialog[MAPDAT_EDIT].bg = 0xFFFFFF;
    mapdataDialog[MAPDAT_EDIT+1].fg = 1;
    mapdataDialog[MAPDAT_EDIT+1].bg = 0xFFFFFF;
}



/*************************************************************
               TileBlock
*************************************************************/

TileBlock::TileBlock()
{
    memset(this, 0, sizeof(*this));
}
TileBlock::TileBlock(int w, int h, unsigned char *array)
{
    layer = 0;
    xPos = 0;
    yPos = 0;
    width = w;
    height = h;
    tileArray = new unsigned char[w*h];
    memcpy(tileArray, array, w*h);
}

TileBlock::~TileBlock()
{
    if (tileArray)
        delete[] tileArray;
}

void TileBlock::set()
{
    if (tileArray) {
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                setTile(tileArray[y*width + x], xPos + x, yPos + y, layer);
            }
        }
    }
}

void TileBlock::set(int w, int h)
{
    if (w > width)
        w = width;
    if (h > height)
        h = height;
    if (tileArray) {
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                setTile(tileArray[y*width + x], xPos + x, yPos + y, layer);
            }
        }
    }
}

int TileBlock::getTile(int x, int y)
{
    if (((x || y) < 0) || (x > width) || (y > height))
        return -1;
    return tileArray[y*width + x];
}
#endif
