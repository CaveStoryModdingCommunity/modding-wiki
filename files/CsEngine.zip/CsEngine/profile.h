#pragma once
#ifndef PROFILE_H
#define PROFILE_H

#include "weapon.h"
void setActiveProfileNum(int n);
class Profile
{
public:
    char exists;
    int currentMap;
    int currentMusic;
    int playerX;
    int playerY;
    int unkn_1;
    short maxHealth;
    short whimStars;
    int currentHealth;
    int currentWep;
    int unkn_2;
    int equipFlags;
    int unkn_3;
    short Time;
    int *teleportArray;
    int FLAG;

    Weapon weaponArray[8];
    int *itemArray;
    unsigned char *flagArray;

    Profile(); //constructs a profile from current game state
    Profile(int profileNumber);   //Loads profile n from memory
    ~Profile();

    void save(int profileNumber); //Saves to profile slot n, -1 uses current active slot
};
#endif
