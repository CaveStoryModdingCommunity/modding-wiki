
#include <stdio.h>
#include <cstring>

#include "tsc.h"
#include "weapon.h"
#include "profile.h"
#include "map.h"
#include "music.h"
#include "graphics.h"
#include "player.h"

int activeProfileNum = 0;
void setActiveProfileNum(int n)
{
    activeProfileNum = n;
}

extern Player *player;
extern unsigned char *flags;

Profile::Profile(int fileNum)
{
    char strBuf[32] = {0};
    sprintf(strBuf, "Prof%d.dat", fileNum);
    FILE *theFile = fopen(strBuf, "rb");
    if (!theFile) {
        exists = 0;
        itemArray = NULL;
        flagArray = NULL;
        return;
    }
    exists = 1;
    fseek(theFile, 0x8, 0);
    fread(&currentMap, 4, 12, theFile);
    fread (weaponArray, 4, 40, theFile);
    itemArray = new int[32];
    fread(itemArray, 4, 32, theFile);
    teleportArray = new int[16];
    fread(teleportArray, 4, 16, theFile);
    flagArray = new unsigned char[1000];
    fseek(theFile, 0x21C, 0);
    fread(flagArray, 1, 1000, theFile);

}

Profile::Profile()
{
    exists = 1;
    currentMap = getMapNum();
    currentMusic = getSong();
    playerX = player->xPos;
    playerY = player->yPos;
    unkn_1 = 0;
    maxHealth = player->maxHealth;
    whimStars = 0;
    currentHealth = player->currentHealth;
    currentWep = player->currentWeapon;
    unkn_2 = 0;
    equipFlags = player->equipFlags;
    unkn_3 = 0;
    Time = 0;
    FLAG = 0x47414C46;
    memcpy(weaponArray, player->weaponArray, 0x8C);
    flagArray = new unsigned char[1000];
    memcpy(flagArray, &flags, 1000);
    itemArray = new int[32];
    memcpy(itemArray, player->itemArray, 32*sizeof(int));
    teleportArray = new int[48];
    memset(teleportArray, 0, 0xC0);
}

Profile::~Profile()
{
    if (itemArray)
        delete[] itemArray;
    if (flagArray)
        delete[] flagArray;
    if (teleportArray)
        delete[] teleportArray;
}

void Profile::save(int fileNum)
{
    if (fileNum < 0)
        fileNum = activeProfileNum;
    char filename[32] = {0};
    sprintf(filename, "Prof%d.dat", fileNum);
    FILE *theFile = fopen(filename, "wb");
    fwrite("Do111101", 1, 8, theFile);
    fwrite(&currentMap, 4, 12, theFile);
    fwrite(weaponArray, 4, 40, theFile);
    fwrite(itemArray, 4, 32, theFile);
    fwrite(teleportArray, 4, 48, theFile);
    fwrite(&FLAG, 4, 1, theFile);
    fwrite(flagArray, 1, 1000, theFile);
    fclose(theFile);
}
