
#include "defines.h"
#ifdef EDITOR_MODE

#include <allegro.h>
#include <stdio.h>

#include "weapon.h"
#include "profile.h"
#include "music.h"
#include "graphics.h"
#include "player.h"
#include "tsc.h"
#include "map.h"
#include "sfx.h"
#include "entity.h"
#include "bullet.h"
#include "debug.h"
#include "effect.h"
#include "main.h"
#include "general.h"
#include "mapEdit.h"
#include "pxeEdit.h"

extern Player *player;
extern char gameError[256];
extern ScriptEvent* currentEvent;
extern int gameState;
extern int FPS;
extern int selectedTile;
extern int selectionX;
extern int selectionY;
extern BITMAP *Buffer;

int frameL = 0;
int frameTarget = 0; //759 for editor modes
void setFrameTarget (int target)
{
    frameTarget = target;
}

int debugMode = 0;

/*******************************************************
               Debug State
*******************************************************/
DebugState::DebugState()
{
    for (int i = 0; i < 4; i++)
        mapCopy[i] = NULL;
    typeCopy = NULL;

    mapNum = -1;
}

DebugState::~DebugState()
{
    for (int i = 0; i < 4; i++) {
        if (mapCopy[i])
            delete[] mapCopy[i];
    }
    if (typeCopy)
        delete[] typeCopy;

    eList0.clear();
    eList1.clear();
    eList2.clear();
    eList3.clear();
}

void DebugState::getState()
{
    //debug
    dbgMode = debugMode;
    frameLeft = frameL;
    frameT = frameTarget;

    //player
    if (player)
        pcCopy = *player;

    //map
    extern int currentMap;
    extern int mapX;
    extern int mapY;
    extern unsigned char *mapArray[4];
    extern unsigned char *typeArray;
    mapNum = currentMap;
    for (int i = 0; i < 4; i++) {
        if (mapCopy[i])
            delete[] mapCopy[i];
        if (mapArray[i]) {
            mapCopy[i] = new unsigned char[mapX*mapY];
            memcpy(mapCopy[i], mapArray[i], mapX*mapY);
        }
    }
    /*
       if (typeCopy)
          delete[] typeCopy;
       if (typeArray)
       {
          typeCopy = new unsigned char[256];
          memcpy(typeCopy, typeArray, 256);
       }
    */

    //entity
    using namespace std;
    extern list<Entity> npcLayer0;
    extern list<Entity> npcLayer1;
    extern list<Entity> npcLayer2;
    extern list<Entity> npcLayer3;
    eList0 = npcLayer0;
    eList1 = npcLayer1;
    eList2 = npcLayer2;
    eList3 = npcLayer3;

    //tsc
    extern unsigned char flags[1000];
    memcpy(flagCopy, flags, 1000);
}

void DebugState::setState()
{
    //debug
    debugMode = dbgMode;
    frameL = frameLeft;
    frameTarget = frameT;

    //player
    if (player)
        *player = pcCopy;

    //map
    extern int currentMap;
    extern int mapX;
    extern int mapY;
    extern unsigned char *mapArray[4];
    extern unsigned char *typeArray;
    if (mapNum >= 0) {
        loadMap(mapNum);
        for (int i = 0; i < 4; i++) {
            if (mapArray[i])
                delete[] mapArray[i];
            mapArray[i] = new unsigned char[mapX*mapY];
            memcpy(mapArray[i], mapCopy[i], mapX*mapY);
        }
        /*
           if (typeArray)
              delete[] typeArray;
           typeArray = new unsigned char[256];
           memcpy(typeArray, typeCopy, 256);
        */
    }

    //entity
    using namespace std;
    extern list<Entity> npcLayer0;
    extern list<Entity> npcLayer1;
    extern list<Entity> npcLayer2;
    extern list<Entity> npcLayer3;
    npcLayer0 = eList0;
    eList0.clear();
    npcLayer1 = eList1;
    eList1.clear();
    npcLayer2 = eList2;
    eList2.clear();
    npcLayer3 = eList3;
    eList3.clear();

    //tsc
    extern unsigned char flags[1000];
    memcpy(flags, flagCopy, 1000);
}

/*******************************************************
               Not sure what to call segment
*******************************************************/
void updateFramePos()
{
    int mov;
    if (frameL < frameTarget) {
        mov = (frameTarget - frameL) / 16;
        if (mov > 16)
            mov = 16;
        if (!mov)
            mov++;
        frameL += mov;
    }
    if (frameL > frameTarget) {
        mov = (frameL - frameTarget) / 16;
        if (mov > 16)
            mov = 16;
        if (!mov)
            mov++;
        frameL -= mov;
    }
}

void drawDebugFrame()
{

    Rect frameRect = {0, 0, 1280, 800};
    mainBlit(3, frameRect, frameL, 0);


    if (frameL < 575) {
        //display general info
        renderFPS(frameL + 712, 44, FPS);
        writeNum_l_al(frameL + 770, 74, countNpcs());
        writeNum_l_al(frameL + 778, 104, countEffects());
        writeNum_l_al(frameL + 746, 134, getBgMode());
        if (currentEvent)
            writeNum_l_al(frameL + 762, 164, currentEvent->eventNum);
        else
            writeNum_l_al(frameL + 762, 164, -1);
        writeNum_l_al_hex(frameL + 762, 194, gameState);

        //display error messages
        writeText_al(allegro_error, frameL + 784, 250);
        musicError(frameL + 778, 280);
        writeText_al(gameError, frameL + 760, 310);
    }

    if (frameL < 328) {
        //display player info
        writeNum_l_al(frameL + 974, 44, player->xPos >> 13);
        writeNum_l_al(frameL + 974, 74, player->yPos >> 13);
        writeNum_l_al_hex(frameL + 992, 104, player->collision);
        writeNum_l_al_hex(frameL + 984, 134, player->stateFlags);
        writeNum_l_al_hex(frameL + 984, 164, player->equipFlags);
        writeNum_l_al(frameL + 1132, 44, player->xVel >> 4);
        writeNum_l_al(frameL + 1132, 74, player->yVel >> 4);
        writeNum_l_al(frameL + 998, 194, countBullets());
        extern int keyPressed, keyHeld;
        writeNum_l_al_hex(frameL + 1132, 104, keyPressed);
        writeNum_l_al_hex(frameL + 1132, 134, keyHeld);
    }

    if (debugMode & (DBG_MAP | DBG_MAP_TYPE)) {
        Rect tempRect = {0, 0, 512, 512};
        //draw tileset bitmap
        rectfill(Buffer, 768, 0, 1279, 511, 0x7582B6);
        noMaskBlit(BMP_TILESET, tempRect, 768, 0);
        if (isShowingTypes() || (debugMode == DBG_MAP_TYPE))
            drawTilesetTypes();
        //draw selection rectangle
        int cursorLeft, cursorUp, cursorRight, cursorDown;

        if (selectionX > 0) {
            cursorLeft = 768 + (selectedTile % 0x10) * 32;
            cursorRight = cursorLeft + (selectionX * 32);
        } else {
            cursorLeft = 768 + (selectedTile % 0x10 + selectionX ) * 32;
            cursorRight = 800 + (selectedTile % 0x10) * 32;
        }
        if (selectionY > 0) {
            cursorUp = (selectedTile / 0x10) * 32;
            cursorDown = cursorUp + (selectionY * 32);
        } else {
            cursorUp = (selectedTile/0x10 + selectionY) * 32;
            cursorDown = 32 + (selectedTile / 0x10) * 32;
        }
        rect(Buffer, cursorLeft, cursorUp, cursorRight, cursorDown, 0x00FF00);
    }
}

char *buttonStr[] = {
    "Set X", "Set Y", "Play Song", "Play SFX", "Give Weapon", "Remove Weapon",
    "Set Flag", "Remove Flag", "Max Health", "Current Health", "Run TSC Event",
    "Add item", "Remove item", "Add Equip", "Unequip", "Create Entity", "Goto Map",
    "Close"
};

char *labelStr[] = {
    "xPos", "yPos", "xVel", "yVel", "Event",
    "Direction", "Layer", "State", "Entity Num", "Flag ID",
    "Map Num", "xPos", "yPos", "Event",
    "Invulterable", "Infinite Ammo", "Flying mode", "No Tile collision"
};

#define MAX_BYTES_PER_CHAR 1
#define TEXTLEN 9

char stringBuf[29][(TEXTLEN + 1) * MAX_BYTES_PER_CHAR] = {0};

DIALOG cheatDialog[] = {
    /* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags) (d1)     (d2)  (dp)(dp2) (dp3) */
    //buttons
    {setx_button_proc,   40,   510,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[0], NULL, NULL},
    {sety_button_proc,   40,   545,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[1], NULL, NULL},
    {song_button_proc,   40,   580,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[2], NULL, NULL},
    {sfx_button_proc,    40,   615,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[3], NULL, NULL},
    {giveWep_button_proc,40,   650,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[4], NULL, NULL},
    {takeWep_button_proc,40,   685,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[5], NULL, NULL},
    {setFlag_button_proc,336,  510,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[6], NULL, NULL},
    {unFlag_button_proc, 336,  545,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[7], NULL, NULL},
    {healthM_button_proc,336,  580,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[8], NULL, NULL},
    {healthC_button_proc,336,  615,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[9], NULL, NULL},
    {tsc_button_proc,    336,  650,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[10],NULL, NULL},
    {itemAdd_button_proc,40,   720,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[11],NULL, NULL},
    {itemRem_button_proc,40,   755,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[12],NULL, NULL},
    {equip_button_proc,  336,  685,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[13],NULL, NULL},
    {unequip_button_proc,336,  720,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[14],NULL, NULL},
    {entity_button_proc, 795,  510,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[15],NULL, NULL},
    {map_button_proc,    1080,  510,  120,  20,   0, 0,    0,    0,    0,       0,    buttonStr[16],NULL, NULL},

    //textboxes
#define TEXTBOX 17
    {custom_edit_proc,   180,  510,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[0], NULL, NULL},
    {custom_edit_proc,   180,  545,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[1], NULL, NULL},
    {custom_edit_proc,   180,  580,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[2], NULL, NULL},
    {custom_edit_proc,   180,  615,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[3], NULL, NULL},
    {custom_edit_proc,   180,  650,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[4], NULL, NULL},
    {custom_edit_proc,   180,  685,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[5], NULL, NULL},
    {custom_edit_proc,   476,  510,  120,  20,   0, 0,    0,   D_USER,TEXTLEN, 0,    stringBuf[6], NULL, NULL},
    {custom_edit_proc,   476,  545,  120,  20,   0, 0,    0,   D_USER,TEXTLEN, 0,    stringBuf[7], NULL, NULL},
    {custom_edit_proc,   476,  580,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[8], NULL, NULL},
    {custom_edit_proc,   476,  615,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[9], NULL, NULL},
    {custom_edit_proc,   476,  650,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[10], NULL, NULL},
    {custom_edit_proc,   180,  720,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[11], NULL, NULL},
    {custom_edit_proc,   180,  755,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[12], NULL, NULL},
    {custom_edit_proc,   476,  685,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[13], NULL, NULL},
    {custom_edit_proc,   476,  720,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[14], NULL, NULL},
    //entity fields
#define ENTITYFIELD 32
    {custom_edit_proc,   685,  545,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[15], NULL, NULL},
    {custom_edit_proc,   685,  580,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[16], NULL, NULL},
    {custom_edit_proc,   685,  615,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[17], NULL, NULL},
    {custom_edit_proc,   685,  650,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[18], NULL, NULL},
    {custom_edit_proc,   685,  685,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[19], NULL, NULL},
    {custom_edit_proc,   915, 545,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[20], NULL, NULL},
    {custom_edit_proc,   915, 580,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[21], NULL, NULL},
    {custom_edit_proc,   915, 615,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[22], NULL, NULL},
    {custom_edit_proc,   915, 650,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[23], NULL, NULL},
    {custom_edit_proc,   915, 685,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[24], NULL, NULL},
#define MAPFIELD 42
    {custom_edit_proc,   1085, 550,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[25], NULL, NULL},
    {custom_edit_proc,   1085, 595,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[26], NULL, NULL},
    {custom_edit_proc,   1085, 640,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[27], NULL, NULL},
    {custom_edit_proc,   1085, 685,  120,  20,   0, 0,    0,    0,    TEXTLEN, 0,    stringBuf[28], NULL, NULL},

    //labels
#define LABEL 46
    {d_rtext_proc,       675,  550,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[0], NULL, NULL},
    {d_rtext_proc,       675,  585,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[1], NULL, NULL},
    {d_rtext_proc,       675,  620,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[2], NULL, NULL},
    {d_rtext_proc,       675,  655,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[3], NULL, NULL},
    {d_rtext_proc,       675,  690,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[4], NULL, NULL},
    {d_rtext_proc,       905,  550,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[5], NULL, NULL},
    {d_rtext_proc,       905,  585,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[6], NULL, NULL},
    {d_rtext_proc,       905,  620,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[7], NULL, NULL},
    {d_rtext_proc,       905,  655,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[8], NULL, NULL},
    {d_rtext_proc,       905,  690,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[9], NULL, NULL},
    {d_ctext_proc,       1140, 540,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[10], NULL, NULL},
    {d_ctext_proc,       1140, 585,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[11], NULL, NULL},
    {d_ctext_proc,       1140, 630,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[12], NULL, NULL},
    {d_ctext_proc,       1140, 675,  0,  0,   0, 0,    0,    0,    0,       0,    labelStr[13], NULL, NULL},
    //misc
#define CHEATQUIT 60
    {d_button_proc,      1126, 750,  80,   20,   0, 0,    0,   D_EXIT,0,       0,    buttonStr[17], NULL, NULL },
    {d_keyboard_proc,    0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL},
    {d_yield_proc,       0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL},
    {NULL,               0,    0,    0,    0,    0, 0,    0,    0,    0,       0,    NULL, NULL, NULL}
};

/********************
   DEBUG PROCS
********************/

int setx_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int xPos = str2num((char*)cheatDialog[TEXTBOX].dp);
        player->xPos = xPos << 13;
        int camX = (xPos << 13) - SCREENHALFW;
        if (camX < 0)
            camX = 0;
        setCamera(camX, -1);
        drawAll();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int sety_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int yPos = str2num((char*)cheatDialog[TEXTBOX+1].dp);
        player->yPos = yPos << 13;
        int camY = (yPos << 13) - SCREENHALFH;
        if (camY < 0)
            camY = 0;
        setCamera(-1, camY);
        drawAll();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int song_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int song = str2num((char*)cheatDialog[TEXTBOX+2].dp);
        playSong(song);
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int sfx_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int sfx = str2num((char*)cheatDialog[TEXTBOX+3].dp);
        playSound(sfx);
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int giveWep_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int sfx = str2num((char*)cheatDialog[TEXTBOX+4].dp);

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int takeWep_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int sfx = str2num((char*)cheatDialog[TEXTBOX+5].dp);

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int setFlag_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int flag = str2num((char*)cheatDialog[TEXTBOX+6].dp);
        setFlag(flag);
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int unFlag_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int flag = str2num((char*)cheatDialog[TEXTBOX+7].dp);
        removeFlag(flag);
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int healthM_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int hp = str2num((char*)cheatDialog[TEXTBOX+8].dp);
        if (hp)
            player->maxHealth = hp;
        if (player->maxHealth < player->currentHealth)
            player->currentHealth = hp;
        drawAll();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int healthC_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int hp = str2num((char*)cheatDialog[TEXTBOX+9].dp);
        if (hp)
            player->currentHealth = hp;
        if (player->currentHealth > player->maxHealth)
            player->currentHealth = player->maxHealth;

        drawAll();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int tsc_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int item = str2num((char*)cheatDialog[TEXTBOX+10].dp);

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int itemAdd_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int item = str2num((char*)cheatDialog[TEXTBOX+11].dp);

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int itemRem_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int sfx = str2num((char*)cheatDialog[TEXTBOX+12].dp);

        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int equip_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int flag = str2num((char*)cheatDialog[TEXTBOX+13].dp);
        player->equipFlags |= flag;
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int unequip_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int flag = str2num((char*)cheatDialog[TEXTBOX+14].dp);
        player->equipFlags &= !flag;
        return D_REDRAWME;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int entity_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int fieldArray[10] = {0};
        for (int i = 0; i < 10; i++)
            fieldArray[i] = str2num((char*)cheatDialog[ENTITYFIELD+i].dp);
        createNpc_debug(fieldArray[8], fieldArray[0] << 13, fieldArray[1] << 13, fieldArray[2], fieldArray[4],
                        fieldArray[5], fieldArray[6], fieldArray[9], fieldArray[4], fieldArray[7]);
        oneFrame();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int map_button_proc(int msg, DIALOG *d, int c)
{
    if (msg == MSG_CLICK) {
        d->flags |= D_SELECTED;
        //add action code here
        int fieldArray[4] = {0};
        for (int i = 0; i < 4; i++)
            fieldArray[i] = str2num((char*)cheatDialog[MAPFIELD+i].dp);
        loadMap(fieldArray[0]);
        player->xPos = fieldArray[1] << 13;
        player->yPos = fieldArray[2] << 13;
        runEvent(fieldArray[3]);
        drawAll();
        broadcast_dialog_message(MSG_DRAW, 0);
        return D_O_K;
    } else if (msg == MSG_LRELEASE) {
        d->flags &= !D_SELECTED;
        return D_REDRAWME;
    } else if (msg == MSG_LOSTMOUSE) {
        d->flags &= !D_SELECTED;
        return d_button_proc(msg, d, c);
    } else {
        return d_button_proc(msg, d, c);
    }
    return D_O_K;
}

int custom_edit_proc(int msg, DIALOG *d, int c)
{
    switch (msg) {
    case MSG_CHAR: {
        int tempC = c >> 8;
        if ((tempC >= KEY_0) &&
                (tempC <= KEY_9_PAD) &&
                ((d->d2 != 0) || (*(char*)d->dp != 'x')) ) {
            //char is 0-9
            if (strlen((char*)d->dp) < d->d1) { //if there is room to put more chars
                int size = d->d1;
                char buf[size];
                memset(buf, 0, size);
                char *dest = (char*)d->dp;
                memcpy(buf, dest, d->d2);
                buf[d->d2] = c & 0xFF;
                memcpy(&buf[d->d2+1], &dest[d->d2], size - d->d2); //copy all afte
                memcpy(dest, buf, size);
                d->d2++;
            }
        } else if ((tempC == KEY_X) && (d->d2 == 0) && (*(char*)d->dp != 'x')) {
            //char is x
            if (strlen((char*)d->dp) < d->d1) { //if there is room to put more chars
                char *dest = (char*)d->dp;
                memcpy(&dest[1], dest, d->d1);
                dest[0] = 'x';
                d->d2++;
            }
        } else if (tempC == KEY_BACKSPACE) {
            if (d->d2 > 0) {
                int size = d->d1;
                char buf[size];
                memset(buf, 0, size);
                memcpy(buf, d->dp, d->d2 - 1); //copy all up to the deleted char
                memcpy(&buf[d->d2 - 1], &((char*)d->dp)[d->d2], size - d->d2); //copy all after
                memcpy(d->dp, buf, size);
                d->d2--;
            }
        } else if (tempC == KEY_DEL) {
            int size = d->d1;
            char buf[size];
            memset(buf, 0, size);
            memcpy(buf, d->dp, d->d2); //copy all up to the deleted char
            memcpy(&buf[d->d2], &((char*)d->dp)[d->d2+1], size - d->d2); //copy all after
            memcpy(d->dp, buf, size);
        }
        d->proc(MSG_DRAW, d, 0);
        return D_USED_CHAR;
    }
    case MSG_DRAW: {
        Rect boxRect = {0,0,113,20};
        if (gui_get_screen() == screen)
            screenBlit(4, boxRect, d->x, d->y);
        else
            mainBlit(BMP_DBG2, boxRect, d->x, d->y);
        //write cursor block
        if (d->dp2) {
            int l1, r1;
            l1 = d->x + 4 + (d->d2 * 8);
            r1 = d->y + 5;
            rectfill(gui_get_screen(), l1, r1, l1 + 6, r1 + 8, gui_mg_color);
        }

        //write flag show-er
        if (d->flags & D_USER) {

            int flag = str2num((char*)d->dp);
            int left, top;
            left = d->x + 126;
            top = d->y;
            rectfill(screen, left, top, left + 20, top + 20, 0x9FA7C6);
            if (!checkFlag(flag)) {
                rectfill(gui_get_screen(), left + 2, top + 2, left + 18, top + 18, 0x192142);
            }
        }

        //write text
        gui_textout_ex(gui_get_screen(), (char*)d->dp, d->x + 4, d->y + 6, d->bg, -1, FALSE);
    }
    break;

    case MSG_GOTFOCUS:
        d->dp2 = (void*)1;
        return D_O_K;

    case MSG_LOSTFOCUS:
        d->dp2 = NULL;
        return D_WANTFOCUS;

    case MSG_GOTMOUSE:
        return D_WANTFOCUS;

    case MSG_CLICK:
        return d_edit_proc(msg, d, c);

    case MSG_WANTFOCUS:
        return D_WANTFOCUS;

    case MSG_LPRESS:
    case MSG_RPRESS:
    case MSG_LRELEASE:
    case MSG_RRELEASE:
    case MSG_DCLICK:
        break;
    default:
        return d_edit_proc(msg, d, c);
    };
    return D_O_K;
}

/********************
   MISC DEBUG STUFF
********************/

void debugInit()
{
    /*
    enable_hardware_cursor();
    show_os_cursor(MOUSE_CURSOR_ARROW);
    */
    pxeInit();
    disable_hardware_cursor();
    select_mouse_cursor(MOUSE_CURSOR_ALLEGRO);
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/DEBUG/cursor.bmp", dataDir);
    set_mouse_sprite(load_bitmap(filebuf, NULL));
    show_mouse(screen);
    gui_fg_color = 0x9FA7C6;
    gui_mg_color = 0x475489;
    gui_bg_color = 0x192142;
    mapedit_init();
    set_dialog_color(cheatDialog, gui_fg_color, gui_bg_color);
}

void do_dbg1()
{
    for (int i = 0; i < 29; i++)
        memset(stringBuf[i], 0, TEXTLEN);
    clear_keybuf();
    //fix the frame
    frameL = 0;
    frameTarget = 0;
    drawDebugFrame();
    updateScreen();

    popup_dialog(cheatDialog, -1);
    extern int timer_4, timer_1, escHack;
    timer_1 = 0;
    timer_4 = 0;
    escHack = 50;
}

void forceCloseDialog()
{
    //simulate_keypress(KEY_ESC);
}

#endif
