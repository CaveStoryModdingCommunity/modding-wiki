

#include <stdio.h>
#include <cstring>

#include "defines.h"
#include "graphics.h"
#include "map.h"
#include "weapon.h"
#include "profile.h"
#include "player.h"
#include "entity.h"
#include "general.h"
#include "tsc.h"
#include "bullet.h"
#include "effect.h"
#include "numobj.h"

#ifdef EDITOR_MODE
#include "pxeEdit.h"
#endif

//#define NO_ANIM

unsigned char *mapArray[4] = {NULL};
unsigned char *typeArray = {NULL};
int mapX;
int mapY;
int tAnimTimer;
int numMaps;
int currentMap;
int mnaTimer = 0;

MapData *mapdata = NULL;

void loadMapdata()
{
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/dsmap.bin", dataDir);
    FILE *mapFile = fopen(filebuf, "rb");
    if (!mapFile)
        fatalError("Couldn't load mapdata!");
    fread(&numMaps, 4, 1, mapFile); //read how many maps are in the mapdata

    if (mapdata)
        delete[] mapdata;
    mapdata = new MapData[numMaps];

    fread(mapdata, sizeof(MapData), numMaps, mapFile);

    fclose(mapFile);
}

void saveMapData()
{
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/dsmap.bin", dataDir);
    FILE *mapFile = fopen(filebuf, "wb");
    fwrite(&numMaps, 4, 1, mapFile);
    fwrite(mapdata, sizeof(MapData), numMaps, mapFile);
    fclose(mapFile);
}

void loadMap(unsigned int mapNum)
{
    if (mapNum > numMaps)
        fatalError("Map number out of bounds");
    currentMap = mapNum;
    //clear map arrays
    for (int i = 0; i < 4; i++)
        if (mapArray[i])
            delete[] mapArray[i];
    if (typeArray)
        delete[] typeArray;

    //clear all the things on the map
    clearNpcList();
    clearAllBullet();
    clearAllEffect();
    clearAllNumObj();

    //load tile type data
    typeArray = new unsigned char[256];
    char strBuf[128] = {0};
    sprintf(strBuf, "%s/Stage/", dataDir);
    strcat(strBuf, mapdata[mapNum].tileset);
    strcat(strBuf, ".pxa");
    FILE *pxaFile = fopen(strBuf, "rb");
    if (!pxaFile) {
        strcat(strBuf, " <- Couldn't find(pxa)");
        fatalError(strBuf);
    }
    fread(typeArray, 1, 256, pxaFile);
    fclose(pxaFile);

    //load map data
    memset(strBuf, 0, 128);
    sprintf(strBuf, "%s/Stage/", dataDir);
    strcat(strBuf, mapdata[mapNum].filename);
    strcat(strBuf, ".pxm");
    FILE *pxmFile = fopen(strBuf, "rb");
    if (!pxmFile) {
        strcat(strBuf, " <- Couldn't find(pxm)");
        fatalError(strBuf);
    }
    strBuf[strrchr(strBuf, 'm') - strBuf] = 'e'; //"pxm" -> "pxe"
    PxeFile *pxeFile = new PxeFile(strBuf);
    if (!pxeFile) {
        strcat(strBuf, " <- Couldn't find(pxe)");
        fatalError(strBuf);
    }
#ifdef EDITOR_MODE
    extern PxeFile *pxeGlobal;
    if (pxeGlobal)
        delete pxeGlobal;
    pxeGlobal = pxeFile;
    fillPxeList();
    loadNpcsFromFile(pxeFile);
#else
    //read pxe file
    loadNpcsFromFile(pxeFile);
    delete pxeFile;
#endif
    //read pxm file
    char fileTag[4];
    fread(fileTag, 1, 4, pxmFile);
    fread(&mapX, 2, 1, pxmFile);
    fread(&mapY, 2, 1, pxmFile);
    int arraySize = mapX * mapY;
    if (fileTag[3] == 0x10) { //old pxm type, convert
        for (int i = 0; i < 4; i++) {
            mapArray[i] = new unsigned char [arraySize];
            memset(mapArray[i], 0, arraySize);
        }

        unsigned char *tempArray = new unsigned char[arraySize];
        memset(tempArray, 0, sizeof tempArray);
        fread(tempArray, 1, arraySize, pxmFile);

        for (int i = 0; i < arraySize; i++) {
            unsigned char current = tempArray[i];
            if (getType(current) < 0x20)
                mapArray[1][i] = current;
            if (getType(current) > 0x20)
                mapArray[2][i] = current;
        }
        fclose(pxmFile);
        delete[] tempArray;
#ifdef EDITOR_MODE
        saveMap();
#endif
    } else { //new type
        for (int i = 0; i < 4; i++) {
            mapArray[i] = new unsigned char [arraySize];
            fread(mapArray[i], 1, arraySize, pxmFile);
        }
        fclose(pxmFile);
    }
    //load script
    memset(strBuf, 0, 128);
    sprintf(strBuf, "%s/Stage/", dataDir);
    strcat(strBuf, mapdata[mapNum].filename);
    strcat(strBuf, ".tsc");
    loadScript(strBuf);

    //load the tileset to bitmap file
    memset(strBuf, 0, 128);
    sprintf(strBuf, "%s/Stage/Prt", dataDir);
    strcat(strBuf, mapdata[mapNum].tileset);
    strcat(strBuf, ".png");
    loadTileset(strBuf);

    //load the background to the bitmap
    memset(strBuf, 0, 128);
    sprintf(strBuf, dataDir);
    strcat(strBuf, mapdata[mapNum].bgName);
    strcat(strBuf, ".png");
    loadBG(strBuf);
    setCamLimit(mapX, mapY);
    setBgMode(mapdata[mapNum].scrollType);

    //load the npc tilesets to the game
    memset(strBuf, 0, 128);
    char strBuf2[128] = {0};
    sprintf(strBuf, "%s/npc/Npc", dataDir);
    sprintf(strBuf2, "%s/npc/Npc", dataDir);
    strcat(strBuf, mapdata[mapNum].npc1);
    strcat(strBuf2, mapdata[mapNum].npc2);
    strcat(strBuf, ".png");
    strcat(strBuf2, ".png");
    loadNpcSets(strBuf, strBuf2);
}

void saveMap()
{
    if (!mapArray[0])
        return;
    char header[4] = {0x50, 0x58, 0x4D, 0x20}; //"PXM(0x20)"
    char buffer[64] = {0};
    sprintf(buffer, "%s/npc/Npc", dataDir);
    strcat(buffer, mapdata[currentMap].filename);
    strcat(buffer, ".pxm");

    FILE *output = fopen(buffer, "wb");
    fwrite(header, 1, 4, output);
    fwrite(&mapX, 2, 1, output);
    fwrite(&mapY, 2, 1, output);
    for (int i = 0; i < 4; i++)
        fwrite(mapArray[i], 1, mapX * mapY, output);

    fclose(output);

    sprintf(buffer, "%s/dsmap.bin\0", dataDir);
    output = fopen(buffer, "r+b");
    fseek(output, 4 + currentMap*sizeof(MapData), SEEK_SET);
    fwrite(&mapdata[currentMap], sizeof(MapData), 1, output);

    fclose(output);
}

void updateTileAnim()
{
#ifndef NO_ANIM
    tAnimTimer++;
    if (tAnimTimer >= 32)
        tAnimTimer = 0;
#endif
}
void drawTiles(int layer)
{
    for (int y = 0; y < mapY; y++) {
        for (int x = 0; x < mapX; x++) {
            Rect tempRect;
            int tileNum = getTile(x,y, layer);
            int tileType = getType(tileNum);
            if (tileType) {
#ifdef EDITOR_MODE
                extern int debugMode, dbgScale;
                tempRect.left = (tileNum%16)*32;
                tempRect.up = (tileNum >> 4)*32;
                tempRect.right = tempRect.left + 32;
                tempRect.down = tempRect.up + 32;
                if ((tileType % 0x10) > 7) {
                    int frame = tAnimTimer / 8;
                    tempRect.up += frame*32;
                    tempRect.down += frame*32;

                }
                int scaleFactor;
                if (debugMode & (DBG_MAP | DBG_MAP_TYPE | DBG_PXE)) {
                    scaleFactor = 0x100*dbgScale;
                    cameraBlit_scale(2, tempRect, x*scaleFactor, y*scaleFactor, ((float)dbgScale / 0x20));
                } else {
                    scaleFactor = 0x2000;
                    cameraBlit(2, tempRect, x*scaleFactor - 0x1000, y*scaleFactor - 0x1000);
                }
#else
                tempRect.left = (tileNum%16)*32;
                tempRect.up = (tileNum >> 4)*32;
                tempRect.right = tempRect.left + 32;
                tempRect.down = tempRect.up + 32;
                if ((tileType % 0x10) > 7) {
                    int frame = tAnimTimer / 8;
                    tempRect.up += frame*32;
                    tempRect.down += frame*32;

                }
                int scaleFactor = 0x2000;
                cameraBlit(2, tempRect, x*scaleFactor - 0x1000, y*scaleFactor - 0x1000);
#endif
            }
        }
    }
}

void drawMNA()
{
    if (mnaTimer > 0) {
        writeText(mapdata[currentMap].mapName, 280, 60);
        writeText(mapdata[currentMap].mapName, 281, 60);
        mnaTimer--;
    }
}

int getTile(int x, int y, unsigned int layer)
{
    if (layer > 3)
        return -1;
    if ((x < 0) || (y < 0) || (x >= mapX) || (y >= mapY))
        return -1;
    int loc = x + (y*mapX);
    return mapArray[layer][loc];
}

void setTile(unsigned char tileNum, int x, int y, unsigned int layer)
{
    if (layer > 3)
        return;
    if ((x < 0) || (x >= mapX))
        return;
    if ((y < 0) || (y >= mapY))
        return;
    mapArray[layer][y*mapX + x] = tileNum;
}

int getType (int tileNum)
{
    if (tileNum < 256) return typeArray[tileNum];
    else return -1;
}
int getType (int x, int y)
{
    return getType(getTile(x, y, 2));
}

int getMapNum()
{
    return currentMap;
}

void softQuake(int duration)
{

}

void hardQuake(int duration)
{

}

void setMapNameTimer(int time)
{
    mnaTimer = time;
}

#ifdef EDITOR_MODE
void drawTileTypes()
{
    for (int y = 0; y < mapY; y++) {
        for (int x = 0; x < mapX; x++) {
            Rect tempRect;
            extern int debugMode, dbgScale;

            int tileNum = getTile(x,y, 2);
            int tileType = getType(tileNum);
            tempRect.left = (tileType%16)*32;
            tempRect.up = (tileType >> 4)*32;
            tempRect.right = tempRect.left + 32;
            tempRect.down = tempRect.up + 32;

            int scaleFactor = 0x100 * dbgScale;
            cameraBlit_trans_scale(BMP_DBG3, tempRect,
                                   x*scaleFactor,
                                   y*scaleFactor,
                                   128, ((float)dbgScale / 0x20));
        }
    }
}

void drawTilesetTypes()
{
    for (int i = 0; i < (getTilesetHeight() * 0x10); i++) {
        Rect tempRect;
        unsigned char type = typeArray[i];
        tempRect.left = (type % 0x10) * 0x20;
        tempRect.up = (type / 0x10) * 0x20;
        tempRect.right = tempRect.left + 0x20;
        tempRect.down = tempRect.up + 0x20;
        int xPos = 768 + (i % 0x10) * 0x20;
        int yPos = i / 0x10 * 0x20;

        transBlit(BMP_DBG3, tempRect, xPos, yPos, 128);
    }
}

void setType(unsigned char tileNum, unsigned char tileType)
{
    typeArray[tileNum] = tileType;
}

unsigned char *copyLayer(int layer)
{
    unsigned char *array = new unsigned char[mapX * mapY];
    memcpy(array, mapArray[layer], mapX * mapY);
    return array;
}

char *getMapFilename(int mapNum)
{
    if (mapNum < 0)
        mapNum = currentMap;
    char *buffer = new char[64];
    memset(buffer, 0, 64);
    sprintf(buffer, "%s/Stage/", dataDir);
    strcat(buffer, mapdata[mapNum].filename);
    strcat(buffer, ".pxe");
    return buffer;
}
#endif
