
#include "bitManip.h"

void writeBits(char *buf, int value, int numBits, long pos)
{
	//setup information
	int theByte = (int) (pos / 8);
	int theBit = (int) (pos % 8);
	int valCopy = value;
	int bitsWritten = 0;
	
	while (numBits > 0)
	{
		//determine # of bits we can write to the current byte
		int ourBits = 8 - theBit;
		numBits -= ourBits;
		
		//setup the bit thing
		//shift right to the first unwritten bit
		valCopy >>= bitsWritten;
		//shift left so the first bit is @ theBit
		valCopy <<= theBit;
		//mask only first 8 bits
		valCopy &= 0xFF;
		//apply to the buffer
		buf[theByte] |= (char) valCopy;
		
		//increase the write position by # bits written
		pos += (long) ourBits;
		bitsWritten += ourBits;
		//update information
		theByte = (int) (pos / 8);
		theBit = (int) (pos % 8);
		valCopy = value;
	}//while there are bits to write
}//writeBits(byte[], int, int, long)

int readBits(char *buf, int numBits, long pos)
{
	int bitsWritten = 0;
	int result = 0;
	
	while (bitsWritten < numBits)
	{
		//get the byte/bit
		int theByte = (int) (pos / 8);
		int theBit = (int) (pos % 8);
		int ourBits = 8 - theBit;
		
		//read n bits
		//store bit in temp variable
		int tempVal = buf[theByte];
		tempVal &= 0xFF;
		//remove all unneeded bits
		tempVal >>= theBit;
		//shift left to the next bit to be written
		tempVal <<= bitsWritten;			
		//write to result
		result |= tempVal;
		
		//update pos
		pos += ourBits;
		bitsWritten += ourBits;
	}
	//incase of negatives, mask to appropriate # bits
	int mask = -1;
	mask >>= (32 - numBits);
	result &= mask;
	return result;
}
