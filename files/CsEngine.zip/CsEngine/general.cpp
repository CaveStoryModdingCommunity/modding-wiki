
#include <allegro.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <winalleg.h>
#include <stdio.h>

#include "defines.h"
#include "graphics.h"
#include "general.h"

int keyPressed = 0;
int keyHeld = 0;
int key_buffer = 0;

int alphaPressed = 0;
int alphaHeld = 0;
int alpha_buffer = 0;

int numPressed = 0;
int numHeld = 0;
int num_buffer = 0;

char gameError[256];

char dataDir[64];

#ifdef EDITOR_MODE
int mousePressed = 0;
int mouseHeld = 0;
int mouse_buffer = 0;

int currentTab;
#endif

int random (int low, int high)
{
    int difference = high - low;
    return (rand() % (++difference) + low);
}

void setError(const char *string)
{
    strcpy(gameError, string);
    FILE *debug = fopen("debug.txt", "a");
    fprintf(debug, "Message: %s\n", string);
    fclose(debug);
#ifdef VERBOSE
    printf("Message: %s\n", string);
#endif
}

void fatalError(const char *string)
{
    char buffer[128] = "Fatal error: ";
    FILE *error = fopen("debug.txt", "a");
    fprintf(error, "Fatal error: %s", string);
    fclose(error);

    strcat(buffer, string);
    allegro_message(buffer);
    exit(2);
}

int str2num (const char *str)
{
    int result = 0;
    int size = strlen(str);
    int numRead = 0;
    if (str[0] == 'x') {
        for (int i = --size; i >= 1; i--) {
            result += (str[i] - '0') << (numRead*4);
            numRead++;
            if (numRead > 8)
                break;
        }
    } else {
        for (int i = --size; i >= 0; i--) {
            result += (str[i] - '0') * (int)(pow(10, numRead) + 0.1);
            numRead++;
            if (numRead > 10)
                break;
        }
    }
    return result;
}

void updateKeys()
{
    int temp = key_buffer;
    key_buffer = 0;

    if (key[KEY_UP])
        key_buffer |= KEYUP;
    if (key[KEY_LEFT])
        key_buffer |= KEYLEFT;
    if (key[KEY_RIGHT])
        key_buffer |= KEYRIGHT;
    if (key[KEY_DOWN])
        key_buffer |= KEYDOWN;
    if (key[KEY_Z])
        key_buffer |= KEYJUMP;
    if (key[KEY_Y])
        key_buffer |= KEYY;
    if (key[KEY_U])
        key_buffer |= KEYU;
    if (key[KEY_I])
        key_buffer |= KEYI;
    if (key[KEY_O])
        key_buffer |= KEYO;
    if (key[KEY_Q])
        key_buffer |= KEYQ;
    if (key[KEY_X])
        key_buffer |= KEYSHOOT;
    if (key[KEY_ESC])
        key_buffer |= KEYESC;
    if (key[KEY_P])
        key_buffer |= KEYP;
    if (key[KEY_F1])
        key_buffer |= KEYF1;
    if (key[KEY_F2])
        key_buffer |= KEYF2;
    if (key[KEY_F3])
        key_buffer |= KEYF3;

    temp = ~(key_buffer & temp);
    keyPressed = (key_buffer & temp);
    keyHeld = key_buffer;

#ifdef EDITOR_MODE
    temp = mouse_buffer;
    mouse_buffer = 0;

    if (mouse_b & LEFT)
        mouse_buffer |= LEFT;
    if (mouse_b & 2)
        mouse_buffer |= RIGHT;

    if (temp & LEFT)
        if (!(mouse_buffer & LEFT))
            mouse_buffer |= LEFT_REL;
    if (temp & RIGHT)
        if (!(mouse_buffer & RIGHT))
            mouse_buffer |= RIGHT_REL;

    temp = ~(mouse_buffer & temp);
    mousePressed = (mouse_buffer & temp);
    mouseHeld = mouse_buffer;
#endif
}

void updateKeys_a()
{
    int temp = alpha_buffer;
    alpha_buffer = 0;

    for (int i = 1; i < 27; i++) { //read letter keys
        if (key[i])
            alpha_buffer |= 1 << (i - 1);
    }

    temp = ~(alpha_buffer & temp);
    alphaPressed = (alpha_buffer & temp);
    alphaHeld = alpha_buffer;

    temp = num_buffer;
    num_buffer = 0;

    if (key[KEY_0])
        num_buffer |= KEY0;
    if (key[KEY_1])
        num_buffer |= KEY1;
    if (key[KEY_2])
        num_buffer |= KEY2;
    if (key[KEY_3])
        num_buffer |= KEY3;
    if (key[KEY_4])
        num_buffer |= KEY4;
    if (key[KEY_5])
        num_buffer |= KEY5;
    if (key[KEY_6])
        num_buffer |= KEY6;
    if (key[KEY_7])
        num_buffer |= KEY7;
    if (key[KEY_8])
        num_buffer |= KEY8;
    if (key[KEY_9])
        num_buffer |= KEY9;
    if (key[KEY_0_PAD])
        num_buffer |= KEY0;
    if (key[KEY_1_PAD])
        num_buffer |= KEY1;
    if (key[KEY_2_PAD])
        num_buffer |= KEY2;
    if (key[KEY_3_PAD])
        num_buffer |= KEY3;
    if (key[KEY_4_PAD])
        num_buffer |= KEY4;
    if (key[KEY_5_PAD])
        num_buffer |= KEY5;
    if (key[KEY_6_PAD])
        num_buffer |= KEY6;
    if (key[KEY_7_PAD])
        num_buffer |= KEY7;
    if (key[KEY_8_PAD])
        num_buffer |= KEY8;
    if (key[KEY_9_PAD])
        num_buffer |= KEY9;

    if (key[KEY_BACKSPACE])
        num_buffer |= KEYBKSP;
    if (key[KEY_DEL])
        num_buffer |= KEYDEL;
    if (key[KEY_MINUS])
        num_buffer |= KEYMINUS;
    if (key[KEY_EQUALS])
        num_buffer |= KEYEQUALS;

    temp = ~(num_buffer & temp);
    numPressed = (num_buffer & temp);
    numHeld = num_buffer;
}

#ifdef EDITOR_MODE
int getAlphaChar()
{
    int result = 0;
    int bit;
    for (int i = 0; i < ('z'-'a'); i++) {
        bit = 1 << i;
        if (alphaPressed & bit) {
            result = 'a' + i;
            if (key[KEY_LSHIFT] | key[KEY_RSHIFT])
                result -= 0x20;
            result |= (i+KEY_A) << 8; //scancode (hopefully)
        }
    }
    return result;
}

int getMiscChar()
{
    int result = 0;
    int bit;
    for (int i = 0; i < 10; i++) {
        bit = 1 << i;
        if (numPressed & bit) {
            result = '0' + i;
            result |= (i+KEY_0) << 8;
        }
    }
    if (!result) {
        if (numPressed & KEYBKSP)
            return KEY_BACKSPACE << 8;
        if (numPressed & KEYDEL)
            return KEY_DEL << 8;
    }
    return result;
}

void checkTabs()
{
    //check keypress
    if (numPressed & KEYMINUS) {
        currentTab--;
        if (currentTab < 0)
            currentTab = NUMTAB - 1;
    }
    if (numPressed & KEYEQUALS) {
        currentTab++;
        if (currentTab >= NUMTAB)
            currentTab = 0;
    }
    //check mouseclicks
    if (mouse_x > 1252) {
        for (int i = NUMTAB-1; i >= 0; i--) {
            if ((mousePressed & LEFT) &&
                    (mouse_y > 770-i*24) &&
                    (mouse_y < 794-i*24)) {
                currentTab = i;
            }
        }
    }
}

void drawTabs()
{
    Rect tabRect = {0, 36, 16, 52};
    for (int i = NUMTAB - 1; i >= 0; i--) {
        tabRect.left = i*16;
        if (currentTab == i)
            tabRect.left += NUMTAB*16;
        tabRect.right = tabRect.left + 16;
        mainBlit(BMP_DBG2, tabRect, 1254, 774-i*24);
    }
}
#endif
