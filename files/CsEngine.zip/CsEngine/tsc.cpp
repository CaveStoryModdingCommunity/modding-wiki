
#include <string.h>
#include <stdio.h>
#include "entity.h"
#include "tsc.h"
#include "general.h"
#include "map.h"
#include "weapon.h"
#include "profile.h"
#include "player.h"
#include "defines.h"
#include "music.h"
#include "sfx.h"
#include "defines.h"

#include <vector>

using namespace std;
//globals
unsigned char flags[1000] = {0};
unsigned char skipflags[10] = {0};

int tscState = 0; //What mode is the TSC Engine in
char msgState = 0; //flags for the status of the message box display
/*
   0x1  - Top of screen (else bottom)
   0x2  - TUR
   0x4  - CAT
   0x8  - SAT
   0x10 -
   0x20 -
   0x40 - Displaying box
   0x80 - Displaying text
*/
int textDelay = 0; //general script delay; paces letter output
int eventPos = 0; //what command of the TSC Event are we up to
int waitTimer = 0; //delay script
int blipTimer = 0; //used for flashing text position marker @ NOD
int msgPos = 0; //used to indicated location in a string currently being read in MSG
int textRow = 0; //row (0, 1 or 2) of text output
int textColumn = 0; //column of text output
int ynTarget = 0; // where to jump to if yes/no jump gives "No"
char selectionCursor = 0; //stores the state of the Yes/No cursor
int currentFace = 0; //which face is being displayed in the textbox
int facePos = 0; //x offset for the face slider
int textOffset = 0; //y offset for scrolling text
bool showOverlay = false; //do we show the overlay for the <IMG command
char fadeTimer; //timer for fade operations
char fadeState; //state of fade; 0 = no fade 1 = fading in 2 = fading out 4 = black screen
short fadeDirection; //direction of the fade
vector<char> fadeVec; //holds misc. data pertaining to the fade

bool scriptLoadError = false;

vector<ScriptEvent> headScript;
vector<ScriptEvent> stageScript;
vector<ScriptEvent> itemScript;

ScriptEvent *currentEvent = NULL;

//imported globals
extern char gameState;
extern int keyHeld;
extern int keyPressed;
extern Player *player;

void renderTextbox()
{
    Rect clipRect;
    Rect frameRect = {0,0,488,16};
    //get xBase and yBase
    int xBase = 77;
    int yBase, i;
    if (msgState & 1) //if the message box is at the top
        yBase = 40;
    else
        yBase = 348;

    clipRect.left = xBase + 17;
    clipRect.right = clipRect.left + 460;
    clipRect.up = yBase + 16;
    clipRect.down = clipRect.up + 96;
    if (msgState & 0x40) { //show the box
        mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase);
        frameRect.up += 16;
        frameRect.down += 16;
        for (i = 1; i < 7; i++)
            mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + i*16);
        frameRect.up += 16;
        frameRect.down += 16;
        mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + 0x70);
    }
    if (msgState & 0x80) { //show the text
        frameRect.up = 0;
        frameRect.right = 460;
        frameRect.down = 20;
        int currentRow; //current row -> the current top row

        if (textRow > 2)
            currentRow = (textRow-2)%4;
        else
            currentRow = 0;
        //offset the text from the face
        int txtOff = 20;
        if (currentFace)
            txtOff += 100;
        //update the face position
        if (facePos < 90)
            facePos += 8;
        //update text position
        if (textOffset > 0)
            textOffset -= 3;
        for (i = 0; i < 4; i++) { //for each thing
            clipBlit(BMP_TEXT1 + currentRow, frameRect, xBase + txtOff, yBase + (LINE_SPACING * i) - 12 + textOffset, clipRect);
            currentRow++;
            if (currentRow > 3)
                currentRow = 0;
        } //for each text obj.
        //render the face
        if (currentFace) {
            int faceSize = 96;
            frameRect.left = (currentFace % 6) * faceSize;
            frameRect.up = (currentFace / 6) * faceSize;
            frameRect.right = frameRect.left + faceSize;
            frameRect.down = frameRect.up + faceSize;
            clipBlit(BMP_FACE, frameRect, facePos, yBase + 12, clipRect);
        }
        //render cursor blip
        frameRect.left = 476;
        frameRect.up = 64;
        frameRect.right = frameRect.left + 12;
        frameRect.down = frameRect.up + 20;
        if ((blipTimer++%20)>12) {
            if (tscState == 2) {
                int lastRow = textRow;
                if (lastRow > 2)
                    lastRow = 2;
                int blipX = FONT_WIDTH * (textColumn+1) + xBase + txtOff;
                int blipY = yBase + lastRow * LINE_SPACING + 20 + textOffset;
                clipBlit(BMP_TEXTBOX, frameRect, blipX, blipY, clipRect);
            }
        }
    }//if showText


    //render yes/no box
    if (tscState == 6) {
        frameRect.left = 304;
        frameRect.up = 96;
        frameRect.right = frameRect.left + 160;
        frameRect.down = frameRect.up + 64;

        mainBlit(BMP_TEXTBOX, frameRect, 434, 288);

        frameRect.left = 224;
        frameRect.up = 176;
        frameRect.right = frameRect.left + 32;
        frameRect.down = frameRect.up + 32;

        mainBlit(BMP_TEXTBOX, frameRect, 422 + 80*selectionCursor, 308);
    }
}

void renderInvoFrame()
{
    Rect frameRect = {0,0,488,16};
    //get xBase and yBase
    int xBase = 77;
    int yBase, i;
    yBase = 16;
    //render the upper box
    mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase);
    frameRect.up += 16;
    frameRect.down += 16;
    for (i = 1; i < 17; i++)
        mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + i*16);
    frameRect.up += 16;
    frameRect.down += 16;
    mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + 0x110);
    //render arms and items icons
    frameRect.left = 160;
    frameRect.up = 96;
    frameRect.right = frameRect.left + 128;
    frameRect.down = frameRect.up + 16;
    mainBlit(BMP_TEXTBOX, frameRect, 96, 32);
    frameRect.up += 16;
    frameRect.down += 16;
    mainBlit(BMP_TEXTBOX, frameRect, 96, 134);
}

void renderFade()
{
    switch (fadeState) {
    case 0: //no fade
        break;
    case 1: //fading in
        drawFade(0, fadeDirection, fadeTimer);
        break;
    case 2: //fading out
        drawFade(1, fadeDirection, fadeTimer);
        break;
    case 4: //full black
        drawFade(2, fadeDirection, 0);
        break;
    default:
        break;
    }
    if (fadeTimer > 0) {
        fadeTimer--;
        if (fadeTimer == 0) {
            if (fadeState & 1)
                fadeState = 0;
            if (fadeState & 2)
                fadeState = 4;
        }
    }
}

void renderImgOverlay()
{
    if (showOverlay) {
        Rect fsr = {0, 0, 640, 480};
        mainBlit(BMP_IMG, fsr, 0, 0);
    }
}

void prepFade()
{
    fadeVec.clear();
    int x, y;
    int n = 0;
    int fadeDir = fadeDirection % 10;
    int fadeType = fadeDirection / 10 % 10;
    switch (fadeType) {
    case 0:
    case 1: { //classic fade types
        switch(fadeDir) {
        case 0: //fade from left (classic)
            fadeVec.resize(VISIBLE_TILES_X*VISIBLE_TILES_Y);
            for (y = 0; y < VISIBLE_TILES_Y; y++)
                for (x = 0; x < VISIBLE_TILES_X; x++) {
                    fadeVec[y*VISIBLE_TILES_X + x] = x;
                }
            break;
        case 1: //fade from top (classic)
            fadeVec.resize(VISIBLE_TILES_X*VISIBLE_TILES_Y);
            for (x = 0; x < VISIBLE_TILES_X; x++)
                for (y = 0; y < VISIBLE_TILES_Y; y++) {
                    fadeVec[y*VISIBLE_TILES_X + x] = y;
                }
            break;
        case 2: //fade from right (classic)
            fadeVec.resize(VISIBLE_TILES_X*VISIBLE_TILES_Y);
            for (y = 0; y < VISIBLE_TILES_Y; y++) {
                for (x = VISIBLE_TILES_X - 1; x >= 0; x--) {
                    fadeVec[y*VISIBLE_TILES_X + x] = n ;
                    n++;
                }
                n = 0;
            }
            break;
        case 3: //fade from bottom (classic)
            fadeVec.resize(VISIBLE_TILES_X*VISIBLE_TILES_Y);
            for (x = 0; x < VISIBLE_TILES_X; x++) {
                for (y = VISIBLE_TILES_Y - 1; y <= 0; y--) {
                    fadeVec[y*VISIBLE_TILES_X + x] = n;
                    n++;
                }
                n = 0;
            }
            break;
        case 4: //fade from center (classic)
            fadeVec.resize(VISIBLE_TILES_X*VISIBLE_TILES_Y);
            for (int y = 0; y < VISIBLE_TILES_X; y++)
                for (int x = 0; x < VISIBLE_TILES_X; x++) {
                    n = 9001;
                    if (x < n)
                        n = x;
                    if (y < n)
                        n = y;
                    if (VISIBLE_TILES_X-1 - y < n)
                        n = VISIBLE_TILES_X - 1 - y;
                    if (VISIBLE_TILES_X-1 - x < n)
                        n = VISIBLE_TILES_X - 1 - x;
                    if ((y-2 >= 0) && (y-2 < VISIBLE_TILES_Y))
                        fadeVec[(y-2)*VISIBLE_TILES_X + x] = n*2;
                }
            break;
        default:
            printf("Invalid fade direction");
            break;
        } //fade direction switch
        break;
    } //classic fade type
    case 2: { //bar fades
        switch (fadeDir) {
        case 0:
        case 2:
            fadeVec.resize(SCREENH / 0x1000);
            for (n = 0; n < SCREENH / 0x1000; n++)
                fadeVec[n] = random(8, 18);
            break;
        case 1:
        case 3:
            fadeVec.resize(SCREENW / 0x1000);
            for (n = 0; n < SCREENW / 0x1000; n++)
                fadeVec[n] = random(11, 21);
            break;
        }
    } //bar fade type
    } //fade type switch
}

void fillFlags(unsigned char* flagData)
{
    memcpy(flags, flagData, 1000);
}

void clearFlags()
{
    memset(flags, 0, 1000);
}

int checkFlag(unsigned int flagNum)
{
    if (flagNum >= 8000)
        return 0;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    if (flags[theByte] & theBit)
        return 1;
    else
        return 0;
}

void setFlag(unsigned int flagNum)
{
    if (flagNum >= 8000)
        return;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    flags[theByte] |= theBit;
}

void removeFlag(unsigned int flagNum)
{
    if (flagNum >= 8000)
        return ;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    flags[theByte] &= !theBit;
}

bool checkSkip(unsigned int flagNum)
{
    if (flagNum >= 80)
        return 0;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    if (skipflags[theByte] & theBit)
        return 1;
    else
        return 0;
}

void setSkip(unsigned int flagNum)
{
    if (flagNum >= 80)
        return;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    skipflags[theByte] |= theBit;
}

void removeSkip(unsigned int flagNum)
{
    if (flagNum >= 80)
        return ;
    int theByte = flagNum / 8;
    int theBit = 1 << flagNum % 8;
    skipflags[theByte] &= !theBit;
}


void runEvent(int tscNum)
{
    gameState |= 5;
    tscState = 1;
    msgPos = 0;
    //search for event in head
    vector<ScriptEvent>::iterator it;
    for (it = headScript.begin(); it != headScript.end(); it++) {
        if (((ScriptEvent)*it).eventNum == tscNum) {
            currentEvent = &*it;
            eventPos = 0;
            return;
        }
    }
    if (!(gameState & 0x20)) { //if we aren't in inventory mode
        //search for event in stage script
        for (it = stageScript.begin(); it != stageScript.end(); it++) {
            if (((ScriptEvent)*it).eventNum == tscNum) {
                currentEvent = &*it;
                eventPos = 0;
                return;
            }
        }
    } else { //if we are on the inventory screen
        //search for event in item script
        for (it = itemScript.begin(); it != itemScript.end(); it++) {
            if (((ScriptEvent)*it).eventNum == tscNum) {
                currentEvent = &*it;
                eventPos = 0;
                return;
            }
        }
    }
    //the event doesn't be found!
    tscState = 0;
}

void gotoEvent(int eve)
{
    //search for event in head
    vector<ScriptEvent>::iterator it;
    for (it = headScript.begin(); it != headScript.end(); it++) {
        if (((ScriptEvent)*it).eventNum == eve) {
            currentEvent = &*it;
            eventPos = 0;
            return;
        }
    }
    if (!(gameState & 0x20)) { //if we aren't in inventory mode
        //search for event in stage script
        for (it = stageScript.begin(); it != stageScript.end(); it++) {
            if (((ScriptEvent)*it).eventNum == eve) {
                currentEvent = &*it;
                eventPos = 0;
                return;
            }
        }
    } else { //if we are on the inventory screen
        //search for event in item script
        for (it = itemScript.begin(); it != itemScript.end(); it++) {
            if (((ScriptEvent)*it).eventNum == eve) {
                currentEvent = &*it;
                eventPos = 0;
                return;
            }
        }
    }
    //the event doesn't be found!
    tscState = 0;
}

int scriptParser()
{
    int stopParse;

    switch (tscState) {
    case 2: //NOD
        if (keyPressed & (KEYSHOOT | KEYJUMP))
            tscState = 1;
        break;
    case 3: //unk
        break;
    case 4: //WAI
        if (waitTimer != 9999) {
            textDelay++;
            if (textDelay >= waitTimer) {
                tscState = 1;
                blipTimer = 0;
            }
        }
        break;
    case 5: //fade in or out
        if (!(fadeState & 3)) { //if not fading in or out
            tscState = 1;
            blipTimer = 0;
        }
        break;
    case 6: //Yes/No selection
        if (keyPressed & (KEYLEFT | KEYRIGHT)) {
            playSound(SFX_menu_move);
            selectionCursor ^= 1;
        }
        if (keyPressed & (KEYJUMP | KEYSHOOT)) {
            playSound(SFX_menu_select);
            if (selectionCursor)
                runEvent(ynTarget);
            tscState = 1;
        }
        break;
    case 7: //Wait until Standing
        if (player->collision & 8) {
            tscState = 1;
            blipTimer = 0;
        }
        break;
    case 1:
        textDelay++;
        if (!(gameState & 2)) {
            if ((keyHeld & (KEYSHOOT | KEYJUMP)) || (msgState & 8))
                textDelay += 4;
        }
        if (textDelay < 4)
            break;
        textDelay = 0;
        stopParse = 0;
        while (!stopParse) {
            if (eventPos >= currentEvent->commandList.size()) {
                tscState = 0;
                msgState = 0;
                gameState |= 2;
                gameState &= -0x11;
                player->stateFlags &= -2;
                break;
            }
            TscCommand currentCommand = currentEvent->commandList[eventPos];
            switch(currentCommand.command) {
            case TSC_AE_PLUS:
                break;
            case TSC_AM_PLUS:
                break;
            case TSC_AM_MINUS:
                break;
            case TSC_AMJ:
                break;
            case TSC_ANP:
                entityAction(0, currentCommand.parameters);
                break;
            case TSC_BOA:
                break;
            case TSC_BSL:
                break;
            case TSC_CAT:
                msgState |= 0x4;
                break;
            case TSC_CIL:
                break;
            case TSC_CLO:
                msgState &= -0xC1;
                break;
            case TSC_CLR:
                clearBitmap(BMP_TEXT1);
                clearBitmap(BMP_TEXT2);
                clearBitmap(BMP_TEXT3);
                clearBitmap(BMP_TEXT4);
                textColumn = 0;
                textRow = 0;
                break;
            case TSC_CMP:
                setTile(currentCommand.parameters[2],
                        currentCommand.parameters[0],
                        currentCommand.parameters[1],
                        3);
                createSmoke(currentCommand.parameters[0], currentCommand.parameters[1], 0x1000, 2);
                playSound(SFX_fx_block_destroy);
                break;
            case TSC_CMU:
                playSong(currentCommand.parameters[0]);
                break;
            case TSC_CNP:
                entityAction(1, currentCommand.parameters);
                break;
            case TSC_CPS:
                break;
            case TSC_CRE:
                break;
            case TSC_CSS:
                break;
            case TSC_DNA:
                entityAction(9, currentCommand.parameters);
                break;
            case TSC_DNP:
                entityAction(2, currentCommand.parameters);
                break;
            case TSC_ECJ:
                if (entityAction(10, currentCommand.parameters)) {
                    gotoEvent(currentCommand.parameters[1]);
                    stopParse = true;
                }
                break;
            case TSC_END:
                tscState = 0;
                msgState = 0;
                gameState |= 2;
                gameState &= -0x11;
                player->stateFlags &= -2;
                stopParse = true;
                break;
            case TSC_EQ_PLUS:
                player->addEquip(currentCommand.parameters[0]);
                break;
            case TSC_EQ_MINUS:
                player->removeEquip(currentCommand.parameters[0]);
                break;
            case TSC_ESC:
                return 2;
                break;
            case TSC_EVE:
                gotoEvent(currentCommand.parameters[0]);
                stopParse = true;
                break;
            case TSC_FAC:
                if (currentFace != currentCommand.parameters[0]) {
                    currentFace = currentCommand.parameters[0];
                    facePos = -6;
                }
                break;
            case TSC_FAI:
                //FAI/FAO lasts 36 frames
                tscState = 5;
                fadeTimer = FADE_DURATION;
                fadeState = 1;
                fadeDirection = currentCommand.parameters[0];
                prepFade();
                stopParse = true;
                break;
            case TSC_FAO:
                tscState = 5;
                fadeTimer = FADE_DURATION;
                fadeState = 2;
                fadeDirection = currentCommand.parameters[0];
                prepFade();
                stopParse = true;
                break;
            case TSC_FL_PLUS:
                setFlag(currentCommand.parameters[0]);
                break;
            case TSC_FL_MINUS:
                removeFlag(currentCommand.parameters[0]);
                break;
            case TSC_FLA:
                break;
            case TSC_FLJ:
                if (checkFlag(currentCommand.parameters[0])) {
                    gotoEvent(currentCommand.parameters[1]);
                    stopParse = true;
                    eventPos--;
                }
                break;
            case TSC_FMU:
                break;
            case TSC_FOB:
                break;
            case TSC_FOM:
                player->giveCamera(currentCommand.parameters[0]);
                break;
            case TSC_FON:
                entityAction(3, currentCommand.parameters);
                break;
            case TSC_FRE:
                gameState |= 2;
                gameState &= -0x11;
                break;
            case TSC_GIT:
                break;
            case TSC_HMC:
                player->stateFlags |= 2;
                break;
            case TSC_IMG:
                if (showOverlay = (bool)currentCommand.parameters[0]) {
                    char nametag[10] = "Timg\0\0\0\0\0";
                    memcpy(&nametag[4], &currentCommand.string[4], 4);
                    loadOverlayImage(nametag);
                }
                break;
            case TSC_INI:
                break;
            case TSC_INP: {
                Entity *ent = createNpc(currentCommand.parameters[0],
                                        currentCommand.parameters[1] << 13,
                                        currentCommand.parameters[2] << 13,
                                        0,
                                        0,
                                        currentCommand.parameters[3],
                                        NULL,
                                        2);
                ent->flags |= 0x8000;
            }
            break;
            case TSC_IT_PLUS:
                player->addItem(currentCommand.parameters[0]);
                break;
            case TSC_IT_MINUS:
                player->removeItem(currentCommand.parameters[0]);
                break;
            case TSC_ITJ:
                if(player->hasItem(currentCommand.parameters[0])) {
                    gotoEvent(currentCommand.parameters[1]);
                    stopParse = true;
                    eventPos--;
                }
                break;
            case TSC_KEY:
                gameState &= -3;
                break;
            case TSC_LDP:
                break;
            case TSC_LI_PLUS:
                player->heal(currentCommand.parameters[0]);
                break;
            case TSC_ML_PLUS:
                player->addHealth(currentCommand.parameters[0]);
                break;
            case TSC_MLP:
                break;
            case TSC_MM0:
                player->xVel = 0;
                break;
            case TSC_MNA:
                setMapNameTimer(120);
                break;
            case TSC_MNP:
                entityAction(4, currentCommand.parameters);
                break;
            case TSC_MOV:
                player->moveTo(currentCommand.parameters[0], currentCommand.parameters[1]);
                break;
            case TSC_MPJ:
                break;
            case TSC_MP_PLUS:
                break;
            case TSC_MS2: //invis msg box @ top of screen
            case TSC_MS3: //visible msg box @ top of screen
            case TSC_MSG:
                textColumn = 0;
                textRow = 0;
                currentFace = 0;
                clearBitmap(BMP_TEXT1);
                clearBitmap(BMP_TEXT2);
                clearBitmap(BMP_TEXT3);
                clearBitmap(BMP_TEXT4);
                if (currentCommand.command == TSC_MSG)
                    msgState |= 0xC0;
                else if (currentCommand.command == TSC_MS2)
                    msgState |= 0x81;
                else
                    msgState |= 0xC1;
                break;
            case TSC_MYB:
                entityAction(5, currentCommand.parameters);
                break;
            case TSC_MYD:
                break;
            case TSC_NCJ:
                if (entityAction(16, currentCommand.parameters)) {
                    gotoEvent(currentCommand.parameters[1]);
                    stopParse = true;
                }
                break;
            case TSC_NOD:
                tscState = 2;
                stopParse = true;
                break;
            case TSC_NUM:
                break;
            case TSC_PRI:
                gameState |= 0x10;
                gameState &= -3;
                break;
            case TSC_PS_PLUS:
                break;
            case TSC_QUA:
                break;
            case TSC_RMU:

                break;
            case TSC_RND: {
                unsigned short *p_var = (unsigned short *)&flags[0x2F0];
                int r = random(currentCommand.parameters[0], currentCommand.parameters[1]);
                p_var[currentCommand.parameters[2]] = r;
            }
            break;
            case TSC_SAT:
                msgState |= 0x8;
                break;
            case TSC_SIL:
                break;
            case TSC_SK_PLUS:
                setSkip(currentCommand.parameters[0]);
                break;
            case TSC_SK_MINUS:
                removeSkip(currentCommand.parameters[0]);
                break;
            case TSC_SKJ:
                if (checkSkip(currentCommand.parameters[0])) {
                    gotoEvent(currentCommand.parameters[1]);
                    stopParse = true;
                    eventPos--;
                }
                break;
            case TSC_SLP:
                break;
            case TSC_SMC:
                player->stateFlags &= -3;
                break;
            case TSC_SMP:
                break;
            case TSC_SNP:
                createNpc(currentCommand.parameters[0],
                          currentCommand.parameters[1] << 13,
                          currentCommand.parameters[2] << 13,
                          0,
                          0,
                          currentCommand.parameters[3],
                          NULL,
                          2);
                break;
            case TSC_SOU:
                playSound(convertFxNum(currentCommand.parameters[0]));
                break;
            case TSC_SPS:
                break;
            case TSC_SSS:
                break;
            case TSC_STC:
                break;
            case TSC_SVP: {
                Profile *p = new Profile();
                p->save(-1);
                delete p;
            }
            break;
            case TSC_TAM:
                break;
            case TSC_TRA:
                loadMap(currentCommand.parameters[0]);
                player->moveTo(currentCommand.parameters[2], currentCommand.parameters[3]);
                setCamera((currentCommand.parameters[2] << 13) - SCREENHALFW, (currentCommand.parameters[3] << 13) - SCREENHALFH);
                gotoEvent(currentCommand.parameters[1]);
                gameState &= -0x11;
                stopParse = true;
                break;
            case TSC_TUR:
                msgState |= 2;
                break;
            case TSC_UNI:
                break;
            case TSC_UNJ:
                break;
            case TSC_VAR: {
                unsigned short *p_var = (unsigned short *)&flags[0x2F0];
                p_var[currentCommand.parameters[0]] = currentCommand.parameters[1];
            }
            break;
            case TSC_VAZ: {
                unsigned short *p_var = (unsigned short *)&flags[0x2F0];
                for (int i = 0; i < currentCommand.parameters[1]; i++)
                    p_var[currentCommand.parameters[0] + i] = 0;
            }
            break;
            case TSC_VAJ: {
                unsigned short *p_var = (unsigned short *)&flags[0x2F0];
            }
            break;
            case TSC_VAO: {
                unsigned short *p_var = (unsigned short *)&flags[0x2F0];
            }
            break;
            case TSC_WAI:
                waitTimer = currentCommand.parameters[0];
                tscState = 4;
                stopParse = true;
                break;
            case TSC_WAS:
                tscState = 7;
                stopParse = true;
                break;
            case TSC_YNJ:
                selectionCursor = 0;
                ynTarget = currentCommand.parameters[0];
                tscState = 6;
                playSound(SFX_menu_prompt);
                stopParse = true;
                break;
            case TSC_ZAM:
                break;
            case TSC_CIN:
                break;
            case TSC_STR:
                break;
            case TSC_CTB:
                break;
            case TSC_NO:
                if (msgState & 0x80) {
                    char next[4];
                    bool wide = false;
                    next[0] = currentCommand.string[msgPos];
                    next[1] = currentCommand.string[msgPos+1];
                    next[3] = '\0';
                    if(next[0] & 0x80){
                        next[2] = '\0';
                        wide = true;
                    }
                    else{
                        next[1] = '\0';
                    }
                    if (next[0] != 0) {
                        textColumn++;
                        if (next[0] == '\r' || next[0] == '\n') { //carriage return
                            msgPos += 2;
                            textRow++;
                            if (textRow > 2) { //if we need scrolling
                                textOffset = LINE_SPACING;
                                clearBitmap(BMP_TEXT1 + (textRow+1)%4);
                            }
                            textColumn = 0;
                        } else { //character
                            playSound(SFX_fx_msg);
                            writeTextTo(BMP_TEXT1 + (textRow+1)%4, next, textColumn*FONT_WIDTH, 0);
                            if(wide){
                                textColumn++;
                                msgPos+=2;
                            }
                            else{
                                msgPos++;
                            }
                        }
                        eventPos--; //keep the event position where it is until we're done here
                    } else { //reached the end of the string
                        msgPos = 0;
                    }
                }
                stopParse = true;
                break;
            default:
                //couldn't find the TSC command
                char errorStr[32] = {0};
                sprintf(errorStr, "TSC Command not found: %d", currentEvent->commandList[eventPos].command);
                setError(errorStr);
            }
            eventPos++;
        } //massive hideous TSC parser block
        break;
    default:
        textDelay = 4;
        break;
    }
    if (tscState)
        gameState |= 4;
    else
        gameState &= -5;
    return 1;
}

void loadGlobalTsc()
{
    int fileSize, filePos;
    int key = 0;
    unsigned char *rawData;
    unsigned char numBuf[5] = {0};
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/Head.tsc", dataDir);

    //head.tsc
    FILE *head = fopen(filebuf, "rb");
    if (!head)
        fatalError("Can't find head.tsc!");
    fseek(head, 0, SEEK_END);
    fileSize = ftell(head);
    fseek(head, fileSize/2, SEEK_SET);
    fread(&key, 1, 1, head); //get "encryption" value
    //read the file
    fseek(head, 0, SEEK_SET);
    rawData = new unsigned char[fileSize];
    fread(rawData, 1, fileSize, head);
    fclose(head);
    //decrypt
    for (int i = 0; i < fileSize; i++) {
        if (i != fileSize/2)
            rawData[i] -= key;
    }
    //parse
    scriptLoadError = false;
    for (int filePos = 0; filePos < fileSize;) {
        //find an event number
        if (rawData[filePos] == '#') {
            headScript.push_back(ScriptEvent(rawData, fileSize, filePos)); //create the new event with desired number
            if (filePos >= fileSize)
                break;

        } else {
            filePos++;
        }
    }
    if (scriptLoadError) {
        setError("Parse error in: Head.tsc");
    }
    delete[] rawData;

    //armsitem.tsc
    sprintf(filebuf, "%s/ArmsItem.tsc", dataDir);
    FILE *armsItem = fopen(filebuf, "rb");
    if (!armsItem)
        fatalError("Can't find ArmsItem.tsc!");
    fseek(armsItem, 0, SEEK_END);
    fileSize = ftell(armsItem);
    fseek(armsItem, fileSize/2, SEEK_SET);
    fread(&key, 1, 1, armsItem); //get "encryption" value
    //read the file
    fseek(armsItem, 0, SEEK_SET);
    rawData = new unsigned char[fileSize];
    fread(rawData, 1, fileSize, armsItem);
    fclose(armsItem);
    //decrypt
    for (int i = 0; i < fileSize; i++) {
        if (i != fileSize/2)
            rawData[i] -= key;
    }
    //parse
    scriptLoadError = false;
    for (int filePos = 0; filePos < fileSize;) {
        //find an event number
        if (rawData[filePos] == '#') {
            itemScript.push_back(ScriptEvent(rawData, fileSize, filePos)); //create the new event with desired number
            if (filePos >= fileSize)
                break;

        } else {
            filePos++;
        }
    }
    if (scriptLoadError) {
        setError("Parse error in: ArmsItem.tsc");
    }
    delete[] rawData;
}

void loadScript(const char *filename)
{
    unsigned char *rawData;
    int fileSize, filePos;
    int key;

    stageScript.clear();

    FILE *script = fopen(filename, "rb");
    if (!script) {
        char buf[128] = "Can't find ";
        strcat(buf, filename);
        fatalError(buf);
    }
    fseek(script, 0, SEEK_END);
    fileSize = ftell(script);
    fseek(script, fileSize/2, SEEK_SET);
    fread(&key, 1, 1, script); //get "encryption" value
    //read the file
    fseek(script, 0, SEEK_SET);
    rawData = new unsigned char[fileSize];
    fread(rawData, 1, fileSize, script);
    fclose(script);
    //decrypt
    for (int i = 0; i < fileSize; i++) {
        if (i != fileSize/2)
            rawData[i] -= key;
    }
    //parse
    scriptLoadError = false;
    for (int filePos = 0; filePos < fileSize;) {
        //find an event number
        if (rawData[filePos] == '#') {
            stageScript.push_back(ScriptEvent(rawData, fileSize, filePos)); //create the new event with desired number
            if (filePos >= fileSize)
                break;

        } else {
            filePos++;
        }
    }
    if (scriptLoadError) {
        char errorBuf[64] = {0};
        sprintf(errorBuf, "Parse error in: %s", filename);
        setError(errorBuf);
    }
}

/*******************************************************
               Script Event
*******************************************************/

ScriptEvent::ScriptEvent()
{
    eventNum = -1;
}

ScriptEvent::ScriptEvent(unsigned char *data, int maxLen, int &offset)
{
    bool eventError = false;
    char numBuf[5] = {0};
    //read event number
    memcpy(numBuf, &data[++offset], 4);
    eventNum = str2num(numBuf);
    offset += 6; //account for newline
    //read commands
    while(offset < maxLen) {
        TscCommand *newCommand = new TscCommand(data, maxLen, offset);
        commandList.push_back(*newCommand);
        if (!strcmp(newCommand->string, "???"))
            eventError = true;
        int comNum = newCommand->command;
        if ((comNum == TSC_EVE) ||
                (comNum == TSC_TRA) ||
                (comNum == TSC_END) ||
                (comNum == TSC_ESC)) {
            delete newCommand;
            break;
        } else {
            delete newCommand;
        }
    }
    if (eventError) {
        char errorBuf[32] = {0};
        sprintf(errorBuf, "In event: %d", eventNum);
        setError(errorBuf);
    }
}

/****************************************************
               Tsc Event
****************************************************/

TscCommand::TscCommand(unsigned char *data, int maxLen, int &offset)
{
    if (data[offset] != '<') { //string data
        int strLength = 0;
        while (data[offset] != '<') {
            strLength++;
            offset++;
        }
        string = new char[strLength+1];
        memcpy(string, &data[offset-strLength], strLength);
        string[strLength] = 0;
        command = TSC_NO;
    } else {
        char tag[5] = {0};
        memcpy(tag, &data[offset], 4);//copy the tag to buffer for reading
        //big ol' manual checker
        if (!strcmp(tag, "<AE+"))
            command = TSC_AE_PLUS;
        else if (!strcmp(tag, "<AM+"))
            command = TSC_AM_PLUS;
        else if (!strcmp(tag, "<AM-"))
            command = TSC_AM_MINUS;
        else if (!strcmp(tag, "<AMJ"))
            command = TSC_AMJ;
        else if (!strcmp(tag, "<ANP"))
            command = TSC_ANP;
        else if (!strcmp(tag, "<BOA"))
            command = TSC_BOA;
        else if (!strcmp(tag, "<BSL"))
            command = TSC_BSL;
        else if (!strcmp(tag, "<CAT"))
            command = TSC_CAT;
        else if (!strcmp(tag, "<CIL"))
            command = TSC_CIL;
        else if (!strcmp(tag, "<CLO"))
            command = TSC_CLO;
        else if (!strcmp(tag, "<CLR"))
            command = TSC_CLR;
        else if (!strcmp(tag, "<CMP"))
            command = TSC_CMP;
        else if (!strcmp(tag, "<CMU"))
            command = TSC_CMU;
        else if (!strcmp(tag, "<CNP"))
            command = TSC_CNP;
        else if (!strcmp(tag, "<CPS"))
            command = TSC_CPS;
        else if (!strcmp(tag, "<CRE"))
            command = TSC_CRE;
        else if (!strcmp(tag, "<CSS"))
            command = TSC_CSS;
        else if (!strcmp(tag, "<DIE"))
            command = TSC_DIE;
        else if (!strcmp(tag, "<DNA"))
            command = TSC_DNA;
        else if (!strcmp(tag, "<DNP"))
            command = TSC_DNP;
        else if (!strcmp(tag, "<ECJ"))
            command = TSC_ECJ;
        else if (!strcmp(tag, "<END"))
            command = TSC_END;
        else if (!strcmp(tag, "<EQ+"))
            command = TSC_EQ_PLUS;
        else if (!strcmp(tag, "<EQ-"))
            command = TSC_EQ_MINUS;
        else if (!strcmp(tag, "<ESC"))
            command = TSC_ESC;
        else if (!strcmp(tag, "<EVE"))
            command = TSC_EVE;
        else if (!strcmp(tag, "<FAC"))
            command = TSC_FAC;
        else if (!strcmp(tag, "<FAI"))
            command = TSC_FAI;
        else if (!strcmp(tag, "<FAO"))
            command = TSC_FAO;
        else if (!strcmp(tag, "<FL+"))
            command = TSC_FL_PLUS;
        else if (!strcmp(tag, "<FL-"))
            command = TSC_FL_MINUS;
        else if (!strcmp(tag, "<FLA"))
            command = TSC_FLA;
        else if (!strcmp(tag, "<FLJ"))
            command = TSC_FLJ;
        else if (!strcmp(tag, "<FMU"))
            command = TSC_FMU;
        else if (!strcmp(tag, "<FOB"))
            command = TSC_FOB;
        else if (!strcmp(tag, "<FOM"))
            command = TSC_FOM;
        else if (!strcmp(tag, "<FON"))
            command = TSC_FON;
        else if (!strcmp(tag, "<FRE"))
            command = TSC_FRE;
        else if (!strcmp(tag, "<GIT"))
            command = TSC_GIT;
        else if (!strcmp(tag, "<HMC"))
            command = TSC_HMC;
        else if (!strcmp(tag, "<IMG"))
            command = TSC_IMG;
        else if (!strcmp(tag, "<INI"))
            command = TSC_INI;
        else if (!strcmp(tag, "<INP"))
            command = TSC_INP;
        else if (!strcmp(tag, "<IT+"))
            command = TSC_IT_PLUS;
        else if (!strcmp(tag, "<IT-"))
            command = TSC_IT_MINUS;
        else if (!strcmp(tag, "<ITJ"))
            command = TSC_ITJ;
        else if (!strcmp(tag, "<KEY"))
            command = TSC_KEY;
        else if (!strcmp(tag, "<LDP"))
            command = TSC_LDP;
        else if (!strcmp(tag, "<LIV"))
            command = TSC_LIV;
        else if (!strcmp(tag, "<LI+"))
            command = TSC_LI_PLUS;
        else if (!strcmp(tag, "<ML+"))
            command = TSC_ML_PLUS;
        else if (!strcmp(tag, "<MLP"))
            command = TSC_MLP;
        else if (!strcmp(tag, "<MM0"))
            command = TSC_MM0;
        else if (!strcmp(tag, "<MNA"))
            command = TSC_MNA;
        else if (!strcmp(tag, "<MNP"))
            command = TSC_MNP;
        else if (!strcmp(tag, "<MOV"))
            command = TSC_MOV;
        else if (!strcmp(tag, "<MPJ"))
            command = TSC_MPJ;
        else if (!strcmp(tag, "<MP+"))
            command = TSC_MP_PLUS;
        else if (!strcmp(tag, "<MS2"))
            command = TSC_MS2;
        else if (!strcmp(tag, "<MS3"))
            command = TSC_MS3;
        else if (!strcmp(tag, "<MSG"))
            command = TSC_MSG;
        else if (!strcmp(tag, "<MYB"))
            command = TSC_MYB;
        else if (!strcmp(tag, "<MYD"))
            command = TSC_MYD;
        else if (!strcmp(tag, "<NCJ"))
            command = TSC_NCJ;
        else if (!strcmp(tag, "<NOD"))
            command = TSC_NOD;
        else if (!strcmp(tag, "<NUM"))
            command = TSC_NUM;
        else if (!strcmp(tag, "<PRI"))
            command = TSC_PRI;
        else if (!strcmp(tag, "<PS+"))
            command = TSC_PS_PLUS;
        else if (!strcmp(tag, "<QUA"))
            command = TSC_QUA;
        else if (!strcmp(tag, "<RMU"))
            command = TSC_RMU;
        else if (!strcmp(tag, "<SAT"))
            command = TSC_SAT;
        else if (!strcmp(tag, "<SIL"))
            command = TSC_SIL;
        else if (!strcmp(tag, "<SK+"))
            command = TSC_SK_PLUS;
        else if (!strcmp(tag, "<SK-"))
            command = TSC_SK_MINUS;
        else if (!strcmp(tag, "<SKJ"))
            command = TSC_SKJ;
        else if (!strcmp(tag, "<SLP"))
            command = TSC_SLP;
        else if (!strcmp(tag, "<SMC"))
            command = TSC_SMC;
        else if (!strcmp(tag, "<SMP"))
            command = TSC_SMP;
        else if (!strcmp(tag, "<SNP"))
            command = TSC_SNP;
        else if (!strcmp(tag, "<SOU"))
            command = TSC_SOU;
        else if (!strcmp(tag, "<SPS"))
            command = TSC_SPS;
        else if (!strcmp(tag, "<SSS"))
            command = TSC_SSS;
        else if (!strcmp(tag, "<STC"))
            command = TSC_STC;
        else if (!strcmp(tag, "<SVP"))
            command = TSC_SVP;
        else if (!strcmp(tag, "<TAM"))
            command = TSC_TAM;
        else if (!strcmp(tag, "<TRA"))
            command = TSC_TRA;
        else if (!strcmp(tag, "<TUR"))
            command = TSC_TUR;
        else if (!strcmp(tag, "<UNI"))
            command = TSC_UNI;
        else if (!strcmp(tag, "<UNJ"))
            command = TSC_UNJ;
        else if (!strcmp(tag, "<VAR"))
            command = TSC_VAR;
        else if (!strcmp(tag, "<VAJ"))
            command = TSC_VAJ;
        else if (!strcmp(tag, "<VAO"))
            command = TSC_VAO;
        else if (!strcmp(tag, "<VAZ"))
            command = TSC_VAZ;
        else if (!strcmp(tag, "<RND"))
            command = TSC_RND;
        else if (!strcmp(tag, "<WAI"))
            command = TSC_WAI;
        else if (!strcmp(tag, "<WAS"))
            command = TSC_WAS;
        else if (!strcmp(tag, "<YNJ"))
            command = TSC_YNJ;
        else if (!strcmp(tag, "<ZAM"))
            command = TSC_ZAM;
        else if (!strcmp(tag, "<CTB"))
            command = TSC_CTB;
        else if (!strcmp(tag, "<CIN"))
            command = TSC_CIN;
        else if (!strcmp(tag, "<STR"))
            command = TSC_STR;
        else
            command = TSC_NO;
        if (command == TSC_NO) {
            char errorStr[64] = {0};
            sprintf(errorStr, "ScriptCompile: Unrecognized Command %s", tag);
            setError(errorStr);
            scriptLoadError = true;
            offset += 4;
            return;
        }
        //setup parameters
        int numParam;
        switch (command) {
            //four-parameter commands
        case TSC_MNP:
        case TSC_SNP:
        case TSC_TRA:
            numParam = 4;
            break;
            //three-parameter commands
        case TSC_ANP:
        case TSC_CMP:
        case TSC_CNP:
        case TSC_INP:
        case TSC_TAM:
        case TSC_RND:
        case TSC_CIN:
            numParam = 3;
            break;
            //two-parameter commands
        case TSC_AM_PLUS:
        case TSC_AMJ:
        case TSC_ECJ:
        case TSC_FLJ:
        case TSC_FON:
        case TSC_ITJ:
        case TSC_MOV:
        case TSC_NCJ:
        case TSC_PS_PLUS:
        case TSC_SKJ:
        case TSC_SMP:
        case TSC_VAR:
        case TSC_VAO:
        case TSC_VAZ:
        case TSC_STR:
            numParam = 2;
            break;
            //single-parameter commands:
        case TSC_AM_MINUS:
        case TSC_BOA:
        case TSC_BSL:
        case TSC_CMU:
        case TSC_DIE:
        case TSC_DNA:
        case TSC_DNP:
        case TSC_EQ_PLUS:
        case TSC_EQ_MINUS:
        case TSC_EVE:
        case TSC_FAC:
        case TSC_FAI:
        case TSC_FAO:
        case TSC_FL_PLUS:
        case TSC_FL_MINUS:
        case TSC_FOM:
        case TSC_GIT:
        case TSC_IMG:
        case TSC_IT_PLUS:
        case TSC_IT_MINUS:
        case TSC_LI_PLUS:
        case TSC_ML_PLUS:
        case TSC_MPJ:
        case TSC_MP_PLUS:
        case TSC_MYB:
        case TSC_MYD:
        case TSC_NUM:
        case TSC_QUA:
        case TSC_SIL:
        case TSC_SK_PLUS:
        case TSC_SK_MINUS:
        case TSC_SOU:
        case TSC_SSS:
        case TSC_UNI:
        case TSC_UNJ:
        case TSC_WAI:
        case TSC_YNJ:
            numParam = 1;
            break;
        default:
            numParam = 0;
        }//switch (command)
        parameters = new int[numParam];
        int strLength = 4;
        if (numParam)
            strLength += numParam * 5 -1;
        string = new char[4 + strLength +1];
        memset(string, 0, strLength +1);
        memcpy(string, &data[offset], strLength);
        offset += 4;
        for (int i = 0; i < numParam; i++) {
            memcpy(tag, &data[offset], 4);
            parameters[i] = str2num(tag);
            offset += 5;
            if (i == (numParam-1))
                offset--;
        }
    }
}

TscCommand::TscCommand(const TscCommand &other)
{
    command = other.command;
    if (other.string) {
        string = new char[strlen(other.string)+1];
        strcpy(string, other.string);
    } else {
        string = NULL;
    }
    int numParam;
    switch (command) {
        //four-parameter commands
    case TSC_MNP:
    case TSC_SNP:
    case TSC_TRA:
        numParam = 4;
        break;
        //three-parameter commands
    case TSC_ANP:
    case TSC_CMP:
    case TSC_CNP:
    case TSC_INP:
    case TSC_TAM:
    case TSC_RND:
    case TSC_CIN:
        numParam = 3;
        break;
        //two-parameter commands
    case TSC_AM_PLUS:
    case TSC_AMJ:
    case TSC_ECJ:
    case TSC_FLJ:
    case TSC_FON:
    case TSC_ITJ:
    case TSC_MOV:
    case TSC_NCJ:
    case TSC_PS_PLUS:
    case TSC_SKJ:
    case TSC_SMP:
    case TSC_VAR:
    case TSC_VAO:
    case TSC_VAZ:
    case TSC_STR:
        numParam = 2;
        break;
        //single-parameter commands:
    case TSC_AM_MINUS:
    case TSC_BOA:
    case TSC_BSL:
    case TSC_CMU:
    case TSC_DIE:
    case TSC_DNA:
    case TSC_DNP:
    case TSC_EQ_PLUS:
    case TSC_EQ_MINUS:
    case TSC_EVE:
    case TSC_FAC:
    case TSC_FAI:
    case TSC_FAO:
    case TSC_FL_PLUS:
    case TSC_FL_MINUS:
    case TSC_FOM:
    case TSC_GIT:
    case TSC_IMG:
    case TSC_IT_PLUS:
    case TSC_IT_MINUS:
    case TSC_LI_PLUS:
    case TSC_ML_PLUS:
    case TSC_MPJ:
    case TSC_MP_PLUS:
    case TSC_MYB:
    case TSC_MYD:
    case TSC_NUM:
    case TSC_QUA:
    case TSC_SIL:
    case TSC_SK_PLUS:
    case TSC_SK_MINUS:
    case TSC_SOU:
    case TSC_SSS:
    case TSC_UNI:
    case TSC_UNJ:
    case TSC_WAI:
    case TSC_YNJ:
        numParam = 1;
        break;
    default:
        numParam = 0;
    }//switch (command)
    parameters = new int[numParam];
    for (int i = 0; i < numParam; i++) {
        parameters[i] = other.parameters[i];
    }
}

TscCommand& TscCommand::operator=(const TscCommand &other)
{
    command = other.command;
    if (other.string) {
        string = new char[strlen(other.string)+1];
        strcpy(string, other.string);
    } else {
        string = NULL;
    }
    int numParam;
    switch (command) {
        //four-parameter commands
    case TSC_MNP:
    case TSC_SNP:
    case TSC_TRA:
        numParam = 4;
        break;
        //three-parameter commands
    case TSC_ANP:
    case TSC_CMP:
    case TSC_CNP:
    case TSC_INP:
    case TSC_TAM:
    case TSC_RND:
    case TSC_CIN:
        numParam = 3;
        break;
        //two-parameter commands
    case TSC_AM_PLUS:
    case TSC_AMJ:
    case TSC_ECJ:
    case TSC_FLJ:
    case TSC_FON:
    case TSC_ITJ:
    case TSC_MOV:
    case TSC_NCJ:
    case TSC_PS_PLUS:
    case TSC_SKJ:
    case TSC_SMP:
    case TSC_VAR:
    case TSC_VAO:
    case TSC_VAZ:
    case TSC_STR:
        numParam = 2;
        break;
        //single-parameter commands:
    case TSC_AM_MINUS:
    case TSC_BOA:
    case TSC_BSL:
    case TSC_CMU:
    case TSC_DIE:
    case TSC_DNA:
    case TSC_DNP:
    case TSC_EQ_PLUS:
    case TSC_EQ_MINUS:
    case TSC_EVE:
    case TSC_FAC:
    case TSC_FAI:
    case TSC_FAO:
    case TSC_FL_PLUS:
    case TSC_FL_MINUS:
    case TSC_FOM:
    case TSC_GIT:
    case TSC_IMG:
    case TSC_IT_PLUS:
    case TSC_IT_MINUS:
    case TSC_LI_PLUS:
    case TSC_ML_PLUS:
    case TSC_MPJ:
    case TSC_MP_PLUS:
    case TSC_MYB:
    case TSC_MYD:
    case TSC_NUM:
    case TSC_QUA:
    case TSC_SIL:
    case TSC_SK_PLUS:
    case TSC_SK_MINUS:
    case TSC_SOU:
    case TSC_SSS:
    case TSC_UNI:
    case TSC_UNJ:
    case TSC_WAI:
    case TSC_YNJ:
        numParam = 1;
        break;
    default:
        numParam = 0;
    }//switch (command)
    parameters = new int[numParam];
    for (int i = 0; i < numParam; i++) {
        parameters[i] = other.parameters[i];
    }
}
