#pragma once
#ifndef GENERAL_H
#define GENERAL_H
int random(int low, int high);
int str2num(const char *string); //reads at most 10 chars
void updateKeys();
void updateKeys_a();
extern char dataDir[64];
#ifdef EDITOR_MODE
int getAlphaChar();
int getMiscChar();
void checkTabs();
void drawTabs();
#endif
void setError(const char *string);
void fatalError(const char *string);
#endif
