#include "effect.h"
#include "player.h"
#include "general.h"
#include "defines.h"
#include <math.h>
#include <list>

using namespace std;
list<Effect> effectList;

void (Effect::*effectAction[]) () = {
    &Effect::eXX,
    &Effect::ePulseDisk, &Effect::eRisingDisk_Diamond, &Effect::eStar, &Effect::eFireballImpact,
    &Effect::eZZZ, &Effect::eBoostSmoke, &Effect::eDrownSprite, &Effect::eExclaimation,
    &Effect::eLevelUD, &Effect::eDamageDisk, &Effect::eSplosion, &Effect::eXX,
    &Effect::eBonkDot, &Effect::eXX, &Effect::eWhiteCirclePop, &Effect::eEmpty
};

/*************************
   Effect class functions
*************************/
Effect::Effect()
{
    inUse = 0;
}

Effect::Effect(int x, int y, int id, int dir)
{
    inUse = 0x80;
    gfxNum = BMP_CARET;
    xPos = x;
    yPos = y;
    xVel = 0;
    yVel = 0;
    direction = dir;
    ID = id;
    frameNum = 0;
    frameTimer = 0;
    scriptState = 0;
    //scriptTimer = 0;
}

Effect::~Effect()
{

}

void Effect::draw()
{
    int dOffx = 0x100 * (frameRect.right - frameRect.left) / 2;
    int dOffy = 0x100 * (frameRect.down - frameRect.up) / 2;
    cameraBlit(gfxNum, frameRect, xPos - dOffx, yPos - dOffy);
}

/*****************************
   Effect utility functions
*****************************/
void effectInit()
{

}

void clearAllEffect()
{
    effectList.clear();
}

void updateAllEffect()
{
    list<Effect>::iterator eIt;

    for (eIt = effectList.begin(); eIt != effectList.end(); eIt++) {
        Effect *tempEffect = &*eIt;
        (tempEffect->*effectAction[tempEffect->ID])();
    }

    effectList.remove_if(effectExpired);
}

void drawAllEffect()
{
    list<Effect>::iterator bIt;

    for (bIt = effectList.begin(); bIt != effectList.end(); bIt++) {
        Effect *tempEffect = &*bIt;
        tempEffect->draw();
    }
}

void createEffect(int x, int y, int id, int dir)
{
    effectList.push_front(Effect(x, y, id, dir));
}

int countEffects()
{
    return effectList.size();
}

bool effectExpired(const Effect &b)
{
    return b.inUse == 0;
}

/*******************************
   EFFECT AI FUNCTIONS
*******************************/
void Effect::ePulseDisk() //effect 1
{
    if (!scriptState) {
        scriptState = 1;
        xVel = random(-1024, 1024);
        yVel = random(-1024, 0);
    }
    yVel += 64;
    xPos += xVel;
    yPos += yVel;
    frameTimer++;
    if (frameTimer > 5) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 3)
            inUse = 0;
    }

    switch (direction) {
    case 1:   //red circles
        frameRect.left = 128 + frameNum * 16;
        frameRect.up = 48;
        break;
    case 0:   //blue circles
        frameRect.left = frameNum * 16;
        frameRect.up = 128;
        break;
    case 2: //red blood
        frameRect.left = 96 + frameNum * 16;
        frameRect.up = 160;
        break;
    case 3: //green(?) blood
        frameRect.left = 96 + frameNum * 16;
        frameRect.up = 176;
    }
    frameRect.right = frameRect.left + 16;
    frameRect.down = frameRect.up + 16;

}

void Effect::eRisingDisk_Diamond() //effect 2
{
    char frameArray[] = {0, 2, 1};
    switch (direction) {
    case 1:
        frameTimer++;
        frameNum = frameTimer / 2 % 3;
        if (frameTimer > 24)
            inUse = 0;
        frameRect.left = frameArray[frameNum] * 32;
        frameRect.up = 64;
        frameRect.right = frameRect.left + 32;
        frameRect.down = frameRect.up + 32;
        break;
    case 2: //diamond hit
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 3)
                inUse = 0;
        }
        frameRect.left = 352 + frameNum * 32;
        frameRect.up = 0;
        frameRect.right = frameRect.left + 32;
        frameRect.down = frameRect.up + 32;
        break;
    default: //floaty circle
        yVel -= 16;
        yPos += yVel;
        frameTimer++;
        if (frameTimer > 5) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 3)
                inUse = 0;
        }
        frameRect.left = frameNum * 32;
        frameRect.up = 64;
        frameRect.right = frameRect.left + 32;
        frameRect.down = frameRect.up + 32;
    }
}

void Effect::eStar() //effect 3
{
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 3)
            inUse = 0;
    }
    frameRect.left = frameNum * 32;
    frameRect.up = 96;
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Effect::eFireballImpact() //effect 4
{
    frameTimer++;
    if (frameTimer > 1) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 2)
            inUse = 0;
    }
    frameRect.left = 128 + frameNum * 32;
    frameRect.up = 64 + direction * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Effect::eZZZ() //effect 5
{
    char frameArray[] = {0, 2, 1, 3, 1, 3, 1};
    frameTimer++;
    if (frameTimer > 4) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 6)
            inUse = 0;
    }
    xPos += 128;
    yPos -= 128;
    frameRect.left = 64 + (frameArray[frameNum]%2) * 16;
    frameRect.up = 128 + (frameArray[frameNum]/2) * 16;
    frameRect.right = frameRect.left + 16;
    frameRect.down = frameRect.up + 16;
}

void Effect::eBoostSmoke() //effect 6
{
    frameTimer++;
    if (frameTimer > 1) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 6)
            inUse = 0;
    }
    switch (direction) {
    case 0:
        xPos -= 1024;
        break;
    case 1:
        yPos -= 1024;
        break;
    case 2:
        xPos += 1024;
        break;
    case 3:
        yPos += 1024;
        break;
    default:
        break;
    }
    frameRect.left = 112 + frameNum * 16;
    frameRect.up = 0;
    frameRect.right = frameRect.left + 16;
    frameRect.down = frameRect.up + 16;
}

void Effect::eDrownSprite() //effect 7
{
    frameRect.left = direction * 32 + 32;
    frameRect.up = 160;
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Effect::eExclaimation() //effect 8
{
    frameTimer++;
    if (frameTimer < 5)
        yPos -= 2048;
    if (frameTimer == 32)
        inUse = 0;
    if (direction) {
        frameRect.left = 96;
        frameRect.up =  128;
    } else {
        frameRect.left = 0;
        frameRect.up = 160;
    }
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Effect::eLevelUD() //effect 9
{
    frameTimer++;
    frameRect.up = 0;
    if (direction) {
        if (frameTimer < 20)
            yPos -= 512;
        frameRect.up += 192;
    } else {
        if (frameTimer < 20)
            yPos -= 1024;
    }
    if (frameTimer == 80)
        inUse = 0;
    frameRect.left = 0;
    frameRect.right = 112;
    frameRect.up += (frameTimer/2%2) * 32;
    frameRect.down = frameRect.up + 32;
}

void Effect::eDamageDisk() //effect 10
{
    if (!scriptState) {
        scriptState = 1;
        int vDir = random(0, 360);
        yVel = (int)(sin(vDir * PI / 180) * 512);
        xVel = (int)(cos(vDir * PI / 180) * 512);
    }
    xPos += xVel;
    yPos += yVel;
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 6)
            inUse = 0;
    }
    frameRect.left = 112 + frameNum * 16;
    frameRect.up = 16;
    frameRect.right = frameRect.left + 16;
    frameRect.down = 32;
}

void Effect::eSplosion()//effect 11
{
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 1)
            inUse = 0;
    }
    frameRect.left = 224 + frameNum * 64;
    frameRect.up = 0;
    frameRect.right = frameRect.left + 64;
    frameRect.down = 64;
}

void Effect::eBonkDot() //effect 12
{
    if (!scriptState) {
        scriptState = 1;
        if (direction == 1) {
            yVel = -512 * random(1,3);
        } else if (direction == 0) {
            xVel = random(-1536, 1536);
            yVel = random(-512, 512);
        }
    }
    if (!direction) {
        xVel = 4 * xVel / 5;
        yVel = 4 * yVel / 5;
    }
    xPos += xVel;
    yPos += yVel;
    frameTimer++;
    if (frameTimer > 20)
        inUse = 0;
    frameRect.left = 112;
    frameRect.up = 48;
    frameRect.right = 128;
    frameRect.down = 64;
    if (frameTimer / 2 % 2)
        frameRect.right = frameRect.left;
    if (direction == 5)
        xPos -= 2048;
}

void Effect::eXX() //effect 13
{
    inUse = 0;
    //empty
}

void Effect::eWhiteCirclePop() //effect 14
{
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 2)
            inUse = 0;
    }
    frameRect.left = frameNum * 16;
    frameRect.up = 144 + direction * 16;
    frameRect.right = frameRect.left + 16;
    frameRect.down = frameRect.up + 16;
}

void Effect::eEmpty() //effect 15
{
    frameTimer++;
    if (frameTimer < 10)
        yPos -= 1024;
    if (frameTimer == 40)
        inUse = 0;
    frameRect.left = 208;
    frameRect.right = 288;
    frameRect.up = 192 + (frameTimer/2%2)*16;
    frameRect.down = frameRect.up + 16;
}
