
#include "defines.h"
#ifdef EDITOR_MODE

#include <allegro.h>
#include <list>
#include <stdio.h>

#include "weapon.h"
#include "profile.h"
#include "music.h"
#include "graphics.h"
#include "player.h"
#include "debug.h"
#include "tsc.h"
#include "map.h"
#include "sfx.h"
#include "entity.h"
#include "particle.h"
#include "main.h"
#include "general.h"
#include "pxeEdit.h"
#include "mapEdit.h"

extern BITMAP *Buffer;
extern int debugMode;
extern int timer_2, timer_4;
extern int keyPressed, keyHeld, alphaPressed, alphaHeld, numPressed, numHeld;
extern int mousePressed, mouseHeld;
extern int closeFlag;
extern int escHack;

PxeFile *pxeGlobal = NULL;
extern DIALOG *focusObj;
extern DIALOG *mouseObj;

extern unsigned char *npctbl_Tileset;
extern unsigned char *npctbl_Displaybox;
extern unsigned short *npctbl_Health;
extern unsigned int *npctbl_Exp;
extern unsigned int *npctbl_Damage;

using namespace std;
list<PxeEntry> entryList;
MouseList_pxe mouseList;
list<PxeEntry> selectionList;
list<PxeEntry> copyList;
vector<EntityCategory> categoryList;
int selectingList = 0;

Rect pxeBound[] =
{
   {0, 784, 752, 800}, //bottom scrollbar
   {752, 0, 768, 784}, //right scrollbar
   {0, 0, 752, 784} //map area
};

vector<DebugEntity> entityInfo;

char *pxeStr[] =
{
   "Entity Editor", "Entity Category", "Subcategory",
   "Parameters", "Event", "FlagID", "Layer", "Flags",
   "Edit Table", "Save PXE",
   "Solid", "No Tile 44", "Invincible", "Ignore Solid",
   "Bouncy Top", "Shootable", "Special Solid", "No Rear/Top Att",
   "TSC on Contact", "TSC on Death", "\"!\" Flag", "Create if FlagID",
   "Direction Flag", "Interactable", "No Create if FlagID", "Show Damage #"
};

//editable text fields
char field_event[5] = {0};
char field_flagID[5] = {0};
char field_layer[2] = {0};

DIALOG pxeDialog[] = 
{
   /* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags) (d1)  (d2)  (dp)(dp2) (dp3) */
   //labels
   {d_ctext_proc,       1000, 15,   0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[0], NULL, NULL},
   {d_text_proc,        800,  40,   0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[1], NULL, NULL},
   {d_text_proc,        950,  40,   0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[2], NULL, NULL},
   {d_ctext_proc,       1000, 420,  0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[3], NULL, NULL},
   {d_ctext_proc,       860,  450,  0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[4], NULL, NULL},
   {d_ctext_proc,       1000, 450,  0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[5], NULL, NULL},
   {d_ctext_proc,       1140, 450,  0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[6], NULL, NULL},
   {d_ctext_proc,       1000, 510,  0,    0,    0, 0, 0,    0,       0,    0,    pxeStr[7], NULL, NULL},
   
   //scrollbars
   #define SCROLL 8
   {custom_slider_proc, 0,    784,  752,  16,   0, 0, 0,    0,       0,    1000, NULL, NULL, NULL},
   {custom_slider_proc, 752,  0,    16,  784,   0, 0, 0,    0,       0,    1000, NULL, NULL, NULL},

   //list items
   #define LIST 10
   {custom_list_proc,        800,  55,   120,  30,   0, 0, 0,    0,       0,    0,    (void*)categoryProc, NULL, NULL},
   {custom_list_proc,        950,  55,   120,  30,   0, 0, 0,    0,       0,    0,    (void*)subcatProc, NULL, NULL},
   
   //The entity selector
   #define SELECTOR 12
   {entitySelector,     800,  100,  455,  300,  0, 0, 0,    0,       0,    0,    NULL, NULL, NULL},

   //editable text fields
   {custom_edit_proc,   800,  465,  120,  20,   0, 0, 0,    0,       4,    0,    field_event, NULL, NULL},
   {custom_edit_proc,   950,  465,  120,  20,   0, 0, 0,    0,       4,    0,    field_flagID, NULL, NULL},
   {custom_edit_proc,   1100, 465,  120,  20,   0, 0, 0,    0,       1,    0,    field_layer, NULL, NULL},
   
   //check buttons
   #define FLAG_CHECKBOXES 16
   {custom_check_proc,  800,  550,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[10], NULL, NULL},
   {custom_check_proc,  800,  570,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[11], NULL, NULL},
   {custom_check_proc,  800,  590,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[12], NULL, NULL},
   {custom_check_proc,  800,  610,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[13], NULL, NULL},
   {custom_check_proc,  800,  630,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[14], NULL, NULL},
   {custom_check_proc,  800,  650,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[15], NULL, NULL},
   {custom_check_proc,  800,  670,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[16], NULL, NULL},
   {custom_check_proc,  800,  690,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[17], NULL, NULL},
   {custom_check_proc,  1000, 550,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[18], NULL, NULL},
   {custom_check_proc,  1000, 570,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[19], NULL, NULL},
   {custom_check_proc,  1000, 590,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[20], NULL, NULL},
   {custom_check_proc,  1000, 610,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[21], NULL, NULL},
   {custom_check_proc,  1000, 630,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[22], NULL, NULL},
   {custom_check_proc,  1000, 650,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[23], NULL, NULL},
   {custom_check_proc,  1000, 670,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[24], NULL, NULL},
   {custom_check_proc,  1000, 690,  200,  16,   0, 0, 0,    0,       0,    0,    pxeStr[25], NULL, NULL}

};

//category list proc
char *categoryProc(int index, int *list_size)
{
   if (index >= 0)
      return categoryList[index].name;
   if (list_size)
      *list_size = categoryList.size();
   return "NULL";
}

//subcategory list proc
char *subcatProc(int index, int *list_size)
{
   //determine which category we're under
   int categoryNum = pxeDialog[LIST].d1;
   EntityCategory *tempCat = &categoryList[categoryNum];
   if (index >= 0)
      return tempCat->subCats[index].name;
   if (list_size)
      *list_size = tempCat->subCats.size();
   return "NULL";
}

/*
d->d1 = selection index
d->d2 = scroll position (pixels)
d->flags & D_USER = nubGrabbed flag
d->dp3 = timer
*/
int entitySelector(int msg, DIALOG *d, int c)
{
   EntityCategory *theCategory;
   EntitySubcat *theSubcat;
   int scrollablePixels;
   int scrollPos;
   switch (msg) {
      case MSG_START:
            d->d1 = 0;
            d->d2 = 0;
            break;
      case MSG_DRAW:
         {
            int x2 = d->x + d->w;
            int y2 = d->y + d->h;
            //draw the framework
            rect(gui_get_screen(), d->x, d->y, x2, y2, gui_fg_color);
            rect(gui_get_screen(), d->x + 1, d->y + 1, x2 - 1, y2 - 1, gui_fg_color);   
            //draw the header
            hline(gui_get_screen(), d->x +2, d->y + 18, d->x + d->w - 2, gui_fg_color);
            hline(gui_get_screen(), d->x +2, d->y + 19, d->x + d->w - 2, gui_fg_color);
            textout_ex(gui_get_screen(), font, "Sprite", d->x + 32, d->y + 6, gui_fg_color, -1);
            textout_ex(gui_get_screen(), font, "Name", d->x + 178, d->y + 6, gui_fg_color, -1);
            textout_ex(gui_get_screen(), font, "HP  DAM  EXP", d->x + 326, d->y + 6, gui_fg_color, -1);

            extern BITMAP *BitmapArray[];
            BITMAP *tempBuffer = BitmapArray[BMP_PXEBUF];
            //wipe to bg colour
            clear_to_color(tempBuffer, gui_bg_color);
            //draw the scroller on the right
            for (int i = 0; i < 279; i += 16)
            {
               blit(BitmapArray[BMP_DBG2], tempBuffer, 80, 20, 436, i, 16, 16);
            }
            //get the list of entities
            theCategory = &categoryList[pxeDialog[LIST].d1];
            if (pxeDialog[LIST+1].d1 >= theCategory->subCats.size())
               pxeDialog[LIST+1].d1 = 0; //If our subcat index is OOB, set to zero
            theSubcat = &theCategory->subCats[pxeDialog[LIST+1].d1];
            scrollablePixels = (theSubcat->entityList.size() * 64) - 279; //each entry is 64px large
            if (scrollablePixels <= 0)
               scrollablePixels = 1;
            scrollPos = 263 * d->d2 / scrollablePixels;
            //now render the scroll position marker
            masked_blit(BitmapArray[BMP_DBG2], tempBuffer, 112, 20, 436, scrollPos, 16, 16);
            //highlight the selected entity
            //render each entity
            for (int currentEnt = d->d2/64; (currentEnt)*64 - d->d2 < 297; currentEnt++)
            {
               if (currentEnt >= theSubcat->entityList.size())
                  break;
               //for each possibly visible entity
               //int textColour;
               if (d->d1 == currentEnt) //if this is the selected entry
               {
                  rectfill(tempBuffer, 0, d->d1*64 - d->d2, 435, d->d1*64 - d->d2 + 64, 0x45558A);
                  //textColour = gui_bg_color;
               } else { //else it isn't
                  //textColour = gui_fg_color;
               }
               int entityType = theSubcat->entityList.at(currentEnt);
               //draw the sprite
               DebugEntity *currentInfo = &entityInfo[entityType];
               int width = currentInfo->frameRect.right - currentInfo->frameRect.left;
               int height = currentInfo->frameRect.down - currentInfo->frameRect.up;
               masked_blit(BitmapArray[npctbl_Tileset[entityType]],
                           tempBuffer,
                           currentInfo->frameRect.left,
                           currentInfo->frameRect.up,
                           32,
                           currentEnt*64 - d->d2 + (64-height)/2,
                           width,
                           height);
               //draw the name
               textout_ex(tempBuffer,
                           font, 
                           currentInfo->name, 
                           175, 
                           currentEnt*64 - d->d2 + 30, 
                           gui_fg_color,
                           -1);
               //draw the stats
               textprintf_centre_ex(tempBuffer,
                              font,
                              368,
                              currentEnt*64 - d->d2 + 30,
                              gui_fg_color,
                              -1,
                              "%d / %d / %d", npctbl_Health[entityType], npctbl_Damage[entityType], npctbl_Exp[entityType]);
            }//for each visible entity
            
            //finally draw to the main buffer
            draw_sprite(Buffer, tempBuffer, d->x + 2, d->y + 20);
         }//msg_draw
         break;
      case MSG_LPRESS:
         {
            //get the list of entities
            theCategory = &categoryList[pxeDialog[LIST].d1];
            if (pxeDialog[LIST+1].d1 >= theCategory->subCats.size())
               pxeDialog[LIST+1].d1 = 0; //If our subcat index is OOB, set to zero
            theSubcat = &theCategory->subCats[pxeDialog[LIST+1].d1];
            scrollablePixels = (theSubcat->entityList.size() * 64) - 279; //each entry is 64px large
            if (scrollablePixels <= 0)
               scrollablePixels = 1;
            scrollPos = 263 * d->d2 / scrollablePixels;
            if ((mouse_x > d->x + d->w - 18) &&
               (mouse_x < d->x + d->w) &&
               (mouse_y > d->y + scrollPos + 20) &&
               (mouse_y < d->y + scrollPos + 36))
            {
               d->flags |= D_USER;
            } else {
               d->flags &= !D_USER;
            }
         }//msg_lpress
         break;
      case MSG_CLICK:
         {
            int *timer = (int*)&d->dp3;
            //get the list of entities
            theCategory = &categoryList[pxeDialog[LIST].d1];
            if (pxeDialog[LIST+1].d1 >= theCategory->subCats.size())
               pxeDialog[LIST+1].d1 = 0; //If our subcat index is OOB, set to zero
            theSubcat = &theCategory->subCats[pxeDialog[LIST+1].d1];
            scrollablePixels = (theSubcat->entityList.size() * 64) - 279; //each entry is 64px large
            if (scrollablePixels < 0)
            {
               scrollablePixels = 0;
            }
            scrollPos = 263 * d->d2 / (scrollablePixels+1);
            if (d->flags & D_USER)
            {
               scrollPos = mouse_y - d->y - 28;
               if (scrollPos < 0)
                  scrollPos = 0;
               if (scrollPos > 263)
                  scrollPos = 263;
               d->d2 = scrollPos * scrollablePixels / 263;
            } else { //nub is not grabbed
               if (mouse_x < d->x + d->w - 18)// left of scrollbar
               {
                  if (mouse_y < d->y + 18) //above selection set
                  {
                     *timer += 1;
                     if (*timer > 10)
                     {
                        *timer = 0;
                        if (d->d1 > 0)
                           d->d1--;
                        d->d2 = d->d1 * 64;
                     }
                  } else if (mouse_y > d->y + d->h) {//below selection set
                     *timer += 1;
                     if (*timer > 10)
                     {
                        *timer = 0;
                        if (d->d1 < theSubcat->entityList.size() - 1)
                           d->d1++;
                        d->d2 = d->d1*64 - 215;
                     }
                  } else { //within selection set
                     d->d1 = (mouse_y - d->y - 20 + d->d2)/64;
                     if (d->d1 >= theSubcat->entityList.size()) //make sure we're not oob
                        d->d1 = theSubcat->entityList.size() -1;
                  }
               } else { //else on scrollbar
                  if (mouse_y < d->y + 20 + scrollPos) //above the scroll nub
                  {
                        d->d2 -=4;
                  } else if (mouse_y > d->y + scrollPos + 36) { //below the scroll nub
                        d->d2 += 4;

                  }
               }//else on scrollbar
            }//else nub not grabbed
            if (d->d2 < 0)
               d->d2 = 0;
            if (d->d2 > scrollablePixels)
               d->d2 = scrollablePixels;
         }//msg_click
         break;
      case MSG_WHEEL:
         {
            theCategory = &categoryList[pxeDialog[LIST].d1];
            if (pxeDialog[LIST+1].d1 >= theCategory->subCats.size())
               pxeDialog[LIST+1].d1 = 0; //If our subcat index is OOB, set to zero
            theSubcat = &theCategory->subCats[pxeDialog[LIST+1].d1];
            scrollablePixels = (theSubcat->entityList.size() * 64) - 279; //each entry is 64px large
            if (scrollablePixels < 0)  
               scrollablePixels = 0;
            c *= scrollablePixels / 10;
            d->d2 -= c;
            if (d->d2 < 0)
               d->d2 = 0;
            if (d->d2 > scrollablePixels)
               d->d2 = scrollablePixels;
         }
         break;
      case MSG_LOSTFOCUS:
      case MSG_WANTFOCUS:
         return D_WANTFOCUS;
      default:
         break;
   };
   return D_O_K;
}

int custom_list_proc(int msg, DIALOG *d, int c)
{
   switch (msg) {
      case MSG_CLICK: //dp3 is scroll timer
         {
            //check to see if this is primary list, and if so set the 2nd list index to zero
            if (d == &pxeDialog[LIST])
            {
               pxeDialog[LIST+1].d1 = 0;
               pxeDialog[LIST+1].d2 = 0;
            }
            int *timer = (int*)&d->dp3;
            int size;
            ((int (*)(int, int*))d->dp)(-1, &size); //cast from void pointer to function
            if (gui_mouse_x() < (d->x + d->w - 14)) //mouse to the left of the scroller
            {
               if (gui_mouse_y() < d->y) //above
               {
                  *timer += 1;
                  if (*timer > 10)
                  {
                     *timer = 0;
                     if (d->d1 > 0)
                        d->d1--;
                     if (d->d2 > d->d1)
                        d->d2 = d->d1;
                  }
               } else if (gui_mouse_y() < (d->y + (d->h/3))) { //top selection
                  d->d1 = d->d2;
               } else if (gui_mouse_y() < (d->y + (d->h/3)*2)) { //middle selection
                  if (size > 1)
                     d->d1 = d->d2 + 1;
                  else
                     d->d1 = 0;
               } else if (gui_mouse_y() < (d->y + d->h)) { //bottom selection

                  if (size > 2) //make sure it's not a single-object list
                     d->d1 = d->d2 + 2; 
                  else if (size = 2)
                     d->d1 = 1;
                  else
                     d->d1 = 0;
               } else { //below
                  *timer += 1;
                  if (*timer > 10)
                  {
                     *timer = 0;
                     if (d->d1 < --size)
                        d->d1++;
                     d->d2 = d->d1 - 2;
                  }
               }//if/else for y-pos
            } else if (gui_mouse_x() < (d->x + d->w)){ //mouse to the right (on) the scroller
               int scrollPos = gui_mouse_y() - 8 - d->y;
               int scrollSpace = d->h - 12;
               if (scrollPos < 0)
                  scrollPos = 0;
               if (scrollPos > scrollSpace)
                  scrollPos = scrollSpace;
               if (size > 2)
               {
                  d->d2 = scrollPos*(size-1) / scrollSpace;
                  if ((d->d2+2) >= size)
                  d->d2 = size-3;
               }
            }
         }
         break;
      case MSG_GOTMOUSE:
         return D_O_K;
      case MSG_WANTFOCUS:
      case MSG_LOSTFOCUS:
         return D_WANTFOCUS;
      default:
         return d_list_proc(msg, d, c);
   };
}

/*********************************************************
*********************************************************/

void renderEntityIcons()
{
   pxeGlobal->draw();
}

void pxeLoop()
{
   //setup map edit stuff
   setFrameTarget(766);
   debugMode = DBG_PXE;
   gui_set_screen(Buffer);
   timer_2 = 0;
   //pxeIterator = pxeHistory.begin();
   addUndo_pxe();
   //set fg/bg colours
   for (int i = 0; i < (sizeof pxeDialog / sizeof pxeDialog[0]); i++)
   {
      pxeDialog[i].fg = gui_fg_color;
      pxeDialog[i].bg = gui_bg_color;
      if ((pxeDialog[i].proc == d_ctext_proc) ||
         (pxeDialog[i].proc == d_text_proc))
      {
         pxeDialog[i].fg = 0xFFFFFF;
         pxeDialog[i].bg = -1;
      }
      pxeDialog[i].proc(MSG_START, &pxeDialog[i], 0);
   }

   while (!(keyPressed & KEYESC) && (!closeFlag))
   {
      while (timer_2)
      {
         pxeDraw();
         timer_2--;
         if (timer_2 > 10)
         {
            timer_2 = 0;
            setError("Can't keep up!");
            break;
         }
      }
      
      while (timer_4)
      {
         updateKeys();
         updateKeys_a();
         updateFramePos();
         doPxeGuiLogic();
         updateTileAnim();
         timer_4--;
         if (timer_4 > 10)
         {
            setError("Can't keep up!");
            timer_4 = 0;
            break;
         }
      }
      rest(1);
   }
   //close map edit stuff
   //mapHistory.clear();
   gui_set_screen(screen);
   debugMode = DBG_DEFAULT;
   focusObj = NULL;
   mouseObj = NULL;
   setFrameTarget(0);
   escHack = 50;
}

void pxeDraw()
{
   clearBuffer();
   renderBG();

   drawTiles(0);
   drawTiles(1);
   drawTiles(2);
   drawTiles(3);
   renderEntityIcons();
   drawMapBounds(0);

   drawDebugFrame();
   //draw those lines that make up the border
   rectfill(Buffer, 775, 0, 1280, 486, 0x182041);
   rectfill(Buffer, 768, 0, 769, 486, 0x7582B6);
   rectfill(Buffer, 770, 0, 770, 486, 0x9EA6C7);
   rectfill(Buffer, 771, 0, 772, 486, 0x45558A);
   rectfill(Buffer, 773, 0, 774, 486, 0x101830);
   //draw all 'dialog' things
   sendPxeMessage(MSG_DRAW, 0);
   //draw the list of names
   list<PxeEntry>::iterator pxeIt;
   int y = 0;
   mouseList.draw();
   updateScreen();
}

void doPxeGuiLogic()
{
   /*
   if (mousePressed & (LEFT_REL | RIGHT_REL))
   {
      if (selectingTiles)
      {
         selectingTiles = 0;
         tileSelection();
      }
      if (selectingMap)
      {
         selectingMap = 0;
         mapCommit();
      }
   }
   */   
   if (mousePressed & LEFT) 
     if (focusObj) //if we click somewhere that's not our focus object
      {  //remove its focus
         if ((mouse_x < focusObj->x) ||
            (mouse_x > (focusObj->x + focusObj->w)) ||
            (mouse_y < focusObj->y) ||
            (mouse_y > (focusObj->y + focusObj->h)))
         {
            focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
            focusObj = NULL;
         }
      }

   //general GUI
   if (mouse_x > 768)
   {
      int wasMouse = 0; //for mouse
      for (int i = 0; i < (sizeof pxeDialog / sizeof pxeDialog[0]); i++)
      {

         if ((mouse_x > pxeDialog[i].x) &&
            (mouse_x < pxeDialog[i].x + pxeDialog[i].w) &&
            (mouse_y > pxeDialog[i].y) &&
            (mouse_y < pxeDialog[i].y + pxeDialog[i].h))
         {
            wasMouse = 1; //the mouse was over an object
            DIALOG *thisObj = &pxeDialog[i];
            if (mouseObj != thisObj) //got/lost mouse messages
            {
               if (mouseObj)
                  mouseObj->proc(MSG_LOSTMOUSE, mouseObj, 0);
               if (thisObj->proc(MSG_GOTMOUSE, thisObj, 0) == D_WANTFOCUS) //got/lost focus messages?
               {
                  if (focusObj) //if we have a focus object to compete with
                  {
                     if (focusObj->proc(MSG_LOSTFOCUS, focusObj, 0) != D_WANTFOCUS)
                     {
                        //the object doesn't care if it loses focus
                        focusObj = thisObj;
                        thisObj->proc(MSG_GOTFOCUS, thisObj, 0);
                     } else {
                        //the object still wants to keep focus
                        focusObj->proc(MSG_GOTFOCUS, focusObj, 0);
                     }
                  } else { //there is no current focus to compete with
                     focusObj = thisObj;
                     thisObj->proc(MSG_GOTFOCUS, thisObj, 0);
                  }
               }
               mouseObj = thisObj;
            }
            if (mouseHeld & LEFT)
            {
               if (mousePressed & LEFT)
               {
                  thisObj->proc(MSG_LPRESS, thisObj, 0); //click message
                  if (thisObj != focusObj) //transfer focus
                  {
                     if (thisObj->proc(MSG_WANTFOCUS, thisObj, 0) == D_WANTFOCUS)
                     {
                        thisObj->proc(MSG_GOTFOCUS, thisObj, 0);
                        if (focusObj)
                           focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
                        focusObj = thisObj;
                     }//if we want focus
                  }//if this != focus
               }// if left pressed
               if (!focusObj || (focusObj == thisObj))
               {
                  thisObj->proc(MSG_CLICK, thisObj, 0); //click message
                  if (thisObj->proc == custom_list_proc) //if we click on the list, reset the entity selector
                     pxeDialog[SELECTOR].proc(MSG_START, &pxeDialog[SELECTOR], 0);
               }
            }
            if (mousePressed & LEFT_REL)
               thisObj->proc(MSG_LRELEASE, thisObj, 0); //release mouse button message
         }//if mouse within current object region
      }//for each dialog object
      if (!wasMouse)
      {
         if (mouseObj)
            mouseObj->proc(MSG_LOSTMOUSE, mouseObj, 0);
         mouseObj = NULL;
         if (mousePressed & LEFT)
         {
            if (focusObj)
               focusObj->proc(MSG_LOSTFOCUS, focusObj, 0);
            focusObj = NULL;
         } //if left pressed
      }//if !mouse
   }//if mouse in region

   //bottom scrollbar region
   if ((mouseHeld || mousePressed) &&
      (mouse_x > pxeBound[0].left) &&
      (mouse_x < pxeBound[0].right) &&
      (mouse_y > pxeBound[0].up) &&
      (mouse_y < pxeBound[0].down) &&
      !focusObj)
   {
      pxeDialog[SCROLL].proc(MSG_CLICK, &pxeDialog[SCROLL], 0);
   }
   //right scrollbar region
   if ((mouseHeld || mousePressed) &&
      (mouse_x > pxeBound[1].left) &&
      (mouse_x < pxeBound[1].right) &&
      (mouse_y > pxeBound[1].up) &&
      (mouse_y < pxeBound[1].down) &&
      !focusObj)
   {
      pxeDialog[SCROLL+1].proc(MSG_CLICK, &pxeDialog[SCROLL+1], 0);
   }

   //scroll wheel
   if (mouse_z)
   {
      if (mouseObj == &pxeDialog[SELECTOR]) //if mouse over the selector, give it scroll
      {
         mouseObj->proc(MSG_WHEEL, mouseObj, mouse_z);
      } else { //else give to vertical scrollwheel
         pxeDialog[SCROLL+1].proc(MSG_WHEEL, &pxeDialog[SCROLL+1], mouse_z * 0x20);
      }
      position_mouse_z (0);
   }

   //map region
   if ((mouse_x > pxeBound[2].left) &&
      (mouse_x < pxeBound[2].right) &&
      (mouse_y > pxeBound[2].up) &&
      (mouse_y < pxeBound[2].down) &&
      !focusObj)
   {
      pxe_mapInteract();
   } else {
      mouseList.entityList.clear();
      selectingList = 0;
   }
   if (selectionList.size() == 1)
      getGuiInfo(selectionList.front().filePos);

   //focus object
   if (focusObj)
   {
      if (mouseHeld)
         if (focusObj != mouseObj)
            focusObj->proc(MSG_CLICK, focusObj, 0);
      if (alphaPressed)
      {
         focusObj->proc(MSG_CHAR, focusObj, getAlphaChar());
      }
      if (numPressed)
      {
         focusObj->proc(MSG_CHAR, focusObj, getMiscChar());
      }
      if (keyPressed & LEFT)
         focusObj->proc(MSG_CHAR, focusObj, KEY_LEFT << 8);
      if (keyPressed & UP)
         focusObj->proc(MSG_CHAR, focusObj, KEY_UP << 8);
      if (keyPressed & RIGHT)
         focusObj->proc(MSG_CHAR, focusObj, KEY_RIGHT << 8);
      if (keyPressed & DOWN)
         focusObj->proc(MSG_CHAR, focusObj, KEY_DOWN << 8);
   }
   
   //undo
   if (!mousePressed &&
      !mouseHeld &&
      key[KEY_LCONTROL] &&
      (alphaPressed & KEYZ))
   {

   }

   //redo
   if (!mousePressed &&
      !mouseHeld &&
      key[KEY_LCONTROL] &&
      (alphaPressed & KEYY))
   {

   }
}

void addUndo_pxe()
{

}

void pxe_mapInteract()
{
   //determine the x/y "tile" of the mouse
   int camX, camY;
   extern int dbgScale;
   getCamera(camX, camY);
   camX = camX / 0x100; 
   camY = camY / 0x100; //convert to px
   int mouse_tileX = (mouse_x + camX) / dbgScale;
   int mouse_tileY = (mouse_y + camY) / dbgScale;

   list<PxeEntry>::iterator pxeIt;

   if (!selectingList)//if we're not picking an entity from the list
   {
      mouseList.entityList.clear();
      mouseList.x = mouse_x + 20;
      mouseList.y = mouse_y;
      mouseList.w = 0;
      mouseList.h = 0;
      for (pxeIt = entryList.begin(); pxeIt != entryList.end(); pxeIt++)
      {
         PxeEntry *currentEntry = &*pxeIt;
         if ((currentEntry->xTile == mouse_tileX) &&
            (currentEntry->yTile == mouse_tileY))
         {
            int width;
            if (entityInfo[currentEntry->entityType].name)
               width = text_length(font, entityInfo[currentEntry->entityType].name);
            else
               width = text_length(font, "Entity_XXX");
            if (width > mouseList.w)
               mouseList.w = width;
            mouseList.h += 8;
            mouseList.entityList.push_back(*currentEntry);
         }//if entity on this tile
      }//for each entry in the list
      if (mousePressed & LEFT)
      {
         if (mouseList.entityList.size() == 0) //click on an empty tile
         {
            if (!key[KEY_LCONTROL] && !key[KEY_RCONTROL])
               selectionList.clear();

         } else if (mouseList.entityList.size() == 1) { //there's only one entity here
            if (!key[KEY_LCONTROL] && !key[KEY_RCONTROL])
               selectionList.clear();
            if (key[KEY_LSHIFT] || key[KEY_RSHIFT]) //shift-select
            {
               int entityType = mouseList.entityList.front().entityType;
               for (pxeIt = entryList.begin(); pxeIt != entryList.end(); pxeIt++)
               {
                  if (pxeIt->entityType == entityType)
                     selectionList.push_back(*pxeIt);
               }//for every entry there is
            } else {
               if (!isSelected_pxe(mouseList.entityList.front().filePos)) //if it's not selected select it
                  selectionList.push_back(mouseList.entityList.front());
               else //if it is selected, unselect it
                  selectionList.remove(mouseList.entityList.front());
               if (selectionList.size() == 1)
                  fillGuiInfo(mouseList.entityList.front());
            }

         } else {//else more than one entity in list
            selectingList = TRUE;
         }
      }//if left mouse button pressed
   } else { //else we are selecting a specific entity from the pile
      if (mousePressed & LEFT)
      {
         if (!key[KEY_LCONTROL] && !key[KEY_RCONTROL])
            selectionList.clear();
         if ((mouse_x > mouseList.x) &&
            (mouse_x < mouseList.w + mouseList.x + 68) && //within the proper x-ranges for the box
            (mouse_y > mouseList.y))
         {
            int yOff = 0;
            for (pxeIt = mouseList.entityList.begin(); pxeIt != mouseList.entityList.end(); pxeIt++)
            {
               if ((mouse_y > mouseList.y + yOff) &&
                  (mouse_y < mouseList.y + yOff + 9))
               {
                  if (key[KEY_LSHIFT] || key[KEY_RSHIFT]) //shift-select
                  {
                     int entityType = pxeIt->entityType;
                     list<PxeEntry>::iterator pxeIt2;
                     for (pxeIt2 = entryList.begin(); pxeIt2 != entryList.end(); pxeIt2++)
                     {
                        if (pxeIt2->entityType == entityType)
                           selectionList.push_back(*pxeIt2);
                     }//for every entry there is
                  } else {
                     if (!isSelected_pxe(pxeIt->filePos))
                        selectionList.push_back(*pxeIt);
                     else
                        selectionList.remove(*pxeIt);
                     if (selectionList.size() == 1)
                        fillGuiInfo(*pxeIt);
                     break;
                  }
               }
               yOff += 8;
            }//for each entry in the mouse list
         }//if the mouse is in the vicinity of the listbox
         selectingList = FALSE;
      }//if left mouse button pressed
   }
}

void fillGuiInfo(const PxeEntry &entry)
{
   memset(field_event, 0, 5);
   memset(field_flagID, 0, 5);
   memset(field_layer, 0, 2);
   sprintf(field_event, "%u", entry.eventNum);
   sprintf(field_flagID, "%u", entry.flagID);
   sprintf(field_layer, "%u", 0); //this needs to be updated when .pxe is given layer fields
   for (int i = 0; i < 16; i++)//flagBits
   {
      if (entry.flags & (1 << i))
         pxeDialog[FLAG_CHECKBOXES + i].flags |= D_SELECTED;
      else
         pxeDialog[FLAG_CHECKBOXES + i].flags &= !D_SELECTED;
   }
   pxeDialog[LIST].d1 = 0;
   pxeDialog[LIST].d2 = 0;
   pxeDialog[LIST+1].d1 = 0;
   pxeDialog[LIST+1].d2 = 0;
   EntityCategory *category = &categoryList[0];
   EntitySubcat *theSubcat = &category->subCats[0];
   for (int i = 0; i < theSubcat->entityList.size(); i++)
   {
      if (theSubcat->entityList[i] == entry.entityType)
      {
         pxeDialog[SELECTOR].d1 = i;
         pxeDialog[SELECTOR].d2 = i*64;
         break;
      }
   }
}

void getGuiInfo(int fp)
{
   list<PxeEntry>::iterator pxeIt;
   for (pxeIt = entryList.begin(); pxeIt != entryList.end(); pxeIt++)
   {
      if (pxeIt->filePos == fp)
      {
         pxeIt->eventNum = str2num(field_event);
         pxeIt->flagID = str2num(field_flagID);
         //pxeIt->layer = str2num(field_layer);
         for (int i = 0; i < 16; i++)//flagBits
         {
            if (pxeDialog[FLAG_CHECKBOXES + i].flags & D_SELECTED)
               pxeIt->flags |= 1 << i;
            else
               pxeIt->flags &= !(1 << i);
         }
      }
   }
}

void sendPxeMessage(int message, int c)
{
   for (int i = 0; i < (sizeof pxeDialog / sizeof pxeDialog[0]); i++)
   {
      pxeDialog[i].proc(message, &pxeDialog[i], c);
   }
}

void pxeInit()
{
   //issue with having to resize entityinfo...
   entityInfo.resize(361);
   FILE *theFile = fopen("DEBUG/entityInfo.txt", "r");
   if (!theFile)
   {
      //failed to load the file!
      setError("Couldn't find Entity info!");
      return;
   }
   char lineSpec = 0;
   char buf[64] = {0};
   EntityCategory *tempCat;
   EntitySubcat *tempSubcat;
   //Initialize a category "All" with subcategory "All"
   categoryList.push_back(EntityCategory("All"));
   tempCat = &categoryList[0];
   tempCat->subCats.push_back(EntitySubcat("All"));
   while (fscanf(theFile, "%c", &lineSpec) != EOF)
   {
      switch (lineSpec) {
         case '#':
            {
               DebugEntity newEnt;
               //read the entity number
               int entityNum;
               fscanf(theFile, "%u", &entityNum);
               //read the name
               fscanf(theFile, "%s63", buf);
               newEnt.name = new char[strlen(buf)+1];
               strcpy(newEnt.name, buf);
               //read rect
               memset(buf, 0, 64);
               fscanf(theFile, "%u", &newEnt.frameRect.left);
               if (fgetc(theFile) != ':')
               {
                  setError("Check entityInfo.txt -> Bad semicolon");
               }
               fscanf(theFile, "%u", &(newEnt.frameRect.up));
               if (fgetc(theFile) != ':')
               {
                  setError("Check entityInfo.txt -> Bad semicolon");
               }
               fscanf(theFile, "%u", &(newEnt.frameRect.right));
               if (fgetc(theFile) != ':')
               {
                  setError("Check entityInfo.txt -> Bad semicolon");
               }
               fscanf(theFile, "%u", &(newEnt.frameRect.down));

               //add to Entity info array
               int maxSize = entityInfo.max_size();
               if (entityInfo.size() < entityNum)
                  entityInfo.resize(entityNum+1);
               entityInfo[entityNum] = newEnt;
               //add to "all" category
               tempCat = &categoryList[0];
               tempSubcat = &(tempCat->subCats[0]);
               tempSubcat->entityList.push_back(entityNum);
               //read categories
               memset(buf, 0, 64);
               char cat[16];
               char subcat[16];
               fscanf(theFile, "%s63", buf);
               while (buf[0] != ';')
               {
                  memset(cat, 0, 16);
                  memset(subcat, 0, 16);
                  int pos = 0;
                  int i = 0;
                  char current = buf[pos];
                  while (current != ':') 
                  {
                     cat[i] = current;
                     i++;
                     pos++;
                     current = buf[pos];
                  }
                  strcpy(subcat, &buf[pos+1]);
                  //search if category exists
                  int wasCategory = 0;
                  for (int i = 0; i < categoryList.size(); i++)
                  {
                     if (!(strcmp(categoryList[i].name, cat))) //if the strings are equal
                     {
                        tempCat = &categoryList[i];
                        wasCategory = 1;
                        break;
                     }
                  }//for each category
                  if (!wasCategory) //if category doesn't exist
                  {
                     categoryList.push_back(EntityCategory(cat));
                     tempCat = &categoryList.back();
                  }
                  //search if subcategory exists
                  wasCategory = 0;
                  for (int i = 0; i < tempCat->subCats.size(); i++)
                  {
                     if (!(strcmp(tempCat->subCats[i].name, subcat)))
                     {
                        tempSubcat = &tempCat->subCats[i];
                        wasCategory = 1;
                        break;
                     }
                  }//for each subcategory
                  if (!wasCategory) //if subcategory doesn't exist
                  {
                     tempCat->subCats.push_back(EntitySubcat(subcat));
                     tempSubcat = &tempCat->subCats.back();
                  }
                  //add entity to the list
                  wasCategory = 0;
                  for (int i = 0; i < tempSubcat->entityList.size(); i++)
                  {
                     if (tempSubcat->entityList[i] == entityNum)
                        wasCategory = 1;
                  }
                  if (!wasCategory) //only add if list doesn't already contain it
                     tempSubcat->entityList.push_back(entityNum);
                  //read the next string
                  memset(buf, 0, 64);
                  fscanf(theFile, "%s63", buf);
               }//for each Cat:Subcat string
            }// case '#'
            break;
         case '/':
         default:
            while (fgetc(theFile) != '\n')
               if (feof(theFile)) //advance until newline char or eof
                  break;
            break;
         case '\n':
            break;
      }; //switch lineSpec
   }//while we have lines
   fclose(theFile);
}

void fillPxeList()
{
   for (int i = 0; i < pxeGlobal->numEntity; i++)
      entryList.push_back(pxeGlobal->entityArray[i]);
}

int isSelected_pxe(int fp)
{
   list<PxeEntry>::iterator it;
   for (it = selectionList.begin(); it != selectionList.end(); it++)
   {
      if (it->filePos == fp)
         return 1;
   }
   return 0;
}

/********************************************************
                  PxeFile class
********************************************************/

void PxeFile::draw()
{
   extern int dbgScale;
   Rect markerRect = {160, 0, 192, 32};
   for (int i = 0; i < numEntity; i++)
   {
      int xPos = entityArray[i].xTile * 0x100 * dbgScale;
      int yPos = entityArray[i].yTile * 0x100 * dbgScale;


      int type = entityArray[i].entityType;
      int gfxNum = npctbl_Tileset[type];
      int xOff = npctbl_Displaybox[type*4] * 0x10 * dbgScale - (0x80 * dbgScale);
      int yOff = npctbl_Displaybox[type*4 + 1] * 0x10 * dbgScale - (0x80 * dbgScale);
      float scale = (float)dbgScale/32.0;
      if (type < entityInfo.size())
         cameraBlit_scale(gfxNum, entityInfo[type].frameRect, xPos - xOff, yPos - yOff, scale); //draw sprite
      //draw marker
      if (isSelected_pxe(entityArray[i].filePos))
      {
         markerRect.left = 192;
         markerRect.right = 224;
      } else {
         markerRect.left = 160;
         markerRect.right = 192;
      }
      cameraBlit_scale(BMP_DBG2, markerRect, xPos, yPos, scale);
   }
}

/********************************************************
                  Categories Classes
********************************************************/

EntityCategory::EntityCategory(const char *str)
{
   name = new char[strlen(str)+1];
   strcpy(name, str);
}

EntityCategory::EntityCategory()
{
   name = NULL;
}


EntityCategory::EntityCategory(const EntityCategory &other)
{
   if (other.name)
   {
      name = new char[strlen(other.name)+1];
      strcpy(name, other.name);
   } else {
      name = NULL;
   }
   subCats = other.subCats;
}

EntityCategory& EntityCategory::operator=(const EntityCategory &other)
{
   if (other.name)
   {
      name = new char[strlen(other.name)+1];
      strcpy(name, other.name);
   } else {
      name = NULL;
   }
   subCats = other.subCats;
}

EntityCategory::~EntityCategory()
{
   if (name)
      delete[] name;
   subCats.clear();
}

EntitySubcat::EntitySubcat(const char *str)
{
   name = new char[strlen(str)+1];
   strcpy(name, str);
}

EntitySubcat::EntitySubcat()
{
   name = NULL;
}

EntitySubcat::EntitySubcat(const EntitySubcat &other)
{
   if (other.name)
   {
      name = new char[strlen(other.name)+1];
      strcpy(name, other.name);
   } else {
      name = NULL;
   }
   entityList = other.entityList;
}

EntitySubcat& EntitySubcat::operator=(const EntitySubcat &other)
{
   if (other.name)
   {
      name = new char[strlen(other.name)+1];
      strcpy(name, other.name);
   } else {
      name = NULL;
   }
   entityList = other.entityList;
}

EntitySubcat::~EntitySubcat()
{
   if (name)
      delete[] name;
   entityList.clear();
}

DebugEntity::DebugEntity()
{
   memset(this, 0, sizeof(*this));
}

DebugEntity::~DebugEntity()
{

}

/*********************************************************
                  mouse list
*********************************************************/

void MouseList_pxe::draw()
{
   list<PxeEntry>::iterator pxeIt;
   int yOff = 0;
   //draw the white box underneath
   int xBuf;
   if (entryList.size() < 10)
      xBuf = 32;
   else if (entryList.size() < 100)
      xBuf = 40;
   else
      xBuf = 48;
   if (entityList.size() > 0)
   {
      rect(Buffer, x-1, y-2, x+w+2+xBuf, y+h+1, gui_fg_color);
      rectfill(Buffer, x, y-1, x+w+1+xBuf, y+h, gui_bg_color);
   }
   for (pxeIt = entityList.begin(); pxeIt != entityList.end(); pxeIt++)
   {
      int entityType = pxeIt->entityType;
      int text_fg, text_bg;
      if (selectingList &&
         (mouse_x > x) &&
         (mouse_x < x+w+68) &&
         (mouse_y > y+yOff) &&
         (mouse_y < y+yOff+9))
      {
         text_fg = 1;
         text_bg = 0xFFFFFF;
      } else if (isSelected_pxe(pxeIt->filePos)) {
         text_fg = gui_bg_color;
         text_bg = gui_fg_color;
      } else {
         text_fg = gui_fg_color;
         text_bg = gui_bg_color;
      }
      
      if (entityInfo[entityType].name)
      {
         textprintf_ex(Buffer, font, x+1, y + yOff, text_fg, text_bg, "(%u) %s", pxeIt->filePos, entityInfo[entityType].name);
      } else {
         textprintf_ex(Buffer, font, x+1, y + yOff, text_fg, text_bg, "(%u) Entity_%u", pxeIt->filePos, pxeIt->entityType);
      }
      yOff += 8;
   }//for each entry in the list
}

#endif
