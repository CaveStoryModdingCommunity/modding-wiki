#include <stdio.h>
#include "graphics.h"
#include "pxtoneEngrish.h"
#include "defines.h"
#include "general.h"
#include "music.h";


#define NUMSONG 41
int SongNum = 0;
int musicVolume;
int musicMute = 0;
const char nameArray[] = {
	'W', 'T', 'F',  0 ,  0 ,   0,   0, 0,
	'T', 'R', 'A', 'N', 'Q', '2',   0, 0,
	'G', 'A', 'M', 'E', 'O', 'V', 'R', 0,
	'G', 'R', 'A', 'V', 'I', 'T', 'Y', 0,
	'W', 'E', 'E', 'D',   0,   0,   0, 0,
	'M', 'I', 'M', 'I', 'P', 'E', 'P', 0,
	'F', 'I', 'R', 'E', 'E', 'Y', 'E', 0,
	'V', 'I', 'V', 'I',   0,   0,   0, 0,
	'M', 'I', 'M', 'I', 'S', 'A', 'D', 0,
	'F', 'A', 'N', 'F', 'R', 'E', '1', 0,
	'G', 'I', 'N', 'S', 'U', 'K', 'E', 0,
	'C', 'E', 'M', 'E', 'T',   0,   0, 0,
	'P', 'L', 'A', 'N', 'T',   0,   0, 0,
	'P', 'U', 'L', 'S', 'E',   0,   0, 0,
	'F', 'A', 'N', 'F', 'R', 'E', '3', 0,
	'F', 'A', 'N', 'F', 'R', 'E', '2', 0,
	'C', 'T', 'H', 'U', 'L', 'U',   0, 0,
	'F', 'A', 'N', 'F', 'R', 'E', '3', 0,
	'B', 'O', 'S', 'S', 'A', 'L', 'P', 0,
	'B', 'O', 'S', 'S', 'B', 'E', 'T', 0,
	'M', 'A', 'Z', 'E',   0,   0,   0, 0,
	'H', 'I', 'T', 'M', 'E',   0,   0, 0,
	'O', 'P', 'P', 'R', 'E', 'S', 'S', 0,
	'S', 'P', 'E', 'L', 'U', 'N', 'K', 0,
	'T', 'I', 'T', 'L', 'E',   0,   0, 0,
	'M', 'O', 'O', 'N',   0,   0,   0, 0,
	'R', 'E', 'Q', 'U', 'I', 'E', 'M', 0,
	'H', 'E', 'R', 'O',   0,   0,   0, 0,
	'Q', 'U', 'I', 'E', 'T',   0,   0, 0,
	'L', 'A', 'S', 'T', 'C', 'A', 'V', 0,
	'B', 'A', 'L', 'C', 'O', 'N', 'Y', 0,
	'C', 'H', 'A', 'R', 'G', 'E',   0, 0,
	'L', 'A', 'S', 'T', 'B', 'T', 'L', 0,
	'E', 'N', 'D', 'I', 'N', 'G',   0, 0,
	'S', 'C', 'I', 'E', 'N', 'C', 'E', 0,
	'S', 'O', 'N', 'G', 'T', '9', '1', 0,
	'H', 'E', 'L', 'L',   0,   0,   0, 0,
	'J', 'E', 'N', 'K', 'A', '2',   0, 0,
	'M', 'A', 'R', 'I', 'N', 'E',   0, 0,
	'B', 'A', 'L', 'L', 'O', 'S',   0, 0,
	'T', 'O', 'R', 'O', 'K', 'O',   0, 0,
	'W', 'H', 'I', 'T', 'E', 'O',   0, 0
	};
int lastPos = 0;

int musicInit(unsigned int newVol){
    int success;
    success = (success & pxtone_Ready(GetActiveWindow(), 2, 22050, 16, 0.1, FALSE, NULL));

    success = (success & pxtone_Tune_Load(0, "PTCOP", "MIMI"));
    musicVolume = newVol;
    if (musicVolume > 100)
        musicVolume = 100;
    pxtone_Tune_SetVolume((double)musicVolume / 100.0);
    return success;
}

void playSong(int n)
{
    setSong(n);
    pxtone_Tune_Stop();
    pxtone_Tune_Release();
    int index = (SongNum*8);
    pxtone_Tune_Load(0, "PTCOP", &nameArray[index]);
    lastPos = 0;
    if(musicMute)
        return;
    pxtone_Tune_Start(0,0);
#ifdef VERBOSE
    printf("Loaded song %s\n", &nameArray[index]);
#endif
}

void resumeSong()
{
    pxtone_Tune_Start(lastPos, 0);
}

void stopSong()
{
    lastPos = pxtone_Tune_Stop();
}

void musicClose()
{
    pxtone_Tune_Stop();
    pxtone_Tune_Release();
    pxtone_Release();
}

void musicError(int x, int y)
{
    writeText_al(pxtone_GetLastError(), x, y);
}

void setSong(int Number)
{
    if (Number > NUMSONG) {
        SongNum = 0;
    } else if (Number < 0) {
        SongNum = 41;
    } else {
        SongNum = Number;
    }
}

int getSong()
{
    int variable = SongNum;
    return variable;
}

int getMusicVol(){
    return musicVolume;
}
void setMusicVol(int newVol){
    musicVolume = newVol;
    if (musicVolume > 100)
        musicVolume = 100;
    if (musicVolume < 0)
        musicVolume = 0;
    pxtone_Tune_SetVolume((double)musicVolume / 100.0);
    return;
}
void toggleMusic(){
    musicMute ^= 1;
    if(musicMute){
        stopSong();
    }
    else{
        resumeSong();
    }
    return;
}
int isMusicMuted(){
    return musicMute;
}
