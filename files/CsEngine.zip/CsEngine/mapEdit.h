#pragma once
#ifndef MAPEDIT_H
#define MAPEDIT_H

#include <allegro.h>
void mapEditLoop();
void getImageStrings();
void mapedit_init();
void mapdataDialog_init();
void mapdataDialog_commit();

void tileTypeLoop();
void mapDraw();
void doMapGuiLogic();
int custom_check_proc(int msg, DIALOG *d, int c);
int custom_radio_proc(int msg, DIALOG *d, int c);
int custom_slider_proc(int msg, DIALOG *d, int c);
int save_button_proc(int msg, DIALOG *d, int c);
int mapdata_button_proc(int msg, DIALOG *d, int c);
void tileSelection();
void mapSelection();
void mapCommit();
void mapFill(int x, int y, int tile);
void sendMapMessage(int msg, int c);
int isShowingTypes();
void putMapBlock();
void addUndo_map();

class TileBlock
{
public:
    int layer;
    int xPos;
    int yPos;
    int width;
    int height;
    unsigned char *tileArray;

    TileBlock();
    TileBlock(int w, int h, unsigned char *array);
    ~TileBlock();
    void set();
    void set(int w, int h);
    int getTile(int x, int y);
};
#endif
