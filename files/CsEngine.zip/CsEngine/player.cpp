
#include <cstring>

#include "graphics.h"
#include "object.h"
#include "map.h"
#include "weapon.h"
#include "profile.h"
#include "player.h"
#include "entity.h"
#include "defines.h"
#include "general.h"
#include "sfx.h"
#include "tsc.h"
#include "effect.h"
#include "numobj.h"

#define BOOSTSPEED 1535
#define HALFBOOST 767

extern int keyPressed;
extern int keyHeld;
extern int gameState;
int boostState = 0;
int boosterFuel = 0;
int hasSplashed = 0;

Player::Player()
{

    xPos = 27 << 13;
    yPos = 10 << 13;
    xVel = 0;
    yVel = 0;
    maxHealth = 7;
    currentHealth = 7;
    healthBarPos = (currentHealth*HPBAR_PX)/maxHealth;
    currentWeapon = 0;
    xpFlashTimer = 0;
    selectedItem = 0;
    stateFlags = 0x1080;
    collision = 0;
    frameNum = 0;
    charNum = 0;
    hitRect.left = 0xA00;
    hitRect.up = 0x1000;
    hitRect.right = 0xA00;
    hitRect.down = 0x1000;
    equipFlags = 0;
    invoFlash = 0;
    camX = xPos;
    camY = yPos;
    int focusOffsetX;
    int focusOffsetY;
    invincTimer = 0;
    expGained = 0;
    memset(itemArray, 0, 32*sizeof(int));
    memset(weaponArray, 0, 8*sizeof(Weapon));
}

Player::Player(Profile *prof)
{
    xPos = prof->playerX;
    yPos = prof->playerY;
    xVel = 0;
    yVel = 0;
    maxHealth = prof->maxHealth;
    currentHealth = prof->currentHealth;
    healthBarPos = (currentHealth*HPBAR_PX)/maxHealth;
    stateFlags = 0x1080;
    collision = 0;
    frameNum = 0;
    charNum = prof->flagArray[996];
    hitRect.left = 0xA00;
    hitRect.up = 0x1000;
    hitRect.right = 0xA00;
    hitRect.down = 0x1000;
    equipFlags = prof->equipFlags;
    memcpy(weaponArray, prof->weaponArray, 0x8C);
    currentWeapon = prof->currentWep;
    xpFlashTimer = 0;
    selectedItem = 0;
    invoFlash = 0;
    camX = xPos;
    camY = yPos;
    int focusOffsetX;
    int focusOffsetY;
    invincTimer = 0;
    expGained = 0;
    fillFlags(prof->flagArray);
    memcpy(itemArray, prof->itemArray, 32*sizeof(int));
}

//these arrays are for the offset of the weapon sprite relative to the player sprite for each frame of animation
const static int pcWepOffX[] = {-0x1000, -0x1200, -0xF00, -0x1000, -0x1200, -0xF00, -0x1200, -0x800, -0x1000, -0x1000, -0x1000}; //x offset of weapon to draw, based on frame num
const static int pcWepOffY[] = {-0x1000, -0x1100, -0x1100, -0x1000, -0x1100, -0x1100, -0x800,  -0x1000, -0x1000, -0x1000, -0x1000};
void Player::draw(int canControl)
{
    if ((stateFlags & 2) || !(stateFlags & 0x80))
        return;
    if (invincTimer % 4 / 2)
        return;
    char frameArray[4] = {0,2,0,1};
    if (canControl) {
        if (collision & 0x38) { //if on ground
            if (keyHeld & (KEYLEFT | KEYRIGHT)) {
                frameTimer++;
                if (frameTimer >= 28)
                    frameTimer = 0;
            } else {
                frameTimer = 6;
            }
            frameNum = frameArray[frameTimer/7];
            if (frameTimer % 14 == 0)
                playSound(SFX_fx_pc_walk);
            if (keyHeld & KEYLEFT) {
                stateFlags &= -0x4001;
                stateFlags |= 0x1000;
            } else if (keyHeld & KEYRIGHT) { //right key
                stateFlags &= -0x1001;
                stateFlags |= 0x4000;
            }
            if (stateFlags & 1)
                frameNum = 7;
        } else { //if not on ground
            if (yVel < 0)
                frameNum = 2;
            else
                frameNum = 1;
            if (stateFlags & 0x8000)
                frameNum = 6;
        }
    } else { //if can not control
        if (!(collision & 0x38)) {
            frameNum = 0;
        }
    }
    if ((stateFlags & 0x2000) && (frameNum <= 2))
        frameNum += 3;
    frameRect.left = frameNum*32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = charNum * 64;
    if (stateFlags & 0x4000)
        frameRect.up += 32;
    frameRect.down = frameRect.up + 32;

    int wepX = xPos + pcWepOffX[frameNum];
    if (stateFlags & 0x1000)
        wepX -= 0x600;
    int wepY = yPos + pcWepOffY[frameNum];
    if (stateFlags & 0x2000)
        wepY -= 0x400;
    if (stateFlags & 0x3000)
        weaponArray[currentWeapon].draw(wepX, wepY, (stateFlags >> 12) & 0xF );
    cameraBlit(BMP_MYCHAR, frameRect, xPos - 0x1000, yPos - 0x1000);
    if (stateFlags & 0x4000)
        weaponArray[currentWeapon].draw(wepX, wepY, (stateFlags >> 12) & 0xF );
}

void Player::renderHud()
{
    if (invincTimer % 4 / 2)
        return;
    //render sword
    Rect tempRect = {0, 112, 158, 152};
    mainBlit(26, tempRect, 6, 21);
    //render health
    int healthBarLen = (currentHealth*HPBAR_PX)/maxHealth;
    if (invincTimer < 0x40) {
        if (healthBarPos < healthBarLen)
            healthBarPos++;
        else if (healthBarPos > healthBarLen)
            healthBarPos--;
    }
    //render yellow health bar
    tempRect.up = 156;
    tempRect.down = tempRect.up + 4;
    tempRect.right = HPBAR_PX;
    tempRect.left = tempRect.right - healthBarPos;
    mainBlit(26, tempRect, 57, 34);
    //render red health bar
    tempRect.up -= 4;
    tempRect.down -= 4;
    tempRect.left = tempRect.right - healthBarLen;
    mainBlit(26, tempRect, 57, 34);
    //render health counter
    tempRect.left = 86;
    tempRect.up = 152;
    tempRect.right = 119;
    tempRect.down = 167;
    mainBlit(26, tempRect, 57, 15);
    writeNum_l_al(73, 18, currentHealth);
    //render weapon icons
    int numIcons = 0;
    for (int i = 0; i < 8; i++) {
        if (weaponArray[i].ID) {
            weaponArray[i].renderIcon_small(55+numIcons*22, 51, i == currentWeapon);
            numIcons++;
        }
    } //for each weapon
    if (numIcons) { //if there is a weapon
        Rect flashRect = {0, 164, XPBAR_PX, 4};
        if (xpFlashTimer > 0)
            xpFlashTimer--;
        Weapon &currentWep = weaponArray[currentWeapon];
        //render weapon xp bar
        if (currentWep.energy != currentWep.getEnergyToLevel()) {
            int wepBarLen =  XPBAR_PX * currentWep.energy / currentWep.getEnergyToLevel();
            tempRect.up = 160;
            tempRect.right = XPBAR_PX;
            tempRect.down = tempRect.up + 4;
            tempRect.left = tempRect.right - wepBarLen;
            if (xpFlashTimer / 2 % 2)
                mainBlit(BMP_TEXTBOX, flashRect, 72, 43);
            else
                mainBlit(BMP_TEXTBOX, tempRect, 72, 43);
        } else {
            tempRect.left = 0;
            tempRect.up = 164;
            tempRect.right = 73;
            tempRect.down = 170;
            if (xpFlashTimer / 2 % 2)
                mainBlit(BMP_TEXTBOX, flashRect, 72, 43);
            else
                mainBlit(BMP_TEXTBOX, tempRect, 71, 42);
        }
        //render blips for level
        tempRect.left = 0;
        tempRect.up = 160;
        tempRect.right = 1;
        tempRect.down = 164;
        mainBlit(26, tempRect, 57, 43);
        int localLevel = currentWep.level;
        if (localLevel > 1) {
            tempRect.right++;
            mainBlit(26, tempRect, 61, 43);
        }
        if (localLevel > 2) {
            tempRect.right++;
            mainBlit(26, tempRect, 66, 43);
        }
        //render weapon ammo infobox
        if (currentWep.maxAmmo) {
            //draw box
            tempRect.left = 120;
            tempRect.up = 152;
            tempRect.right = 168;
            tempRect.down = 167;
            mainBlit(26, tempRect, 93, 15);
            //draw numbers
            writeNum_l_al(96, 18, currentWep.currentAmmo);
            writeText_al("/", 113, 18);
            writeNum_r_al(137, 18, currentWep.maxAmmo);
        }
    } //if there is a weapon
}

void Player::renderInventory()
{
    invoFlash ^= 1;
    //render the weapons
    int iconsRendered = 0;
    for (int i = 0; i < 8; i++) {
        if (weaponArray[i].ID) {
            weaponArray[i].renderIcon_large(98 + iconsRendered * 80, 50);
            iconsRendered++;
        }
    }
    //render the selected weapon icon
    Rect frameRect = {0, 176, 80, 256};
    if (invoFlash && !selectingItems) {
        frameRect.left += 80;
        frameRect.right += 80;
    }
    mainBlit(BMP_TEXTBOX, frameRect, 96 + 80 * currentWeapon, 50);

    //render the inventory
    for (int i = 0; i < 32; i++) {
        if (itemArray[i]) {
            //64x32
            frameRect.left = (itemArray[i] % 8) * 64;
            frameRect.right = frameRect.left + 64;
            frameRect.up = (itemArray[i]/8) * 32;
            frameRect.down = frameRect.up + 32;
            mainBlit(BMP_ITEM, frameRect, 96 + 64*(i%8), 152 + 32*(i/8));
        }
    }
    //render the selected item icon
    frameRect.left = 160;
    frameRect.up = 176;
    frameRect.right = frameRect.left + 64;
    if (invoFlash && selectingItems) {
        frameRect.up += 32;
    }
    frameRect.down = frameRect.up + 32;

    mainBlit(BMP_TEXTBOX, frameRect, 96 + 64*(selectedItem%8), 152 + 32*(selectedItem/8));
}

void Player::act(int canControl)
{
    if (stateFlags & 0x80) {
        if (invincTimer)
            invincTimer--;
        else {
            //if expGained show number & set to 0
            if (expGained && !xpFlashTimer)
            {
                createNumber(&xPos, &yPos, expGained);
                expGained = 0;
            }
        }
        if (canControl) {
            if (!(gameState & 4))
                airManagement();
            agility(canControl);
            weaponArray[currentWeapon].act();
        }
        tileCollisions();
    }
}

void Player::inventoryControl()
{
    if (keyPressed & (KEYLEFT | KEYUP | KEYRIGHT | KEYDOWN)) {
        playSound(SFX_menu_move);
        if (selectingItems) {
            //count items
            int nItem = 0;
            for (; itemArray[nItem] != 0; nItem++);
            if (nItem > 0)
                nItem--;
            if (keyPressed & KEYLEFT) {
                selectedItem--;
                if (selectedItem < 0)
                    selectedItem = 7;
                if (selectedItem > nItem)
                    selectedItem = nItem;
            }
            if (keyPressed & KEYRIGHT) {
                selectedItem++;
                if (selectedItem > nItem)
                    selectedItem = 8*(nItem / 8);
            }
            if (keyPressed & KEYUP) {
                selectedItem -= 8;
                if (selectedItem < 0) {
                    selectedItem += 8;
                    selectingItems = 0;
                }
            }
            if (keyPressed & KEYDOWN) {
                selectedItem += 8;
                if (selectedItem > nItem) {
                    selectedItem -= 8;
                    selectingItems = 0;
                }
            }
            //run the event
            if (selectingItems)
                runEvent(5000+itemArray[selectedItem]);
            else
                runArmsScript();
        } else { //selecting weapons
            //count weapons
            int nWeapon = 0;
            for (; weaponArray[nWeapon].ID != 0; nWeapon++);
            if (nWeapon > 0)
                nWeapon--;

            if (keyPressed & KEYLEFT) {
                currentWeapon--;
                if (currentWeapon < 0)
                    currentWeapon = nWeapon;
            }
            if (keyPressed & KEYRIGHT) {
                currentWeapon++;
                if (currentWeapon > nWeapon)
                    currentWeapon = 0;
            }
            if (keyPressed & KEYUP) {
                selectedItem = selectedItem % 8 + (8 * (selectedItem / 8));
                selectingItems = 1;
            }
            if (keyPressed & KEYDOWN) {
                selectedItem = selectedItem % 8;
                selectingItems = 1;
            }
            //run the script
            if (selectingItems)
                runEvent(5000+itemArray[selectedItem]);
            else
                runArmsScript();;
        }
    }
}

void Player::headBump()
{
    createEffect(xPos, yPos - hitRect.up, 13, 0);
    createEffect(xPos, yPos - hitRect.up, 13, 0);
    playSound(SFX_fx_headbonk);
}

void Player::giveCamera(int speed)
{
    setCamera(&camX, &camY, speed);
}

void Player::addWeaponExp(int amount)
{
    Weapon &cWep = weaponArray[currentWeapon];
    cWep.energy += amount;
    if (cWep.level == 3) {
        if (cWep.energy > cWep.getEnergyToLevel())
            cWep.energy = cWep.getEnergyToLevel();
    } else {
        int expOver;
        int hasLeveld = 0;
        do {
            if (cWep.energy >= cWep.getEnergyToLevel())
            {
                if (cWep.level < 3) {
                    cWep.level++;
                    expOver = cWep.energy - cWep.getEnergyToLevel();
                    cWep.energy = expOver;
                    hasLeveld = 1;
                } else {
                    cWep.energy = cWep.getEnergyToLevel();
                }
            } else {
                expOver = 0;
            }
        } while (expOver > 0);
        if (hasLeveld) {
            playSound(convertFxNum(27));
            createEffect(xPos, yPos, 9, 0);
        }
    }
    xpFlashTimer = 30;
    expGained += amount;
}

void Player::removeWeaponExp(int amount)
{
    Weapon &wep = weaponArray[currentWeapon];
    wep.energy -= amount;
    int hasDeleveld = 0;
    while (wep.energy < 0) {
        if (wep.level == 1) {
            wep.energy = 0;
        } else {
            wep.level--;
            wep.energy = wep.getEnergyToLevel() + wep.energy;
            hasDeleveld = 1;
        }
    }
    if (hasDeleveld)
    {
        createEffect(xPos, yPos, 9, 1);
    }
}

void Player::addAmmo(int weapon, int amount)
{

}

bool Player::hasWeapon(int wepID)
{
	for (int i = 0; i < 8; i++)
	{
		if (weaponArray[i].ID == wepID)
			return true;
	}
	return false;
}


void Player::addHealth(int amount)
{
    maxHealth += amount;
    currentHealth += amount;
}

void Player::heal(int amt)
{
    currentHealth += amt;
    if (currentHealth > maxHealth)
        currentHealth = maxHealth;
}

void Player::takeDamage(int amount)
{
    if (gameState & 2) {
        if (!invincTimer) {
            playSound(SFX_fx_pc_hurt);
            stateFlags &= -2; //remove 'inspecting' flags
            //invinc lasts x80 frames
            invincTimer = 0x80;
            yVel = -0x400;
            currentHealth -= amount;
            //subtract weapon energy
            removeWeaponExp(amount * 2);
            //create damage numbers
            createNumber(&xPos, &yPos, -amount);
            if (currentHealth <= 0) {
                currentHealth = 0;
                playSound(SFX_fx_pc_die);
                stateFlags = 0;
                //create blood splots
                for (int i = 0; i < 6; i++)
                    createEffect(xPos, yPos, 1, 2);
                //TODO create corpse
                runEvent(40);
            }
        }
    }
}

void Player::addItem(int itemNum)
{
    for (int i = 0; i < 32; i++) {
        if (itemArray[i] == 0) {
            itemArray[i] = itemNum;
            return;
        }
    }
}

void Player::removeItem(int itemNum)
{
    for (int i = 0; i < 32; i++) {
        if (itemArray[i] == itemNum) {
            itemArray[i] = 0;
            return;
        }
    }
}

bool Player::hasItem(int itemNum)
{
    for (int i = 0; i < 32; i++) {
        if (itemArray[i] == itemNum) {
            return true;
        }
    }
    return false;
}

void Player::runArmsScript()
{
    runEvent(1000 + weaponArray[currentWeapon].ID);
}

void Player::addEquip(int flag)
{
    equipFlags |= 1 << flag;
}

void Player::removeEquip(int flag)
{
    equipFlags &= ~(1 << flag);
}

bool Player::checkEquip(int flag)
{
    return equipFlags & (1 << flag);
}
/*************************
PLAYER TILE COLLISION FNCS
*************************/

//checks player against all applicable tiles
void Player::tileCollisions()
{
    int startX = xPos >> 13;
    int startY = yPos >> 13;

    collision = 0;
#ifdef DEBUG
    Rect debugRect = {256, 0, 288, 32};
    cameraBlit(5, debugRect, startX * 0x2000 - 0x1000, startY * 0x2000 - 0x1000);
#endif
    char xArray[4] = {0, 1, 0, 1};
    char yArray[4] = {0, 0, 1, 1};
    int tileX, tileY, tileType;
    for (int i = 0; i < 4; i++) {
        tileX = startX + xArray[i];
        tileY = startY + yArray[i];
        tileType = getType(tileX, tileY);

        switch (tileType) {
        case 0x41:
        case 0x43:
        case 0x46:
        case 0x49:
        case 0x4E:
            tileSolid(tileX, tileY);
            break;
        case 0x50:
        case 0x58:
        case 0x51:
        case 0x59:
        case 0x52:
        case 0x5A:
        case 0x53:
        case 0x5B:
        case 0x54:
        case 0x5C:
        case 0x55:
        case 0x5D:
        case 0x56:
        case 0x5E:
        case 0x57:
        case 0x5F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        break;
        case 0x60:
        case 0x68:
            tileWater(tileX, tileY);
            break;
        case 0x70:
        case 0x78:
        case 0x71:
        case 0x79:
        case 0x72:
        case 0x7A:
        case 0x73:
        case 0x7B:
        case 0x74:
        case 0x7C:
        case 0x75:
        case 0x7D:
        case 0x76:
        case 0x7E:
        case 0x77:
        case 0x7F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        tileWater(tileX, tileY);
        break;
        default:
            break;
        } //switch
    } //for each of 4 tiles
}

void Player::tileSolid(int x, int y)
{
    int result = 0;
    int scaleFactor = 0x200;
    int pxPerTile = 0x10;

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos - hitRect.left) < ((x * pxPerTile + 8) * scaleFactor)) &&
            ((xPos - hitRect.right) > ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile + 8) * scaleFactor) + hitRect.right;
        if (xVel <= -0x180)
            xVel = -0x180;
        if (!(keyHeld & KEYLEFT) && xVel <= 0)
            xVel = 0;
        result |= LEFT;
    }

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 8) * scaleFactor)) &&
            ((xPos + hitRect.right) < ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile - 8) * scaleFactor) - hitRect.right;
        if (xVel >= 0x180)
            xVel = 0x180;
        if (!(keyHeld & KEYRIGHT) && xVel >= 0)
            xVel = 0;
        result |= RIGHT;
    }

    if (((xPos - hitRect.right) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos - hitRect.up) < ((y * pxPerTile + 8) * scaleFactor)) &&
            ((yPos - hitRect.up) > ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile + 8) * scaleFactor) + hitRect.up;
        if ((stateFlags & 2) == 0)
            if (yVel <= -0x200)
                headBump();
        if (yVel <= 0)
            yVel = 0;
        result |= UP;
    }

    if (((xPos - hitRect.left) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 8) * scaleFactor)) &&
            ((yPos + hitRect.down) < ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile - 8) * scaleFactor) - hitRect.down;
        if (yVel > 0x400)
            playSound(SFX_fx_thud);
        if (yVel > 0)
            yVel = 0;
        result |= DOWN;
    }
    collision |= result;
}

//this is what happens when I try to translate GIR's
//ASM pseudocode into C++
//oh god it's an abomination
//types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
void Player::tileSlopeFloor(int x, int y, int type)
{
    /*
    int tileLeft = ((x << 4) -8) << 9;
    int tileRight = ((x << 4) +8) << 9;
    int dBound = yPos + hitRect.down;
    int flags = 0;
    int bottom = ((y << 4) + 8) << 9;

    if (xPos < tileLeft)
       return 0;
    if (xPos > tileRight)
       return 0;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type){
       case 2:
          difference = -0x2000;
       case 1:
          difference -= xPos - tileLeft;
          difference /= 2;
          flags |= 0x10;
          break;
       case 3:
          difference = (xPos - tileLeft) / 2;
          flags |= 0x10;
          break;
       case 4:
          difference = -0x2000;
       case 5:
          difference -= tileRight - xPos;
          difference /= 2;
          flags |= 0x20;
          break;
       case 6:
          difference = (tileRight - xPos) / 2;
          flags |= 0x20;
          break;
       case 0:
          break;
    }
    if (type == 0)
    {

    } else if ((bottom + difference) < dBound) {
       yPos = bottom + difference - hitRect.down;
       if (yVel > 0x400)
          playSound(SFX_fx_thud);
       if (yVel > 0)
          yVel = 0;
       flags |= 8;
       return flags;
    }
    return 0;

    [23:28] <@Cataloupe> or not
    [23:28] <@Cataloupe> nevermind
    [23:28] <@Noxid> lol see it is difficult to read
    [23:29] <@Noxid> And yes, this is very "indev"
    [23:29] <@Cataloupe> ok let me explain it to you step by step
    [23:29] <@Noxid> more of an alpha really
    [23:29] <@Cataloupe> the first bit where it checks y velocity
    [23:29] <@Cataloupe> this is because all the tiles this is for is only meant to work if you're going down and not up
    [23:29] <@Cataloupe> so you can jump up through all these tiles
    [23:30] <@Cataloupe> then if it fails that test
    [23:30] <@Cataloupe> if the type is 0 (flat) then there is no work to be done by the tile
    [23:30] <@Cataloupe> so you just return
    [23:31] <@Cataloupe> however if we're not the flat type
    [23:31] <@Cataloupe> then we have to take into consideration x-velocity as well
    [23:31] <@Cataloupe> otherwise we could potentially walk through our slopes
    [23:31] <@Cataloupe> so that's what the x-velocity checks are for
    [23:32] <@Cataloupe> a different one for the different types of slopes (rising or falling)
    [23:32] <@Cataloupe> if we've determined that the tile may interact with the player based on velocity
    [23:32] <@Cataloupe> then we enter range
    [23:33] <@Cataloupe> the first thing we check in range
    [23:33] <@Cataloupe> is if we are within range to act on the player
    [23:33] <@Cataloupe> in terms of x
    [23:34] <@Cataloupe> basically if the player's x-pos is not withing the tile's xbounds
    [23:34] <@Cataloupe> we do nothing
    [23:34] <@Cataloupe> the next section is dedicated to finding the "roof"
    [23:35] <@Cataloupe> the top of the tile in accordance to the player's x-pos
    [23:35] <@Cataloupe> if the type is 0, the calculation is easy and we move on
    [23:36] <@Cataloupe> if not then we find our relative x-pos
    [23:36] <@Cataloupe> and our relative y-pos i think
    [23:37] <@Cataloupe> no wait
    [23:37] <@Cataloupe> we don't find our relative y-pos
    [23:37] <@Cataloupe> we just use our normal y-pos
    [23:37] <@Cataloupe> we use the x-pos to adjust the normal y-pos
    [23:37] <@Cataloupe> to calculate the roof
    */
    int dBound, flags;
    flags = 0;
    //lBound = hitRect.left;
    //rBound = hitRect.right;
    dBound = hitRect.down;
    int eax;
    int edx;

    if (yVel >= 0)
        goto RANGE;
    if (type == 0)
        goto END;
    if (type > 3)
        goto A1;
    if (xVel > 0x40)
        goto RANGE;
    goto END;
A1:
    if (xVel < -0x40)
        goto RANGE;
    else
        goto END;
RANGE:
    eax = ((x << 4) - 8) << 9;
    if (xPos < eax)
        goto END;
    eax += 0x2000;
    if (xPos > eax)
        goto END;
    if (type == 0) {
        eax = ((y << 4) - 8) << 9;
        goto D;
    } //C
    eax = (x << 0xD) - xPos;
    edx = y << 0xD;
    if (type > 3)
        goto E;
    flags |= 0x80000;
    if (type == 3)
        goto F;
    eax = (eax >> 1) + edx;
    if (type == 2)
        goto G;
    eax += 0x800;
    goto D;
G:
    eax -= 0x800;
    goto D;
F:
    eax = eax + edx - 0x200;
    goto D;
F2:
    eax = eax + edx - 0x380;
    goto D;
E:
    flags |= 0x10000;
    eax = -eax;
    if (type == 6)
        goto F2;
    eax = (eax >> 1) + edx;
    if (type == 4)
        goto G;
    eax += 0x800;
D:
    edx = ((y << 0xD) - 0x1000);
    if (eax >= edx)
        goto LIMIT;
    eax = edx;
LIMIT:
    edx = yPos + dBound;
    if (edx < eax)
        goto END;
    eax += 0xA00;
    if (edx >= eax)
        goto END;
    eax -= (0xA00 + dBound);
    yPos = eax;
    if (!(equipFlags & 1))
        goto H;
    if (type == 0)
        goto H;
    if (type > 3)
        goto I;
    if (type == 3)
        goto J;
    xPos -= 0xB;
    yPos += 6;
    xVel -= 0xA;
    goto H;
J:
    xPos -= 0x1B;
    yPos += 0x1B;
    xVel -= 0x1A;
    goto H;
I:
    if (type == 6)
        goto K;
    xPos += 0xB;
    yPos += 6;
    xVel += 0xA;
K:
    xPos += 0x1B;
    yPos += 0x1B;
    xVel += 0x1A;
H:
    if (xVel > 0x2FF)
        xVel = 0x2FF;
    if (xVel < -0x2FF)
        xVel = -0x2FF;
    if (yVel > 0x400)
        playSound(SFX_fx_thud);
    if (yVel > 0)
        yVel = 0;
    flags |= 8;
END:
    collision |= flags;
}

void Player::tileSlopeRoof(int x, int y, int type)
{
    //int lBound = xPos - hitRect.left;
    int tileLeft = ((x << 4) -8) << 9;
    //int rBound = xPos + hitRect.right;
    int tileRight = ((x << 4) +8) << 9;
    int uBound = yPos - hitRect.up;
    int flags = 0;
    int top = ((y << 4) - 8) << 9;

    if (xPos < tileLeft)
        return;
    if (xPos > tileRight)
        return;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type) {
    case 1:
        difference = 0x2000;
    case 2:
        difference += tileRight - xPos;
        difference /= 2;
        flags |= 0x40;
        break;
    case 3:
        difference = tileRight - xPos;
        flags |= 0x40;
        break;
    case 5:
        difference = 0x2000;
    case 4:
        difference += xPos - tileLeft;
        difference /= 2;
        flags |= 0x80;
        break;
    case 6:
        difference = xPos - tileLeft;
        flags |= 0x80;
        break;
    }
    if ((difference + top) > uBound) {
        yPos = top + difference + hitRect.up;
        if (!(stateFlags & 2))
            if (yVel <= -0x200)
                headBump();
        if (yVel < 0)
            yVel = 0;
        collision |= flags;
    }
}

void Player::tileWater(int x, int y)
{
    if ((xPos - hitRect.right < (0x10 * x + 5) << 9) &&
            (xPos + hitRect.right > (0x10 * x - 5) << 9) &&
            (yPos - hitRect.up < (0x10 * y + 5) << 9) &&
            (yPos + hitRect.down > y << 13))
        collision |= 0x100;
}

/*********************************
AGILITY / PLAYER CONTROL FUNCTIONS
*********************************/

void Player::simpleAgility()
{
    if (keyHeld & KEYLEFT)
        xPos -= 0x200;
    if (keyHeld & KEYRIGHT)
        xPos += 0x200;
    if (keyHeld & KEYUP)
        yPos -= 0x200;
    if (keyHeld & KEYDOWN)
        yPos += 0x200;
}

//This function handles what's commonly called the "Agility" code.
void Player::agility(int canControl)
{
    int jumpSpeed;
    int walkSpeed;
    int friction;
    int gravity;
    int airControl;
    int maxRunSpeed;
    int gravLow;
    if (!(stateFlags & 2)) {
        if (collision & 0x100) {
            maxRunSpeed = 0x196;
            gravity = 0x28;
            gravLow = 0x10;
            jumpSpeed = 0x280;
            walkSpeed = 0x2A;
            airControl = 0x10;
            friction = 0x19;
        } else {
            maxRunSpeed = 0x32C;
            gravity = 0x50;
            gravLow = 0x20;
            jumpSpeed = 0x500;
            walkSpeed = 0x55;
            airControl = 0x20;
            friction = 0x33;
        }
        generateQmark = 0;
        //booster stuff
        if (!canControl)
            boostState = 0;
        //keypresses
        if (collision & 8 || collision & 0x10 || collision & 0x20) {
            boostState = 0;
            if (equipFlags & 0x21)
                boosterFuel = 0x32;
            else
                boosterFuel = 0;
            if (canControl) {
                if (keyPressed != KEYDOWN ||
                        keyHeld != KEYDOWN ||
                        stateFlags & 1 ||
                        gameState & 4) {
                    if (keyHeld != KEYDOWN) {
                        if (keyHeld & KEYLEFT) {
                            if (xVel > -maxRunSpeed)
                                xVel -= walkSpeed;
                        }
                        if (keyHeld & KEYRIGHT) {
                            if (xVel < maxRunSpeed)
                                xVel += walkSpeed;
                        }
                    }
                } else {
                    stateFlags |= 1;
                    generateQmark = 1;
                }
            } //if (can control)
            if (!(stateFlags & 0x20)) {
                if (xVel < 0) {
                    if (xVel <= -friction)
                        xVel += friction;
                    else
                        xVel = 0;
                }
                if (xVel > 0) {
                    if (xVel >= friction)
                        xVel -= friction;
                    else
                        xVel = 0;
                }
            } //if (state &20)
        } else { //if (colliding with ground or floor slope)
            if (canControl) {
                if ((equipFlags & 0x21) &&
                        (keyHeld & KEYJUMP) &&
                        (boosterFuel)) {
                    if (equipFlags & 1) {
                        boostState = 1;
                        if (yVel > 0x100)
                            yVel >>= 1;
                    } else if (keyHeld & KEYUP) {
                        boostState = 2;
                        xVel = 0;
                        yVel = -BOOSTSPEED;
                    } else if (keyHeld & KEYLEFT) {
                        boostState = 1;
                        yVel = 0;
                        xVel = -BOOSTSPEED;
                    } else  if (keyHeld & KEYRIGHT) {
                        boostState = 1;
                        yVel = 0;
                        xVel = BOOSTSPEED;
                    } else if (keyHeld & KEYDOWN) {
                        boostState = 3;
                        xVel = 0;
                        yVel = BOOSTSPEED;
                    } else {
                        boostState = 2;
                        xVel = 0;
                        yVel = -BOOSTSPEED;
                    }
                }// if (equip & 21)
                if (keyHeld & KEYLEFT) {
                    if (xVel > -maxRunSpeed)
                        xVel -= airControl;
                    stateFlags |= 0x1000;
                    stateFlags &= -0x4001;
                }
                if (keyHeld & KEYRIGHT) {
                    if (xVel < maxRunSpeed)
                        xVel += airControl;
                    stateFlags |= 0x4000;
                    stateFlags &= -0x1001;
                }
            } //if (canControl)
            if ((equipFlags & 0x20) &&
                    boostState &&
                    (!(keyHeld & KEYJUMP) || !boosterFuel)) {
                if (boostState == 1) {
                    xVel >>= 1;
                } else if (boostState == 2) {
                    yVel >>= 1;
                }
            } //if (equip & 20) && (...
            if (!boosterFuel || !(keyHeld & KEYJUMP))
                boostState = 0;
        } //else
        if (canControl) {
            if (keyHeld & KEYUP)
                stateFlags |= 0x2000;
            else
                stateFlags &= -0x2001;
            if ((keyHeld & KEYDOWN) && !(collision & 8))
                stateFlags |= 0x8000;
            else
                stateFlags &= -0x8001;
            //jumping
            if (keyPressed & KEYJUMP) {
                if ((collision & 0x38) && !(collision & 0x2000)) {
                    yVel = -jumpSpeed;
                    playSound(SFX_fx_jump);
                }
            }
        }
        if (canControl) {
            if (keyHeld & (KEYSHOOT | KEYJUMP | KEYUP | KEYRIGHT | KEYLEFT))
                stateFlags &= -2;
        }
        if (boostState && boosterFuel)
            --boosterFuel;
        //in current
        if (collision & 0x1000)
            xVel -= 136;
        if (collision & 0x2000)
            yVel -= 128;
        if (collision & 0x4000)
            xVel += 136;
        if (collision & 0x8000)
            yVel += 85;
        if ((equipFlags & 0x20) && boostState) {
            switch (boostState) {
            case 1:
                if (collision & 5)
                    yVel = -0x100;
                if (stateFlags & 0x1000)
                    xVel -= 0x20;
                if (stateFlags & 0x4000)
                    xVel += 0x20;
                if ((keyPressed & KEYJUMP) || ((boosterFuel % 3) == 1)) {
                    if (stateFlags & 0x1000)
                        createEffect(xPos + 0x400, yPos + 0x400, 7, 2);
                    else
                        createEffect(xPos - 0x400, yPos + 0x400, 7, 0);
                    playSound(SFX_fx_splash);
                }
                break;
            case 2:
                yVel -= 0x20;
                if ((keyPressed & KEYJUMP) || ((boosterFuel % 3) == 1)) {
                    createEffect(xPos, yPos + 0xC00, 7, 3);
                    playSound(SFX_fx_boost);
                }
                break;
            case 3:
                if ((keyPressed & KEYJUMP) || ((boosterFuel % 3) == 1)) {
                    createEffect(xPos, yPos + 0xC00, 7, 3);
                    playSound(SFX_fx_boost);
                }
                break;
            }//switch
        } else {
            if (collision & 0x2000) {
                yVel += gravity;
            } else {
                if (equipFlags & 1 && boostState && yVel > -0x800) {
                    yVel -= 0x20;
                    if (!(boosterFuel % 3)) {
                        createEffect(xPos, yPos + hitRect.down / 2, 7, 3);
                        playSound(SFX_fx_boost);
                    }
                    if (collision & 2)
                        yVel = 0x200;
                } else {
                    if (yVel < 0 && canControl && (keyHeld & KEYJUMP))
                        yVel += gravLow;
                    else
                        yVel += gravity;
                }
            }
        }
        if (!canControl || !(keyPressed & KEYJUMP)) {
            if ((collision & 0x10) && (xVel < 0))
                yVel = -xVel;
            if ((collision & 0x20) && (xVel > 0))
                yVel = xVel;
            if ((collision & 8) && (collision & 0x80000) && (xVel < 0))
                yVel = 0x400;
            if ((collision & 8) && (collision & 0x10000) && (xVel > 0))
                yVel = 0x400;
            if ((collision & 8) && (collision & 0x20000) && (collision & 0x40000))
                yVel = 0x400;
        }
        if (!(collision & 0x100) || collision & 0xF000) {
            if (xVel < -BOOSTSPEED)
                xVel = -BOOSTSPEED;
            if (xVel > BOOSTSPEED)
                xVel = BOOSTSPEED;
            if (yVel < -BOOSTSPEED)
                yVel = -BOOSTSPEED;
            if (yVel > BOOSTSPEED)
                yVel = BOOSTSPEED;
        } else {
            if (xVel < -HALFBOOST)
                xVel = -HALFBOOST;
            if (xVel > HALFBOOST)
                xVel = HALFBOOST;
            if (yVel < -HALFBOOST)
                yVel = -HALFBOOST;
            if (yVel > HALFBOOST)
                yVel = HALFBOOST;
        }
        if (!hasSplashed && (collision & 0x100)) {
            int waterDir;
            if (collision & 0x800)
                waterDir = 2;
            else
                waterDir = 0;
            if (collision & 8 || yVel <= -0x200) {
                if (xVel > 0x200 || xVel < -0x200) {
                    for (int i = 0; i < 8; i++) {
                        int waterX = xPos + (random(-8, 8) << 9);
                        int waterVelY = random(-0x200, 0x80);
                        int waterVelX = random(-0x200, 0x200);
                        createNpc(73, waterX, yPos, xVel + waterVelX, waterVelY, waterDir, 0, 1);
                    }
                    playSound(SFX_fx_splash);
                }
            } else {
                for (int i = 0; i < 8; i++) {
                    int waterX = xPos + (random(-8, 8) << 9);
                    int waterVelY = random(-0x200, 0x80) - yVel/2;
                    int waterVelX = random(-0x200, 0x200);
                    createNpc(73, waterX, yPos, xVel + waterVelX, waterVelY, waterDir, 0, 1);
                }
                playSound(SFX_fx_splash);
            }
            hasSplashed = 1;
        }
        if (!(collision & 0x100))
            hasSplashed = 0;
        if (collision & 0x400)
            takeDamage(10);
        if (stateFlags & 0x4000) {
            focusOffsetX += 0x200;
            if (focusOffsetX > 0x8000)
                focusOffsetX = 0x8000;
        } else {
            focusOffsetX -= 0x200;
            if (focusOffsetX < -0x8000)
                focusOffsetX = -0x8000;
        }
        if ((keyHeld & KEYUP) && canControl) {
            focusOffsetY -= 0x200;
            if (focusOffsetY < -0x8000)
                focusOffsetY = -0x8000;
        } else if ((keyHeld & KEYDOWN) && canControl) {
            focusOffsetY += 0x200;
            if (focusOffsetY > 0x8000)
                focusOffsetY = 0x8000;
        } else {
            if (focusOffsetY > 0x200)
                focusOffsetY -= 0x200;
            if (focusOffsetY < -0x200)
                focusOffsetY += 0x200;
        }
        camX = xPos + focusOffsetX;
        camY = yPos + focusOffsetY;

        if (xVel > friction || xVel < -friction)
            xPos += xVel;
        yPos += yVel;
    }
}

void Player::moveTo(int x, int y)
{
    xPos = x << 13;
    yPos = y << 13;
    focusOffsetX = 0;
    focusOffsetY = 0;
    camX = xPos;
    camY = yPos;
}

void Player::airManagement()
{

}
