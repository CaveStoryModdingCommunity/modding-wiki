#pragma once
#ifndef BULLET_H
#define BULLET_H

#include "object.h"
#include "entity.h"
class Bullet: public PhysicalObject
{
public:
    //object variables
    //Rect hitRect; super
    char inUse;
    int flags;
    //int collision; super
    int ID;
    //int xVel; super
    //int yVel; super
    int lifespan;
    int timeElapsed;
    int damage;
    int nHits;
    int direction;
    int scriptState;
    //int scriptTimer
    int frameNum;
    int frameTimer;
    int displayOffsetX;
    int displayOffsetY;

    //class utility functions
    Bullet();
    Bullet(int x, int y, int dir, int ID);
    ~Bullet();
    void draw();
    void tileCollisions();

    //bullet AI functions
    void sixTwo();
    void Bubbler1();
    void Bubbler2();
    void Bubbler3();
};

//holds bullet characteristic data
typedef struct {
    Rect hitRect;
    int displayOffX;
    int displayOffY;
    int flags;
    int hits;
    int damage;
    int lifespan;
} BulletInfo;

//bullet use methods
void bulletInit();
void createBullet(int x, int y, int dir, int ID);
void clearAllBullet();
void drawAllBullet();
void updateAllBullet();
bool bulletExpired(const Bullet &b);
int countBullets();
int countBulletsOfType(int type);
void checkBulletCollision(Entity &e);
#endif
