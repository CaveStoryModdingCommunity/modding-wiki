
#include "general.h"
#include "player.h"
#include "weapon.h"
#include "effect.h"
#include "sfx.h"
#include "graphics.h"
#include "defines.h"
#include "bullet.h"

extern int keyPressed, keyHeld;
extern Player* player;

/**************************************
   Weapon global vars
**************************************/
static int levelArray[NUMWEAPON][LEVELPERWEAPON] = {
    {10, 10, 10,}, //weapon 0 xp
    {10, 10, 10,}, //weapon 1 xp
    {10, 10, 10,}, // ..2
    {10, 10, 10,}, // ..3
    {10, 10, 10,}, // ..4
    {10, 10, 10,}, // ..5
    {10, 10, 10,}, // ..6
    {10, 20, 5,}  // ..7 {bubbler}
};

void (Weapon::*wepFuncArray[]) () = {
    &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::noWeapon,
    &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::bubbler,
    &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::noWeapon, &Weapon::noWeapon,
    &Weapon::pBlaster
};

int Weapon::noAmmoTimer = 50;

/**************************************
   Weapon class utility code
**************************************/
Weapon::Weapon()
{
    ID = 0, level = 0, energy = 0, maxAmmo = 0, currentAmmo = 0, reloadTimer = 0, triggerTimer = 9001;
}

void Weapon::draw(int x, int y, int direction)
{
    //bullet frames 32x48
    Rect frameRect;
    frameRect.left = ID * 48;
    frameRect.right = frameRect.left + 48;

    if (direction & UP)
        frameRect.up = 64;
    else if (direction & DOWN) {
        frameRect.up = 128;
    } else
        frameRect.up = 0;

    if (direction & RIGHT)
        frameRect.up += 32;

    frameRect.down = frameRect.up + 32;
    cameraBlit(BMP_ARMS, frameRect, x - 0x800, y);
}

void Weapon::renderIcon_large(int x, int y)
{
    Rect frameRect = {28 * ID, 0, 28*(ID+1), 28};
    mainBlit(BMP_ARMSITEM, frameRect, x, y);
}

void Weapon::renderIcon_small(int x, int y, bool highlighted)
{
    Rect frameRect = {20*ID, 28, 20*(ID+1), 48};
    if (!highlighted) {
        frameRect.up += 20;
        frameRect.down += 20;
    }
    mainBlit(BMP_ARMSITEM, frameRect, x, y);
}

void Weapon::act()
{
	if (noAmmoTimer > 0)
		noAmmoTimer--;
    (this->*wepFuncArray[ID])();
}

int Weapon::getEnergyToLevel()
{
    return levelArray[ID][level-1];
}

bool Weapon::subtractAmmo(int amt)
{
	if (!maxAmmo)
		return true;
	if ((currentAmmo - amt) < 0) {
		if (!noAmmoTimer) {
			noAmmoTimer = 50;
			createEffect(player->xPos, player->yPos, 16, 0);
			playSound(convertFxNum(37));
		}
		return false;
	} else {
		currentAmmo -= amt;
		return true;
	}
}

void Weapon::addAmmo(int amt)
{
	if (!maxAmmo)
		return;
	currentAmmo += amt;
	if (currentAmmo > maxAmmo)
		currentAmmo = maxAmmo;
}
/*****************************
   Weapon AI codes
*****************************/
void Weapon::noWeapon() {}

void Weapon::bubbler()
{
	int offX, offY, shotDir;
	int shouldFire = 0;
	int levelAdj = level-1;
    switch (levelAdj) {
		case 0:
			if (countBulletsOfType(ID*3 +levelAdj) <= 3) {
				if (keyPressed & KEYSHOOT) {
					if (subtractAmmo(1)) {
						shouldFire = 1;
					}
				}
			}
			if (reloadTimer < 20)
				reloadTimer++;
			else {
				addAmmo(1);
				reloadTimer = 0;
			}
			break;
		case 1:
		case 2:
			if (keyHeld & KEYSHOOT) {
				if (countBulletsOfType(ID*3 +levelAdj) <= 15) {
					triggerTimer++;
					if (triggerTimer >= 7) {
						triggerTimer = 0;
						if (subtractAmmo(1)) {
							shouldFire = 1;
						}
					}
				}
			} else {
				triggerTimer = 7;
				if (reloadTimer < 2)
					reloadTimer++;
				else {
					addAmmo(1);
					reloadTimer = 0;
				}
			}
			break;
		default:
			break;
    }

    if (shouldFire) {
    	int pState = player->stateFlags;
    	if (pState & 0x2000) {//player is facing up
    		offX = -0x200;
    		offY = -0x800;
    		shotDir = 1;
    	} else if (pState & 0x8000) { //player is facing down
			offY = 0xC00;
			shotDir = 3;
			if (pState & 0x1000)
				offX = -0x900;
			else
				offX = 0;
    	} else { //player is facing neither up nor down
			offY = 0x700;
			if (pState & 0x1000) { //left
				offX = -0x1200;
				shotDir = 0;
			} else {
				offX = 0x1000;
				shotDir = 2;
			}
    	}
    	createBullet(player->xPos + offX, player->yPos + offY, shotDir, ID*3 + levelAdj);
    	if (shotDir == 0)
			offX -= 0x600;
		else if (shotDir == 1)
			offY -= 0x600;
		else if (shotDir == 2)
			offX += 0x600;
		else
			offY += 0x600;
		createEffect(player->xPos + offX, player->yPos + offY, 3, 0);
		playSound(SFX_fx_bubble2);
    } //if should fire
}

void Weapon::pBlaster()
{

}
