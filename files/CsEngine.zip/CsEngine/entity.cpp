
#include <stdio.h>
#include <cstring>
#include <math.h>
#include "defines.h"
#include "general.h"
#include "player.h"
#include "entity.h"
#include "map.h"
#include "sfx.h"
#include "tsc.h"
#include "bullet.h"
#include "effect.h"
#include "numobj.h"

#include <list>

//pxe stuff
PxeFile::PxeFile()
{
    memset(this, 0, sizeof(*this));
}

/*original pxe file format
byte 0-3 header "PXE"
byte 4-5 numEntities
byte 6-7 padding
for each entity:
short xPos (tile)
short yPos (tile)
short flagID
short eventNum
short entity type
short flags
12b per entity
*/

PxeFile::PxeFile(const char *filename)
{
    FILE *theFile = fopen(filename, "rb");
    if (!theFile) {
        char strBuf[64] = "PxeFile couldn't find ";
        strcat(strBuf, filename);
        fatalError(strBuf);
    }
    fread(header, 1, 4, theFile);
    switch (header[3]) {
    case 0: //original pxe format
        fread(&numEntity, 2, 2, theFile);
        entityArray = new PxeEntry[numEntity];
        for (int i = 0; i < numEntity; i++) {
            fread(&entityArray[i], 12, 1, theFile);
            entityArray[i].filePos = i;
            entityArray[i].layer = 1;
        }
        break;
    case 0x10: //new pxe format, w/ layers
        fread(&numEntity, 2, 1, theFile);
        entityArray = new PxeEntry[numEntity];
        for (int i = 0; i < numEntity; i++) {
            fread(&entityArray[i], 13, 1, theFile);
            entityArray[i].filePos = i;
        }
    default:
        break;
    }
}

PxeFile::~PxeFile()
{
    if (entityArray)
        delete[] entityArray;
}

bool PxeEntry::operator== (const PxeEntry &other)
{
    return (other.filePos == this->filePos);
}

//entity stuff
#define NUM_ENTITY_TYPE 361
void (Entity::*funcArray[NUM_ENTITY_TYPE]) () = {
    &Entity::npcAct0, &Entity::npcAct1, &Entity::npcAct2, &Entity::npcAct3, &Entity::npcAct4, &Entity::npcAct5,
    &Entity::npcAct6, &Entity::npcAct7, &Entity::npcAct8, &Entity::npcAct9, &Entity::npcAct10,
    &Entity::npcAct11, &Entity::npcAct12, &Entity::npcAct13, &Entity::npcAct14, &Entity::npcAct15, &Entity::npcAct16, &Entity::npcAct17, &Entity::npcAct18, &Entity::npcAct19, &Entity::npcAct20,
    &Entity::npcAct21, &Entity::npcAct22, &Entity::npcAct23, &Entity::npcAct24, &Entity::npcAct25, &Entity::npcAct26, &Entity::npcAct27, &Entity::npcAct28, &Entity::npcAct29, &Entity::npcAct30,
    &Entity::npcAct31, &Entity::npcAct32, &Entity::npcAct33, &Entity::npcAct34, &Entity::npcAct35, &Entity::npcAct36, &Entity::npcAct37, &Entity::npcAct38, &Entity::npcAct39, &Entity::npcAct40,
    &Entity::npcAct41, &Entity::npcAct42, &Entity::npcAct43, &Entity::npcAct44, &Entity::npcAct45, &Entity::npcAct46, &Entity::npcAct47, &Entity::npcAct48, &Entity::npcAct49, &Entity::npcAct50,
    &Entity::npcAct51, &Entity::npcAct52, &Entity::npcAct53, &Entity::npcAct54, &Entity::npcAct55, &Entity::npcAct56, &Entity::npcAct57, &Entity::npcAct58, &Entity::npcAct59, &Entity::npcAct60,
    &Entity::npcAct61, &Entity::npcAct62, &Entity::npcAct63, &Entity::npcAct64, &Entity::npcAct65, &Entity::npcAct66, &Entity::npcAct67, &Entity::npcAct68, &Entity::npcAct69, &Entity::npcAct70,
    &Entity::npcAct71, &Entity::npcAct72, &Entity::npcAct73, &Entity::npcAct74, &Entity::npcAct75, &Entity::npcAct76, &Entity::npcAct77, &Entity::npcAct78, &Entity::npcAct79, &Entity::npcAct80,
    &Entity::npcAct81, &Entity::npcAct82, &Entity::npcAct83, &Entity::npcAct84, &Entity::npcAct85, &Entity::npcAct86, &Entity::npcAct87, &Entity::npcAct88, &Entity::npcAct89, &Entity::npcAct90,
    &Entity::npcAct91, &Entity::npcAct92, &Entity::npcAct93, &Entity::npcAct94, &Entity::npcAct95, &Entity::npcAct96, &Entity::npcAct97, &Entity::npcAct98, &Entity::npcAct99, &Entity::npcAct100,
    &Entity::npcAct101, &Entity::npcAct102, &Entity::npcAct103, &Entity::npcAct104, &Entity::npcAct105, &Entity::npcAct106, &Entity::npcAct107, &Entity::npcAct108, &Entity::npcAct109, &Entity::npcAct110,
    &Entity::npcAct111, &Entity::npcAct112, &Entity::npcAct113, &Entity::npcAct114, &Entity::npcAct115, &Entity::npcAct116, &Entity::npcAct117, &Entity::npcAct118, &Entity::npcAct119, &Entity::npcAct120,
    &Entity::npcAct121, &Entity::npcAct122, &Entity::npcAct123, &Entity::npcAct124, &Entity::npcAct125, &Entity::npcAct126, &Entity::npcAct127, &Entity::npcAct128, &Entity::npcAct129, &Entity::npcAct130,
    &Entity::npcAct131, &Entity::npcAct132, &Entity::npcAct133, &Entity::npcAct134, &Entity::npcAct135, &Entity::npcAct136, &Entity::npcAct137, &Entity::npcAct138, &Entity::npcAct139, &Entity::npcAct140,
    &Entity::npcAct141, &Entity::npcAct142, &Entity::npcAct143, &Entity::npcAct144, &Entity::npcAct145, &Entity::npcAct146, &Entity::npcAct147, &Entity::npcAct148, &Entity::npcAct149, &Entity::npcAct150,
    &Entity::npcAct151, &Entity::npcAct152, &Entity::npcAct153, &Entity::npcAct154, &Entity::npcAct155, &Entity::npcAct156, &Entity::npcAct157, &Entity::npcAct158, &Entity::npcAct159, &Entity::npcAct160,
    &Entity::npcAct161, &Entity::npcAct162, &Entity::npcAct163, &Entity::npcAct164, &Entity::npcAct165, &Entity::npcAct166, &Entity::npcAct167, &Entity::npcAct168, &Entity::npcAct169, &Entity::npcAct170,
    &Entity::npcAct171, &Entity::npcAct172, &Entity::npcAct173, &Entity::npcAct174, &Entity::npcAct175, &Entity::npcAct176, &Entity::npcAct177, &Entity::npcAct178, &Entity::npcAct179, &Entity::npcAct180,
    &Entity::npcAct181, &Entity::npcAct182, &Entity::npcAct183, &Entity::npcAct184, &Entity::npcAct185, &Entity::npcAct186, &Entity::npcAct187, &Entity::npcAct188, &Entity::npcAct189, &Entity::npcAct190,
    &Entity::npcAct191, &Entity::npcAct192, &Entity::npcAct193, &Entity::npcAct194, &Entity::npcAct195, &Entity::npcAct196, &Entity::npcAct197, &Entity::npcAct198, &Entity::npcAct199, &Entity::npcAct200,
    &Entity::npcAct201, &Entity::npcAct202, &Entity::npcAct203, &Entity::npcAct204, &Entity::npcAct205, &Entity::npcAct206, &Entity::npcAct207, &Entity::npcAct208, &Entity::npcAct209, &Entity::npcAct210,
    &Entity::npcAct211, &Entity::npcAct212, &Entity::npcAct213, &Entity::npcAct214, &Entity::npcAct215, &Entity::npcAct216, &Entity::npcAct217, &Entity::npcAct218, &Entity::npcAct219, &Entity::npcAct220,
    &Entity::npcAct221, &Entity::npcAct222, &Entity::npcAct223, &Entity::npcAct224, &Entity::npcAct225, &Entity::npcAct226, &Entity::npcAct227, &Entity::npcAct228, &Entity::npcAct229, &Entity::npcAct230,
    &Entity::npcAct231, &Entity::npcAct232, &Entity::npcAct233, &Entity::npcAct234, &Entity::npcAct235, &Entity::npcAct236, &Entity::npcAct237, &Entity::npcAct238, &Entity::npcAct239, &Entity::npcAct240,
    &Entity::npcAct241, &Entity::npcAct242, &Entity::npcAct243, &Entity::npcAct244, &Entity::npcAct245, &Entity::npcAct246, &Entity::npcAct247, &Entity::npcAct248, &Entity::npcAct249, &Entity::npcAct250,
    &Entity::npcAct251, &Entity::npcAct252, &Entity::npcAct253, &Entity::npcAct254, &Entity::npcAct255, &Entity::npcAct256, &Entity::npcAct257, &Entity::npcAct258, &Entity::npcAct259, &Entity::npcAct260,
    &Entity::npcAct261, &Entity::npcAct262, &Entity::npcAct263, &Entity::npcAct264, &Entity::npcAct265, &Entity::npcAct266, &Entity::npcAct267, &Entity::npcAct268, &Entity::npcAct269, &Entity::npcAct270,
    &Entity::npcAct271, &Entity::npcAct272, &Entity::npcAct273, &Entity::npcAct274, &Entity::npcAct275, &Entity::npcAct276, &Entity::npcAct277, &Entity::npcAct278, &Entity::npcAct279, &Entity::npcAct280,
    &Entity::npcAct281, &Entity::npcAct282, &Entity::npcAct283, &Entity::npcAct284, &Entity::npcAct285, &Entity::npcAct286, &Entity::npcAct287, &Entity::npcAct288, &Entity::npcAct289, &Entity::npcAct290,
    &Entity::npcAct291, &Entity::npcAct292, &Entity::npcAct293, &Entity::npcAct294, &Entity::npcAct295, &Entity::npcAct296, &Entity::npcAct297, &Entity::npcAct298, &Entity::npcAct299, &Entity::npcAct300,
    &Entity::npcAct301, &Entity::npcAct302, &Entity::npcAct303, &Entity::npcAct304, &Entity::npcAct305, &Entity::npcAct306, &Entity::npcAct307, &Entity::npcAct308, &Entity::npcAct309, &Entity::npcAct310,
    &Entity::npcAct311, &Entity::npcAct312, &Entity::npcAct313, &Entity::npcAct314, &Entity::npcAct315, &Entity::npcAct316, &Entity::npcAct317, &Entity::npcAct318, &Entity::npcAct319, &Entity::npcAct320,
    &Entity::npcAct321, &Entity::npcAct322, &Entity::npcAct323, &Entity::npcAct324, &Entity::npcAct325, &Entity::npcAct326, &Entity::npcAct327, &Entity::npcAct328, &Entity::npcAct329, &Entity::npcAct330,
    &Entity::npcAct331, &Entity::npcAct332, &Entity::npcAct333, &Entity::npcAct334, &Entity::npcAct335, &Entity::npcAct336, &Entity::npcAct337, &Entity::npcAct338, &Entity::npcAct339, &Entity::npcAct340,
    &Entity::npcAct341, &Entity::npcAct342, &Entity::npcAct343, &Entity::npcAct344, &Entity::npcAct345, &Entity::npcAct346, &Entity::npcAct347, &Entity::npcAct348, &Entity::npcAct349, &Entity::npcAct350,
    &Entity::npcAct351, &Entity::npcAct352, &Entity::npcAct353, &Entity::npcAct354, &Entity::npcAct355, &Entity::npcAct356, &Entity::npcAct357, &Entity::npcAct358, &Entity::npcAct359, &Entity::npcAct360,
};

extern int gameState;

//lists
using namespace std;
list<Entity> npcLayer0;
list<Entity> npcLayer1;
list<Entity> npcLayer2;
list<Entity> npcLayer3;

unsigned short *npctbl_Flags = NULL;
unsigned short *npctbl_Health = NULL;
unsigned char *npctbl_Tileset = NULL;
unsigned char *npctbl_DeathSound = NULL;
unsigned char *npctbl_HurtSound = NULL;
unsigned char *npctbl_Size = NULL;
unsigned int *npctbl_Exp = NULL;
unsigned int *npctbl_Damage = NULL;
unsigned char *npctbl_Hitbox = NULL;
unsigned char *npctbl_Displaybox =  NULL;

extern Player *player;

//void eSetPlayer(Player *currentChar) {player = currentChar;}

//Entity *testEntity;
int maxListSize;

Entity::Entity()
{
    memset(this, 0, sizeof(*this));
}

Entity::~Entity()
{
    if (isCamera(&xPos, &yPos)) {
        int *p1 = NULL;
        setCamera(p1, p1, 16);
    }
}

void Entity::draw()
{
    cameraBlit(gfxNum, frameRect, xPos - displayOffsetX, yPos - displayOffsetY);
}

/* In bullet class (as in original CS code)
void Entity::takeDamage(int amount)
{
    if (health > amount) { //if it won't kill us
        damageTaken += amount;
        health -= amount;
        playSound(convertFxNum(hurtSound));
    } else {
        damageTaken += health;
        playSound(convertFxNum(deathSound));
        inUse = 0;
        createSmoke(xPos, yPos, displayOffsetX, size * 3);
    }
}
*/

void Entity::kill()
{
	char smokeArray[] = {0, 3, 7, 12};
	playSound(convertFxNum(deathSound));
	createExplosion(xPos, yPos, displayOffsetX, smokeArray[size]);
	if (experience)
	{
		int reward = random(1, 5);
		int hLevel = experience <= 6 ? 1 : 3;
		switch (reward) {
			case 1: //heart
				spawnHeart(xPos, yPos, hLevel * 2);
				break;
			case 2:
				if (spawnMissles(xPos, yPos, hLevel))
					break;
			default:
				spawnExperience(xPos, yPos, experience);
		}
	}
	//flagPlus(flagID);
	if (flags & 0x8000)
	{
		if (damageTaken)
			createNumber(&xPos, &yPos, damageTaken);
		become_npc003();
	} else {
		inUse = 0;
	}
}

void Entity::become_npc003()
{
	entityID = 3;
	flags = 0;
	getNpcTblData(this, 3);
	scriptState = 0;
	scriptTimer = 0;
	inUse = 0x80;
	damageTaken = 0;
}

void entityInit(int maxPerList)
{
    maxListSize = maxPerList;
    //testEntity = new Entity();
    //load npc.tbl
    char filebuf[128] = {0};
    sprintf(filebuf, "%s/npc.tbl", dataDir);
    FILE *npcTable = fopen(filebuf, "rb");
    //read flags
    if (npctbl_Flags)
        delete[] npctbl_Flags;
    npctbl_Flags = new unsigned short[NUM_ENTITY_TYPE];
    fread(npctbl_Flags, 2, NUM_ENTITY_TYPE, npcTable);
    //read health
    if (npctbl_Health)
        delete[] npctbl_Health;
    npctbl_Health = new unsigned short[NUM_ENTITY_TYPE];
    fread(npctbl_Health, 2, NUM_ENTITY_TYPE, npcTable);
    //read tilesets
    if (npctbl_Tileset)
        delete[] npctbl_Tileset;
    npctbl_Tileset = new unsigned char[NUM_ENTITY_TYPE];
    fread(npctbl_Tileset, 1, NUM_ENTITY_TYPE, npcTable);
    //read death sounds
    if (npctbl_DeathSound)
        delete[] npctbl_DeathSound;
    npctbl_DeathSound = new unsigned char[NUM_ENTITY_TYPE];
    fread(npctbl_DeathSound, 1, NUM_ENTITY_TYPE, npcTable);
    //read hurt sound
    if (npctbl_HurtSound)
        delete[] npctbl_HurtSound;
    npctbl_HurtSound = new unsigned char[NUM_ENTITY_TYPE];
    fread(npctbl_HurtSound, 1, NUM_ENTITY_TYPE, npcTable);
    //read size (death smoke)
    if (npctbl_Size)
        delete[] npctbl_Size;
    npctbl_Size = new unsigned char[NUM_ENTITY_TYPE];
    fread(npctbl_Size, 1, NUM_ENTITY_TYPE, npcTable);
    //read exp
    if (npctbl_Exp)
        delete[] npctbl_Exp;
    npctbl_Exp = new unsigned int[NUM_ENTITY_TYPE];
    fread(npctbl_Exp, 4, NUM_ENTITY_TYPE, npcTable);
    //read damage
    if (npctbl_Damage)
        delete[] npctbl_Damage;
    npctbl_Damage = new unsigned int[NUM_ENTITY_TYPE];
    fread(npctbl_Damage, 4, NUM_ENTITY_TYPE, npcTable);
    //read hitbox sizes
    if (npctbl_Hitbox)
        delete[] npctbl_Hitbox;
    npctbl_Hitbox = new unsigned char[NUM_ENTITY_TYPE*4];
    fread(npctbl_Hitbox, 1, NUM_ENTITY_TYPE*4, npcTable);
    //read displaybox sizes
    if (npctbl_Displaybox)
        delete[] npctbl_Displaybox;
    npctbl_Displaybox = new unsigned char[NUM_ENTITY_TYPE*4];
    fread(npctbl_Displaybox, 1, NUM_ENTITY_TYPE*4, npcTable);

    fclose(npcTable);
}

void clearNpcList()
{
    npcLayer0.clear();
    npcLayer1.clear();
    npcLayer2.clear();
    npcLayer3.clear();
}

void updateAllNpc()
{
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity &currentEntity = *it;
        currentEntity.update();
    }
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity &currentEntity = *it;
        currentEntity.update();
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity &currentEntity = *it;
        currentEntity.update();
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity &currentEntity = *it;
        currentEntity.update();
    }

    //do no action if entity is gone
    npcLayer0.remove_if(isDead);
    npcLayer1.remove_if(isDead);
    npcLayer2.remove_if(isDead);
    npcLayer3.remove_if(isDead);

    //This occurs after all entityvplayer collision checks; if none occur, make the mark.
    if (player->generateQmark)
        createEffect(player->xPos, player->yPos, 8, 0);
}

void Entity::update()
{
   tileCollisions();
   (this->*funcArray[entityID])();
   if (flags & 0x20)
      checkBulletCollision(*this);
   playerCollision();
   if (hitTimer) {
      hitTimer--;
   } else {
      if (damageTaken) {
         createNumber(&xPos, &yPos, damageTaken);
         damageTaken = 0;
      }
   }

}

void Entity::tileCollisions()
{
    int startX = xPos >> 13;
    int startY = yPos >> 13;
    collision = 0;
    char xArray[9] = {0,1,0,1,2,2,0,1,2};
    char yArray[9] = {0,0,1,1,0,1,2,2,2};
    int numChecks;
    if (size < 3)
        numChecks = 4;
    else
        numChecks = 9;

    int tileX, tileY, tileType;
    for (int i = 0; i < numChecks; i++) {
        tileX = startX + xArray[i];
        tileY = startY + yArray[i];
        tileType = getType(tileX, tileY);

        switch (tileType) {
        case 0x44:
        case 0x4C:
            if (flags & 2)
                break;
        case 0x03:
        case 0x0B:
        case 0x04:
        case 0x0C:
        case 0x41:
        case 0x49:
        case 0x43:
        case 0x4B:
        case 0x61:
        case 0x69:
        case 0x63:
        case 0x6B:
        case 0x64:
        case 0x6C:
            if (!(flags & 8))
                tileSolid(tileX, tileY);
            break;
        case 0x50:
        case 0x58:
        case 0x51:
        case 0x59:
        case 0x52:
        case 0x5A:
        case 0x53:
        case 0x5B:
        case 0x54:
        case 0x5C:
        case 0x55:
        case 0x5D:
        case 0x56:
        case 0x5E:
        case 0x57:
        case 0x5F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        break;
        case 0x60:
        case 0x68:
            tileWater(tileX, tileY);
            break;
        case 0x70:
        case 0x78:
        case 0x71:
        case 0x79:
        case 0x72:
        case 0x7A:
        case 0x73:
        case 0x7B:
        case 0x74:
        case 0x7C:
        case 0x75:
        case 0x7D:
        case 0x76:
        case 0x7E:
        case 0x77:
        case 0x7F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        tileWater(tileX, tileY);
        break;
        default:
            break;

        } //switch

    } //for each tile
    //modify velocity if tiles collided with
    if (collision & DOWN)
		if (yVel > 0)
			yVel = 0;
	if (collision & UP)
        if (yVel <= 0)
            yVel = 0;
	if (collision & LEFT)
        if (xVel <= -0x180)
            xVel = -0x180;
	if (collision & RIGHT)
		if (xVel >= 0x180)
            xVel = 0x180;
    //delete[] xArray;
    //delete[] yArray;
}
/* ************************
This code moved up to Object class

void Entity::eTileSolid(int x, int y)
{
    int result = 0;
    int scaleFactor = 0x200;
    int pxPerTile = 0x10;

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos - hitRect.left) < ((x * pxPerTile + 8) * scaleFactor)) &&
            ((xPos - hitRect.right) > ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile + 8) * scaleFactor) + hitRect.right;
        if (xVel <= -0x180)
            xVel = -0x180;
        result |= LEFT;
    }

    if (((yPos - hitRect.up) < ((y * pxPerTile + 4) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 4) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 8) * scaleFactor)) &&
            ((xPos + hitRect.right) < ((x * pxPerTile) * scaleFactor))) {
        xPos = ((x * pxPerTile - 8) * scaleFactor) - hitRect.right;
        if (xVel >= 0x180)
            xVel = 0x180;
        result |= RIGHT;
    }

    if (((xPos - hitRect.right) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos - hitRect.up) < ((y * pxPerTile + 8) * scaleFactor)) &&
            ((yPos - hitRect.up) > ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile + 8) * scaleFactor) + hitRect.up;
        if (yVel <= 0)
            yVel = 0;
        result |= UP;
    }

    if (((xPos - hitRect.left) < ((x * pxPerTile + 5) * scaleFactor)) &&
            ((xPos + hitRect.right) > ((x * pxPerTile - 5) * scaleFactor)) &&
            ((yPos + hitRect.down) > ((y * pxPerTile - 8) * scaleFactor)) &&
            ((yPos + hitRect.down) < ((y * pxPerTile) * scaleFactor))) {
        yPos = ((y * pxPerTile - 8) * scaleFactor) - hitRect.down;
        if (yVel > 0)
            yVel = 0;
        result |= DOWN;
    }
    collision |= result;
}

void Entity::eTileSlopeFloor(int x, int y, int type)
{
    int tileLeft = ((x << 4) -8) << 9;
    int tileRight = ((x << 4) +8) << 9;
    int dBound = yPos + hitRect.down;
    int flags = 0;
    int bottom = ((y << 4) + 8) << 9;

    if (xPos < tileLeft)
        return;
    if (xPos > tileRight)
        return;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type) {
    case 2:
        difference = -0x2000;
    case 1:
        difference -= xPos - tileLeft;
        difference /= 2;
        flags |= 0x10;
        break;
    case 3:
        difference = (xPos - tileLeft) / 2;
        flags |= 0x10;
        break;
    case 4:
        difference = -0x2000;
    case 5:
        difference -= tileRight - xPos;
        difference /= 2;
        flags |= 0x20;
        break;
    case 6:
        difference = (tileRight - xPos) / 2;
        flags |= 0x20;
        break;
    case 0:
        break;
    }
    if (type == 0) {

    } else if ((bottom + difference) < dBound) {
        yPos = bottom + difference - hitRect.down;
        if (yVel > 0)
            yVel = 0;
        flags |= 8;
        collision |= flags;
    }
}

void Entity::eTileSlopeRoof(int x, int y, int type)
{
    int tileLeft = ((x << 4) -8) << 9;
    int tileRight = ((x << 4) +8) << 9;
    int uBound = yPos - hitRect.up;
    int flags = 0;
    int top = ((y << 4) - 8) << 9;

    if (xPos < tileLeft)
        return;
    if (xPos > tileRight)
        return;

    int difference = 0;
    //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
    switch (type) {
    case 1:
        difference = 0x2000;
    case 2:
        difference += tileRight - xPos;
        difference /= 2;
        flags |= 0x40;
        break;
    case 3:
        difference = tileRight - xPos;
        flags |= 0x40;
        break;
    case 5:
        difference = 0x2000;
    case 4:
        difference += xPos - tileLeft;
        difference /= 2;
        flags |= 0x80;
        break;
    case 6:
        difference = xPos - tileLeft;
        flags |= 0x80;
        break;
    }
    if ((difference + top) > uBound) {
        yPos = top + difference + hitRect.up;
        if (yVel < 0)
            yVel = 0;
        collision |= flags;
    }
}

void Entity::eTileWater(int x, int y)
{
    if ((xPos - hitRect.right < (0x10 * x + 6) << 9) &&
            (xPos + hitRect.right > (0x10 * x - 6) << 9) &&
            (yPos - hitRect.up < (0x10 * y + 6) << 9) &&
            (yPos + hitRect.down > (0x10 * y - 6) << 9))
        collision |= 0x100;
}
*/
void Entity::playerCollision()
{
    int isColliding = 0;
    if (player->stateFlags & 0x80) {
        if (!(player->stateFlags & 2)) {
            if (flags & 1) { //entity is solid
                isColliding = eSolidCollision();
                player->collision |= isColliding;
            } else {
                if (flags & 0x40) { //entity is special solid
                    isColliding = eSpecialSolid();
                    player->collision |= isColliding;
                } else { //entity is not solid
                    isColliding = eNonSolid();
                }
            }
            if (isColliding && (entityID == 1)) { //if xp chip
                playSound(SFX_fx_get_xp);
                player->addWeaponExp(experience);
                inUse = 0;
            }
            if (isColliding && (entityID == 86)) { //if missles
                playSound(SFX_fx_get_missle);
                player->addAmmo(eventNum, experience);
                inUse = 0;
            }
            if (isColliding && (entityID == 87)) { //if heart
                playSound(SFX_fx_health_refill);
                player->heal(experience);
                inUse = 0;
            }
            if (!(gameState & 4)) { //if not already in TSC mode (I think)
                if (isColliding && (flags & 0x100))
                    runEvent(eventNum);
            }
            if (gameState & 2) {
                if (!(flags & 0x2000)) { //if not interactable entity
                    if (flags & 0x80) { //if rear & top attack 0
                        if ( ((isColliding & 4) && (xVel < 0)) ||
                                ((isColliding & 1) && (xVel > 0)) ||
                                ((isColliding & 8) && (yVel < 0)) ||
                                ((isColliding & 2) && (yVel > 0)) )
                            player->takeDamage(damage);
                    } else {
                        if (isColliding && damage && !(gameState &4))
                            player->takeDamage(damage);
                    }
                }//if not interactable
            }//if gamestate & 2
            if (!(gameState & 4)) {
                if (isColliding && (player->stateFlags & 1) && (flags & 0x2000)) {
                    runEvent(eventNum);
                    player->xVel = 0;
                    player->generateQmark = 0;
                }
            } //if gamestate is not 4
        } //if player is not hidden
    } //if player is not dead
}


int Entity::eSolidCollision()
{
    int result = 0;
    if ( (player->yPos - player->hitRect.up < yPos + hitRect.down - 0x600) &&
            (player->yPos + player->hitRect.down > yPos - hitRect.up + 0x600) &&
            (player->xPos - player->hitRect.right < xPos + hitRect.right) &&
            (player->xPos - player->hitRect.right > xPos) ) {
        if (player->xVel < 0x200)
            player->xVel += 0x200;
        result = 1;
    }

    if ( (player->yPos - player->hitRect.up < yPos + hitRect.down - 0x600) &&
            (player->yPos + player->hitRect.down > yPos - hitRect.up + 0x600) &&
            (player->xPos + player->hitRect.right - 0x200 > xPos - hitRect.right) &&
            (player->xPos + player->hitRect.right - 0x200 < xPos) ) {
        if (player->xVel > -0x200)
            player->xVel += -0x200;
        result |= 4;
    }

    if ( (player->xPos - player->hitRect.right < xPos + hitRect.right - 0x600) &&
            (player->xPos + player->hitRect.right > xPos - hitRect.right + 0x600) &&
            (player->yPos - player->hitRect.up < yPos + hitRect.down) &&
            (player->yPos - player->hitRect.up > yPos) ) {
        if (player->yVel < 0)
            player->yVel = 0;
        result |= 2;
    }

    if ( (player->xPos - player->hitRect.right < xPos + hitRect.right - 0x600) &&
            (player->xPos + player->hitRect.right > xPos - hitRect.right + 0x600) &&
            (player->yPos + player->hitRect.down > yPos - hitRect.up) &&
            (player->yPos + player->hitRect.down < yPos + 0x600) ) {
        if (flags & 0x10) {
            player->yVel = yVel - 0x200;
            result |= 8;
        } else {
            if (!(player->collision & 8) && (player->yVel > yVel)) {
                player->yPos = yPos - hitRect.up - player->hitRect.down + 0x200;
                player->yVel = yVel;
                player->xPos += xVel;
                result |= 8;
            }
        }
    }
    return result;
}

int Entity::eSpecialSolid()
{
    float rectUp, rectRight, yDiff, xDiff;
    int result = 0;

    if (xPos <= player->xPos)
        xDiff = (double)(player->xPos - xPos);
    else
        xDiff = (double)(xPos - player->xPos);

    if (yPos <= player->yPos)
        yDiff = (double)(player->yPos - yPos);
    else
        yDiff = (double)(yPos - player->yPos);

    rectRight = (double)hitRect.right;
    rectUp = (double)hitRect.up;

    //safeguard against divide by 0
    if (xDiff == 0.0)
        xDiff = 1.0;
    if (rectRight == 0.0)
        rectRight = 1.0;

    if (rectUp/rectRight >= yDiff/xDiff) {
        if (player->yPos - player->hitRect.up < yPos + hitRect.down) {
            if (player->yPos + player->hitRect.down > yPos - hitRect.up) {
                if (player->xPos - player->hitRect.right < xPos + hitRect.right) {
                    if (player->xPos - player->hitRect.right > xPos) {
                        if (player->xVel < xVel)
                            player->xVel = xVel;
                        player->xPos = player->hitRect.right + hitRect.right + xPos;
                        result = 1;
                    }
                }
                if (player->xPos + hitRect.right > xPos - hitRect.right) {
                    if (player->xPos + hitRect.right < xPos) {
                        if (player->xVel > xVel)
                            player->xVel = xVel;
                        player->xPos = xPos - hitRect.right - player->hitRect.right;
                        result |= 4;
                    }
                }
            }
        }
    } else {
        if (player->xPos - player->hitRect.right < hitRect.right + xPos) {
            if (player->xPos + player->hitRect.right > xPos - hitRect.right) {
                if (player->yPos - player->hitRect.up < yPos + hitRect.down) {
                    if (player->yPos - player->hitRect.up > yPos) {
                        if (player->yVel >= yVel) {
                            if (player->yVel < 0)
                                player->yVel = 0;
                        } else {
                            player->yPos =  hitRect.down + yPos + player->hitRect.up + 0x200;
                            player->yVel = yVel;
                        }
                        result = 2;
                    }
                }
                if (player->yPos + player->hitRect.down > yPos - hitRect.up) {
                    if (player->yPos + player->hitRect.down < yPos + 0x600) {
                        if (player->yVel - yVel > 0x400)
                            playSound(SFX_fx_thud);
                        if (player->worldMode == 1) {
                            player->yPos = yPos - hitRect.up - player->hitRect.down + 0x200;
                            result |= 8;
                        } else {
                            if (flags & 0x10) {
                                player->yVel = yVel - 0x200;
                                result |= 8;
                            } else {
                                if (!(player->collision & 8)) {
                                    player->yPos = yPos - hitRect.up - player->hitRect.down + 0x200;
                                    player->yVel = yVel;
                                    player->xPos += xVel;
                                    result |= 8;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}



int Entity::eNonSolid()
{
    if (direction) {
        if ( player->xPos + player->hitRect.left > xPos - hitRect.right
                && player->xPos - player->hitRect.right < xPos + hitRect.left
                && player->yPos + player->hitRect.down > yPos - hitRect.up
                && player->yPos - player->hitRect.up < yPos + hitRect.down )
            return 1;
    } else {
        if ( player->xPos + player->hitRect.left > xPos - hitRect.left
                && player->xPos - player->hitRect.right < xPos + hitRect.right
                && player->yPos + player->hitRect.down > yPos - hitRect.up
                && player->yPos - player->hitRect.up < yPos + hitRect.down )
            return 1;
    }
    return 0;
}

void drawAllNpc()
{
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity *currentEntity = &*it;
        currentEntity->draw();
    }
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity *currentEntity = &*it;
        currentEntity->draw();
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity *currentEntity = &*it;
        currentEntity->draw();
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity *currentEntity = &*it;
        currentEntity->draw();
    }
}

//initializes data for an npc and adds it to the list
Entity* createNpc(int entityNum, int xPos_in, int yPos_in, int xVel_in, int yVel_in,
                  int direction_in, Entity *parent_in, unsigned int layer)
{
    if (layer > 3)
        return NULL;
    Entity *newEnt = new Entity();
    newEnt->xPos = xPos_in;
    newEnt->yPos = yPos_in;
    newEnt->xVel = xVel_in;
    newEnt->yVel = yVel_in;
    newEnt->entityID = entityNum;
    newEnt->direction = direction_in;
    newEnt->parent = parent_in;

    getNpcTblData(newEnt, entityNum);

    (newEnt->*funcArray[newEnt->entityID])();
    switch(layer) {
    case 0:
        if (npcLayer0.size() >= maxListSize)
            break;
        npcLayer0.push_back(*newEnt);
        delete newEnt;
        return &npcLayer0.back();
    case 1:
        if (npcLayer1.size() >= maxListSize)
            break;
        npcLayer1.push_back(*newEnt);
        delete newEnt;
        return &npcLayer1.back();
    case 2:
        if (npcLayer2.size() >= maxListSize)
            break;
        npcLayer2.push_back(*newEnt);
        delete newEnt;
        return &npcLayer2.back();
    case 3:
        if (npcLayer3.size() >= maxListSize)
            break;
        npcLayer3.push_back(*newEnt);
        delete newEnt;
        return &npcLayer3.back();
    }
}

void createExplosion(int x, int y, int radius, int nSmokes)
{
    for (int i = 0; i < nSmokes; i++) {
        int xVar = random(-radius, radius);
        int yVar = random(-radius, radius);
        createNpc(4, xVar + x, yVar + y, 0, 0, 0, NULL, 3);
    }
    createEffect(x, y, 11, 0);
}

void createSmoke(int x, int y, int radius, int nSmokes)
{

    for (int i = 0; i < nSmokes; i++) {
        int xVar = random(-radius, radius);
        int yVar = random(-radius, radius);
        createNpc(4, xVar + x, yVar + y, 0, 0, 0, NULL, 3);
    }
}

void spawnExperience(int x, int y, int amt)
{
    //TODO: This function
    while (amt > 0)
    {
    	Entity *xpEnt = createNpc(1, x, y, 0, 0, 0, NULL, 3);
    	if (amt >= 20)
    	{
    		amt -= 20;
			xpEnt->experience = 20;
    	} else if (amt >= 5) {
    		amt -= 5;
			xpEnt->experience = 5;
    	} else {
			amt --;
			xpEnt->experience = 1;
    	}
    }
}

void spawnHeart(int x, int y, int sz)
{
	Entity *hpEnt = createNpc(87, x, y, 0, 0, 0, NULL, 3);
	hpEnt->experience = sz;
}

bool spawnMissles(int x, int y, int sz)
{
	if (player->hasWeapon(5) || player->hasWeapon(10))
	{
		Entity *mslEnt = createNpc(87, x, y, 0, 0, 0, NULL, 3);
		mslEnt->experience = sz;
		return true;
	}
	return false;
}

#ifdef EDITOR_MODE
void createNpc_debug(int entityNum, int xPos_in, int yPos_in, int xVel_in, int yVel_in,
                     int direction_in, unsigned int layer, int flagID, int event, int state)
{
    if (layer > 3)
        return;
    Entity *newEnt = new Entity();
    newEnt->xPos = xPos_in;
    newEnt->yPos = yPos_in;
    newEnt->xVel = xVel_in;
    newEnt->yVel = yVel_in;
    newEnt->entityID = entityNum;
    newEnt->direction = direction_in;
    newEnt->eventNum = event;
    newEnt->flagID = flagID;
    newEnt->scriptState = state;

    getNpcTblData(newEnt, entityNum);
    (newEnt->*funcArray[newEnt->entityID])();

    switch(layer) {
    case 0:
        if (npcLayer0.size() >= maxListSize)
            break;
        npcLayer0.push_back(*newEnt);
        break;
    case 1:
        if (npcLayer1.size() >= maxListSize)
            break;
        npcLayer1.push_back(*newEnt);
        break;
    case 2:
        if (npcLayer2.size() >= maxListSize)
            break;
        npcLayer2.push_back(*newEnt);
        break;
    case 3:
        if (npcLayer3.size() >= maxListSize)
            break;
        npcLayer3.push_back(*newEnt);
        break;
    };
    delete newEnt;
}
#endif

void getNpcTblData(Entity *newEnt, int entityNum)
{
    newEnt->flags = npctbl_Flags[entityNum];
    newEnt->health = npctbl_Health[entityNum];
    newEnt->gfxNum = npctbl_Tileset[entityNum];
    newEnt->deathSound = npctbl_DeathSound[entityNum];
    newEnt->hurtSound = npctbl_HurtSound[entityNum];
    newEnt->size = npctbl_Size[entityNum];
    newEnt->experience = npctbl_Exp[entityNum];
    newEnt->damage = npctbl_Damage[entityNum];

    int scaleFactor = 0x200; //table entries are in pixels
    newEnt->hitRect.left = npctbl_Hitbox[entityNum*4] * scaleFactor;
    newEnt->hitRect.up = npctbl_Hitbox[entityNum*4 + 1] * scaleFactor;
    newEnt->hitRect.right = npctbl_Hitbox[entityNum*4 + 2] * scaleFactor;
    newEnt->hitRect.down = npctbl_Hitbox[entityNum*4 + 3] * scaleFactor;
    newEnt->displayOffsetX = npctbl_Displaybox[entityNum*4] * scaleFactor;
    newEnt->displayOffsetY = npctbl_Displaybox[entityNum*4 + 1] * scaleFactor;
    newEnt->inUse = 0x80;
}


void loadNpcsFromFile(PxeFile *theFile)
{
    int entityType;
    for (int i = 0; i < theFile->numEntity; i++) { //for each entity
        Entity *currentEnt = new Entity();
        PxeEntry *currentEntry = &theFile->entityArray[i];
        entityType = currentEntry->entityType;
        getNpcTblData(currentEnt, entityType);
        currentEnt->xPos = currentEntry->xTile << 13;
        currentEnt->yPos = currentEntry->yTile << 13;
        currentEnt->flagID = currentEntry->flagID;
        currentEnt->eventNum = currentEntry->eventNum;
        currentEnt->entityID = entityType;
        currentEnt->flags |= currentEntry->flags;

        if (currentEnt->flags & 0x1000)
            currentEnt->direction = 1;


        (currentEnt->*funcArray[currentEnt->entityID])(); //do one frame of entity AI so it sets its framerects
        //currently only supporting one layer
        //todo: revise .pxe to support more layers
        if (currentEnt->flags & 0x800) { //Create if flagID
            if (checkFlag(currentEnt->flagID))
                npcLayer0.push_back(*currentEnt);
        } else if (currentEnt->flags & 0x4000) { //no create if flag ID
            if (!checkFlag(currentEnt->flagID))
                npcLayer0.push_back(*currentEnt);
        } else {
            npcLayer0.push_back(*currentEnt);
        }
        delete currentEnt;
    }
}

int countNpcs()
{
    int result = npcLayer0.size();
    result += npcLayer1.size();
    result += npcLayer2.size();
    result += npcLayer3.size();
    return result;
}

/*
   Using single function to represent many similar TSC commands
   Type 0: ANP (EventNum, Animation, Direction);
   Type 1: CNP (EventNum, Type, Direction)
   Type 2: DNP (EventNum)
   Type 3: FON (Eventnum, ticks)
   Type 4: MNP (EventNum, X, Y, Direction)
   Type 5: MYB (EventNum, arg)
   Type 6:
   Type 7:
   Type 8:
   Type 9: DNA (entityID)
   Type 10: ECJ (entityID)
   Type 11:
   Type 12:
   Type 13:
   Type 14:
   Type 15:
   Type 16: NCJ (FlagID)
*/
bool entityAction(int actionType, int *args)
{
    //special case MYB
    if (actionType == 5) {
        player->stateFlags &= -2;
        player->yVel = -512;
        if (args[0] == 2) {
            player->stateFlags &= -0x1001;
            player->stateFlags |= 0x4000;
            player->xVel = -512;
        } else if (!args[0]) {
            player->stateFlags &= -0x4001;
            player->stateFlags |= 0x1000;
            player->xVel = 512;
        }
    }
    //check each layer
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity *currentEntity = &*it;
        if (actionType < 8) { //check entity by event num
            if (currentEntity->eventNum == args[0]) {
                switch (actionType) {
                case 0: //ANP
                    currentEntity->scriptState = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 1: { //CNP
                    currentEntity->entityID = args[1];
                    int tmpFlags = currentEntity->flags; //preserve override flags
                    getNpcTblData(currentEntity, args[1]);
                    currentEntity->direction = args[2];
                    currentEntity->flags = tmpFlags;
                    (currentEntity->*funcArray[currentEntity->entityID])();
                    break;
                }
                case 2: //DNP
                    currentEntity->inUse = 0;
                    break;
                case 3:
                    setCamera(currentEntity, args[1]);
                    break;
                case 4:
                    currentEntity->xPos = args[1] << 13;
                    currentEntity->yPos = args[2] << 13;
                    currentEntity->direction = args[3];
                    break;
                case 5:
                    if (currentEntity->xPos >= player->xPos) {
                        player->stateFlags &= -0x1001;
                        player->stateFlags |= 0x4000;
                        player->xVel = -512;
                    } else {
                        player->stateFlags &= -0x4001;
                        player->stateFlags |= 0x1000;
                        player->xVel = 512;
                    }
                    break;
                default:
                    break;
                }//switch
            }//if event matches
        } else if (actionType < 16) { //check entity by entity ID
            if (currentEntity->entityID == args[0]) {
                switch (actionType) {
                case 9://DNA
                    currentEntity->inUse = 0;
                    break;
                case 10://NCJ
                    return true;
                    break;
                default:
                    break;
                }//switch
            }//if id matches
        } else { //else check by FlagID
            if (currentEntity->flagID == args[0]) {
                switch (actionType) {
                case 16://NCJ
                    return true;
                default:
                    break;
                }//switch
            }//if id matches
        } //else check by flagID
    }//for each entity in layer
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity *currentEntity = &*it;
        if (actionType < 5) { //check entity by event num
            if (currentEntity->eventNum == args[0]) {
                switch (actionType) {
                case 0:
                    currentEntity->scriptState = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 1:
                    currentEntity->entityID = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 2:
                    currentEntity->inUse = 0;
                    break;
                case 3:
                    break;
                case 4:
                    currentEntity->xPos = args[1] << 13;
                    currentEntity->yPos = args[2] << 13;
                    currentEntity->direction = args[3];
                    break;
                }//switch
            }//if event matches
        } else { //check entity by entity ID
            if (currentEntity->entityID == args[0]) {
                switch (actionType) {
                case 5://DNA
                    currentEntity->inUse = 0;
                    break;
                case 6://NCJ
                    return true;
                    break;
                }//switch
            }//if id matches
        }//else check by ID
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity *currentEntity = &*it;
        if (actionType < 5) { //check entity by event num
            if (currentEntity->eventNum == args[0]) {
                switch (actionType) {
                case 0:
                    currentEntity->scriptState = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 1:
                    currentEntity->entityID = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 2:
                    currentEntity->inUse = 0;
                    break;
                case 3:
                    break;
                case 4:
                    currentEntity->xPos = args[1] << 13;
                    currentEntity->yPos = args[2] << 13;
                    currentEntity->direction = args[3];
                    break;
                }//switch
            }//if event matches
        } else { //check entity by entity ID
            if (currentEntity->entityID == args[0]) {
                switch (actionType) {
                case 5://DNA
                    currentEntity->inUse = 0;
                    break;
                case 6://NCJ
                    return true;
                    break;
                }//switch
            }//if id matches
        }//else check by ID
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity *currentEntity = &*it;
        if (actionType < 5) { //check entity by event num
            if (currentEntity->eventNum == args[0]) {
                switch (actionType) {
                case 0:
                    currentEntity->scriptState = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 1:
                    currentEntity->entityID = args[1];
                    currentEntity->direction = args[2];
                    break;
                case 2:
                    currentEntity->inUse = 0;
                    break;
                case 3:
                    break;
                case 4:
                    currentEntity->xPos = args[1] << 13;
                    currentEntity->yPos = args[2] << 13;
                    currentEntity->direction = args[3];
                    break;
                }//switch
            }//if event matches
        } else { //check entity by entity ID
            if (currentEntity->entityID == args[0]) {
                switch (actionType) {
                case 5://DNA
                    currentEntity->inUse = 0;
                    break;
                case 6://NCJ
                    return true;
                    break;
                }//switch
            }//if id matches
        }//else check by ID
    }
    return false;
}

void deleteNpc(int eventNum)
{
    //check each layer
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->inUse = 0;
        }
    }
}
void deleteNpcAll(int type)
{
    //check each layer
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->entityID == type) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->entityID == type) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->entityID == type) {
            currentEntity->inUse = 0;
        }
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->entityID == type) {
            currentEntity->inUse = 0;
        }
    }
}

void changeNpc(int eventNum, int type, int direction)
{
    //check each layer
    list<Entity>::iterator it;
    for (it = npcLayer0.begin(); it != npcLayer0.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->entityID = type;
            currentEntity->direction = direction;
        }
    }
    for (it = npcLayer1.begin(); it != npcLayer1.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->entityID = type;
            currentEntity->direction = direction;
        }
    }
    for (it = npcLayer2.begin(); it != npcLayer2.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->entityID = type;
            currentEntity->direction = direction;
        }
    }
    for (it = npcLayer3.begin(); it != npcLayer3.end(); it++) {
        Entity *currentEntity = &*it;
        if (currentEntity->eventNum == eventNum) {
            currentEntity->entityID = type;
            currentEntity->direction = direction;
        }
    }
}

//checks if the player is near our entity
bool Entity::playerRange(int left, int up, int right, int down)
{
    if ((xPos - left < player->xPos) &&
            (xPos + right > player->xPos) &&
            (yPos - up < player->yPos) &&
            (yPos + down > player->yPos) )
        return true;
    else
        return false;
}

//removal predicate
bool isDead (const Entity &ent)
{
    return (ent.inUse == 0);
}


/*******************************************************************************
                    ~~~~~~~~~~HERE BE AI SCRIPTS~~~~~~~~~~
*******************************************************************************/

void Entity::npcAct0() //null
{
    if (!scriptState) {
        scriptState = 1;
        if (direction)
            yPos += 0x2000;
    }
    frameRect.left = 0;
    frameRect.up = 0;
    frameRect.right = 0;
    frameRect.down = 0;
}

void Entity::npcAct1() //xp chipz
{
    int vMax = 0x5FF;

    int mode = getBgMode();
    if (mode != 5 && mode != 6) { //regular gravity scrolling
        //init
        if (!scriptState) {
            scriptState = 1;
            frameNum = random(0,4);
            xVel = random(-512, 512);
            yVel = random(-1024, 0);
            if (random(0,1))
                direction = 0;
            else
                direction = 2;
        }
        if (collision & 0x100)
            yVel += 21;
        else
            yVel += 42;

        if (collision & 1) //left
            if (xVel < 0)
                xVel = -xVel;

        if (collision & 4) //right
            if (xVel > 0)
                xVel = -xVel;

        if (collision & 2) //ceiling
            if (yVel < 0)
                yVel = -yVel;

        if (collision & 8) { //floor
            //playsound
            yVel = -140;
            xVel = 2 * xVel / 3;
        }

        if (collision & 0xD) { //L, R, D
            //playsound
            directive++;
            if (directive > 2)
                yPos -= 512;
        } else {
            directive = 0;
        }

        //speed caps
        SPEEDCAP_MACRO

    } else { //wall gravity
        if (!scriptState) {
            scriptState = 1;
            yVel = random(-128, 128);
            xVel = random(127, 256);
        }
        xVel -= 8;
        if (xPos < 0xA000)
            inUse = 0;
        if (xVel < -vMax)
            xVel = -vMax;

        if (collision & 1)
            xVel = 256;
        if (collision & 2)
            yVel = 64;
        if (collision & 8)
            yVel = -64;
    }

    yPos += yVel;
    xPos += xVel;

    //frame update
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        if (direction) {
            frameNum--;
            if (frameNum < 0)
                frameNum = 5;
        } else {
            frameNum++;
            if (frameNum > 5)
                frameNum = 0;
        }
    }

    //assign framerects
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 32;
    frameRect.down = 64;

    if (experience >= 5) {
        frameRect.up += 32;
        frameRect.down += 32;
    }

    if (experience >= 20) {
        frameRect.up += 32;
        frameRect.down += 32;
    }

    //object timeout
    objectTimer++;
    if (objectTimer > 500) {
        if (frameNum == 5 && frameTimer == 2)
            inUse = 0;
    }
    //blink when nearly timed out
    if (objectTimer > 400) {
        if (objectTimer / 2 % 2) {
            memset(&frameRect, 0, 16);
        }
    }
}

void Entity::npcAct2() //behemoth
{

}

void Entity::npcAct3() //null that disappears after 100 frames
{
    objectTimer++;
    if (objectTimer > 100)
        inUse = 0;
    memset(&frameRect, 0, 16);
}

void Entity::npcAct4() //smoke
{
    if (scriptState) {
        xVel = 20 * xVel / 21;
        yVel = 20 * yVel / 21;
        xPos += xVel;
        yPos += yVel;
    } else { //init
        if (direction <= 1) {
            //assign random direction
            double angle = random(0, 360);
            float result = cos(angle * PI / 180);
            xVel = (int)(result * random(512, 1535));
            result = sin(angle * PI / 180);
            yVel = (int)(result * random(512, 1535));
        }
        frameNum = random(0,4);
        frameTimer = random(0,3);
        scriptState = 1;

        if (direction == 1) { //red
            frameRect.up = 256;
            frameRect.down = 288;
        } else {
            frameRect.up = 0;
            frameRect.down = 32;
        }
    }
    frameTimer++;
    if (frameTimer > 4) {
        frameTimer = 0;
        frameNum++;
    }
    if (frameNum > 7) {
        inUse = 0;
    } else {
        frameRect.left = 32 * frameNum;
        frameRect.right = frameRect.left + 32;
    }
}

void Entity::npcAct5() //hopping green critter
{
    switch (scriptState) {
    case 0: //initialize
        yPos += 1536;
        scriptState = 1;
    case 1: //sit
        //always face pc
        if (xPos <= player->xPos)
            direction = 2;
        else
            direction = 0;

        if (scriptTimer < 8 ||
                xPos - 0xE000 >= player->xPos ||
                xPos + 0xE000 <= player->xPos ||
                yPos - 0xA000 >= player->yPos ||
                yPos + 0xA000 <= player->yPos) {
            if (scriptTimer < 8)
                scriptTimer++;
            frameNum = 0;
        } else { //within wakeup box
            frameNum = 1;
        }

        if (damageTaken) { //jump if hit
            scriptState = 2;
            frameNum = 0;
            scriptTimer = 0;
        }

        if (scriptTimer >= 8 &&
                xPos - 0x6000 < player->xPos &&
                xPos + 0x6000 > player->xPos &&
                yPos - 0xA000 < player->yPos &&
                yPos + 0x6000 < player->yPos) {
            scriptState == 2;
            frameNum = 0;
            scriptTimer = 0;
        }
        break;
    case 2: //jump
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 3;
            frameNum = 2;
            yVel = -0x5FF;
            playSound(SFX_fx_crit_jump);
            if (direction)
                xVel = 0x100;
            else
                xVel = -0x100;
        }
        break;
    case 3: //in air
        if (collision & 8) {
            xVel = 0;
            scriptTimer = 0;
            frameNum = 0;
            scriptState = 1;
            playSound(SFX_fx_crit_land);
        }
        break;
    default:
        break;
    }//switch
    yVel += 64;
    if (yVel > 0x5FF)
        yVel = 0x5FF;
    xPos += xVel;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    if (direction) {
        frameRect.up = 128;
        frameRect.down = 160;
    } else {
        frameRect.up = 96;
        frameRect.down = 128;
    }
}

void Entity::npcAct6() //horizontal green beetle
{
    switch ( scriptState ) {
    case 0:
        if ( direction )
            scriptState = 3;
        else
            scriptState = 1;
        break;
    case 1:
        xVel -= 16;
        if ( xVel < -1024 )
            xVel = -1024;
        if ( damageTaken )
            xPos += xVel / 2;
        else
            xPos += xVel;
        ++frameTimer;
        if ( frameTimer > 1 ) {
            frameTimer = 0;
            ++frameNum;
        }
        if ( frameNum > 2 )
            frameNum = 1;
        if ( collision & 1 ) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 0;
            xVel = 0;
            direction = 2;
        }
        break;
    case 2:
        ++scriptTimer;
        if ( scriptTimer > 60 ) {
            scriptState = 3;
            frameTimer = 0;
            frameNum = 1;
        }
        break;
    case 3:
        xVel += 16;
        if ( xVel > 1024 )
            xVel = 1024;
        if ( damageTaken )
            xPos += xVel / 2;
        else
            xPos += xVel;
        ++frameTimer;
        if ( frameTimer > 1 ) {
            frameTimer = 0;
            ++frameNum;
        }
        if ( frameNum > 2 )
            frameNum = 1;
        if ( collision & 4 ) {
            scriptState = 4;
            scriptTimer = 0;
            frameNum = 0;
            xVel = 0;
            direction = 0;
        }
        break;
    case 4:
        ++scriptTimer;
        if ( scriptTimer > 60 ) {
            scriptState = 1;
            frameTimer = 0;
            frameNum = 1;
        }
        break;
    default:
        break;
    }
    //frames
    frameRect.left = frameNum * 16;
    frameRect.right = frameRect.left + 16;
    if (!direction) {
        frameRect.up = 160;
        frameRect.down = 176;
    } else {
        frameRect.up = 176;
        frameRect.down = 182;
    }
}

void Entity::npcAct7() //Robo Critter
{
    int jumpWait = 0x17;
    int gravity = 0x48;
    int maxFall = 0x600;
    int timeToDie = 0x80;
    int jumpSpeed = 0x680;
    int jumpVel = 0x2C0;
    int rebound = 0x80;


    switch (scriptState) {
    case 0: //idle, eyes closed. Direction & 10 == eyes open. 0 = left 1 = right
        scriptTimer = 0;
        frameTimer = 0;
        if (direction & 0x10)
            frameNum = 1;
        else
            frameNum = 0;
        break;
    case 1: //attack mode; set direction based on player pos, wait then jump
        frameNum = 1;
        //direction check
        if (player->xPos > xPos)
            direction = 1;
        else
            direction = 0;

        scriptTimer++;
        if (scriptTimer > jumpWait) {
            playSound(SFX_fx_crit_jump);
            scriptState = 2;
            yVel = -jumpSpeed;
            int vel = random(rebound, jumpVel);
            if (direction)
                xPos = vel;
            else
                xPos = -vel;
        }
        break;
    case 2: //jumping (in air). If moving up frame =2, if moving down frame =1
        if (yVel > 0)
            frameNum = 0;
        else
            frameNum = 2;

        if (collision & 8) { //floor landing
            xVel = 0;
            yVel = 0;
            frameNum = 0;
            scriptState = 1;
            playSound(SFX_fx_shot_hit);
            scriptTimer = random(-1, 7);
        } else if (collision & 1) { //left wall
            xVel = rebound;
        } else if (collision & 4) { //right wall
            xVel = -rebound;
        }
        break;
    case 10: //remove shootable flag, alternate rapidly between eyes closed / open,
        //spew smoke and die after a few frames.
        flags &= -0x21;
        scriptTimer++;
        if (!(scriptTimer % 3)) { //freak out
            frameNum++;
            if (frameNum > 2)
                frameNum = 0;
        }
        if (!(scriptTimer % 5)) {
            playSound(SFX_fx_enemy_fire);
            createNpc(4, xPos, yPos, random(-0x200, 0x200), random(-0x200, 0x200), 0, NULL, 3);
        }
        inUse = 0x88;
        break;
    }
    xPos += xVel;
    yVel += gravity;
    if (yVel > maxFall)
        yVel = maxFall;
    yPos += yVel;
    //frames
    frameRect.left = 0x200 + frameNum * 0x20;
    frameRect.right = frameRect.left + 0x20;
    frameRect.up = direction * 0x20 + 0x1A0;
    frameRect.down = frameRect.up + 0x20;
}

void Entity::npcAct8() //beetle (follow1)
{
    int *v1; // eax@33
    int *v2; // eax@34
    int v3; // [sp+0h] [bp-44h]@1
    int v4; // [sp+4h] [bp-40h]@1
    int v5; // [sp+8h] [bp-3Ch]@1
    int v6; // [sp+Ch] [bp-38h]@1
    int v7; // [sp+10h] [bp-34h]@1
    int v8; // [sp+14h] [bp-30h]@1
    int v9; // [sp+18h] [bp-2Ch]@1
    int v10; // [sp+1Ch] [bp-28h]@1
    int v11; // [sp+20h] [bp-24h]@1
    int v12; // [sp+24h] [bp-20h]@1
    int v13; // [sp+28h] [bp-1Ch]@1
    int v14; // [sp+2Ch] [bp-18h]@1
    int v15; // [sp+30h] [bp-14h]@1
    int v16; // [sp+34h] [bp-10h]@1
    int v17; // [sp+38h] [bp-Ch]@1
    int v18; // [sp+3Ch] [bp-8h]@1
    int v19; // [sp+40h] [bp-4h]@1

    v12 = 160;
    v13 = 160;
    v14 = 192;
    v15 = 192;
    v16 = 192;
    v17 = 160;
    v18 = 224;
    v19 = 192;
    v4 = 160;
    v5 = 192;
    v6 = 192;
    v7 = 224;
    v8 = 192;
    v9 = 192;
    v10 = 224;
    v11 = 224;
    v3 = scriptState;
    if ( v3 ) {
        if ( v3 == 1 ) {
            if ( xPos <= player->xPos ) {
                direction = 2;
                xVel += 16;
            } else {
                direction = 0;
                xVel -= 16;
            }
            if ( xVel > 767 )
                xVel = 767;
            if ( xVel < -767 )
                xVel = -767;
            if ( yPos >= targetY )
                yVel -= 8;
            else
                yVel += 8;
            if ( yVel > 256 )
                yVel = 256;
            if ( yVel < -256 )
                yVel = -256;
            if ( damageTaken ) {
                xPos += xVel / 2;
                yPos += yVel / 2;
            } else {
                xPos += xVel;
                yPos += yVel;
            }
        }
    } else {
        if ( player->xPos >= xPos + 8192 || player->xPos <= xPos - 8192 ) {
            flags &= 0xFFDFu;
            frameRect.right = 0;
            damage = 0;
            xVel = 0;
            yVel = 0;
            return;
        }
        flags |= 0x20u;
        yVel = -256;
        targetY = yPos;
        scriptState = 1;
        damage = 2;
        if ( direction ) {
            xPos = player->xPos - 131072;
            xVel = 767;
        } else {
            xPos = player->xPos + 131072;
            xVel = -767;
        }
    }
    ++frameTimer;
    if ( frameTimer > 1 ) {
        frameTimer = 0;
        ++frameNum;
    }
    if ( frameNum > 1 )
        frameNum = 0;
    if ( direction ) {
        v2 = &v4 + 4 * frameNum;
        frameRect.left = *v2;
        frameRect.up = v2[1];
        frameRect.right = v2[2];
        frameRect.down = v2[3];
    } else {
        v1 = &v12 + 4 * frameNum;
        frameRect.left = *v1;
        frameRect.up = v1[1];
        frameRect.right = v1[2];
        frameRect.down = v1[3];
    }

}

void Entity::npcAct9() //Balrog (drops in)
{

}

void Entity::npcAct10() //boss balrog - shooting
{

}

void Entity::npcAct11() //projectile - Balrog - energy shot
{

}

void Entity::npcAct12() //Balrog(cutscene)
{

}

void Entity::npcAct13() //forcefield
{

}

void Entity::npcAct14() //MG bullets
{
    if (direction)
        xPos += xVel;
    else
        xPos -= xVel;

    yPos += yVel;
    //hit wall
    if (collision & 0x15)
        inUse = 0;

    frameRect.left = 320;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 416;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct15() //Treasure Chest(locked)
{
    int v1, v2, v3, v4;
    int v6 = scriptState;
    if ( v6 ) {
        if ( v6 != 1 ) {
            if ( v6 == 2 ) {
                ++frameTimer;
                if ( frameTimer > 1 ) {
                    frameTimer = 0;
                    ++frameNum;
                }
                if ( frameNum > 2 ) {
                    frameNum = 0;
                    scriptState = 1;
                }
            }
            goto LABEL_16;
        }
    } else {
        scriptState = 1;
        flags |= 0x2000u;
        if ( direction == 2 ) {
            yVel = -512;
            for ( int i = 0; i < 4; ++i ) {
                v1 = random(-1536, 0);
                v2 = random(-341, 341);
                v3 = yPos + (random(-12, 12) << 9);
                v4 = random(-12, 12);
                createNpc(4, xPos + (v4 << 9), v3, v2, v1, 0, 0, 3);
            }
        }
    }
    frameNum = 0;
    if ( !random(0, 30) )
        scriptState = 2;
LABEL_16:
    yVel += 64;
    if ( yVel > 1535 )
        yVel = 1535;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32 + 480;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 0;
    frameRect.down = 32;

}

void Entity::npcAct16() //save point
{
    ++frameTimer;
    if ( frameTimer > 2 ) {
        frameTimer = 0;
        ++frameNum;
    }
    if ( frameNum > 7 )
        frameNum = 0;
    yVel += 64;
    if ( yVel > 1535 )
        yVel = 1535;
    yPos += yVel;

    //frames
    frameRect.left = frameNum * 32 + 192;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 32;
    frameRect.down = 64;
}

void Entity::npcAct17() //health/ammo refill
{
    int v1; // ST10_4@5
    int v2; // ST0C_4@5
    int v3; // ST08_4@5
    int v4; // eax@5
    signed int i; // [sp+24h] [bp-4h]@3
    signed int v6; // [sp+24h] [bp-4h]@6

    switch ( scriptState ) {
    case 0:
        scriptState = 1;
        if ( direction == 2 ) {
            yVel = -512;
            for ( i = 0; i < 4; ++i ) {
                v1 = random(-1536, 0);
                v2 = random(-341, 341);
                v3 = yPos + (random(-12, 12) << 9);
                v4 = random(-12, 12);
                createNpc(4, xPos + (v4 << 9), v3, v2, v1, 0, 0, 3);
            }
        }
        goto LABEL_6;
    case 1:
LABEL_6:
        v6 = random(0, 30);
        if ( v6 >= 10 ) {
            if ( v6 >= 25 )
                scriptState = 4;
            else
                scriptState = 3;
        } else {
            scriptState = 2;
        }
        scriptTimer = random(16, 64);
        frameTimer = 0;
        break;
    case 2:
        frameRect.left = 576;
        frameRect.up = 0;
        frameRect.right = 608;
        frameRect.down = 32;
        --scriptTimer;
        if ( !scriptTimer )
            scriptState = 1;
        break;
    case 3:
        ++frameTimer;
        if ( frameTimer % 2 ) {
            frameRect.left = 576;
            frameRect.up = 0;
            frameRect.right = 608;
            frameRect.down = 32;
        } else {
            frameRect.left = 608;
            frameRect.up = 0;
            frameRect.right = 640;
            frameRect.down = 32;
        }
        --scriptTimer;
        if ( !scriptTimer )
            scriptState = 1;
        break;
    case 4:
        frameRect.left = 608;
        frameRect.up = 0;
        frameRect.right = 640;
        frameRect.down = 32;
        --scriptTimer;
        if ( !scriptTimer )
            scriptState = 1;
        break;
    default:
        break;
    }
    yVel += 64;
    if ( yVel > 1535 )
        yVel = 1535;
    yPos += yVel;

}

void Entity::npcAct18() //door
{
    if (!direction) {
        frameRect.left = 448;
        frameRect.up = 32;
        frameRect.right = 480;
        frameRect.down = 80;
    } else {
        frameRect.left = 384;
        frameRect.up = 224;
        frameRect.right = 416;
        frameRect.down = 272;
    }
}

void Entity::npcAct19() //Balrog (bust in)
{

}

void Entity::npcAct20() //computer
{
    frameTimer++;
    if (frameTimer > 3) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 2)
            frameNum = 0;
    }

    frameRect.left = 576;
    frameRect.right = frameRect.left + 48;
    if (direction) {
        frameRect.up = 80 + (frameNum & 1) * 48;
        frameRect.down = frameRect.up + 48;
    } else {
        frameRect.up = 64;
        frameRect.down = frameRect.up + 48;
    }
}

void Entity::npcAct21() //treasure chest (opem)
{
    if (!scriptState) {
        scriptState = 1;
        if (direction)
            yPos += 8192;
    }
    frameRect.left = 448;
    frameRect.up = 80;
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct22() //teleporter
{
    Rect rectArray[2] = {
        {480, 32, 528, 96},
        {496, 304, 544, 368}
    };
    if (scriptState == 1) {
        frameNum ^= 1;
    } else {
        frameNum = 0;
    }
    frameRect = rectArray[frameNum];
}

void Entity::npcAct23() //teleporter lights
{
    frameTimer ^= 1;
    if (frameTimer) {
        frameNum++;
        if (frameNum > 7)
            frameNum = 0;
    }
    frameRect.left = 528;
    frameRect.right = 576;
    frameRect.up = 32 + frameNum * 8;
    frameRect.down = frameRect.up + 8;
}

void Entity::npcAct24() //enemy power critter
{
    int vMax = 512;
    switch (scriptState) {
    case 0: //initialize
        yPos += 1536;
        scriptState = 1;
    case 1: //sit
        //always face pc


        if (scriptTimer < 8 ||
                xPos - 0x10000 >= player->xPos ||
                xPos + 0x10000 <= player->xPos ||
                yPos - 0x10000 >= player->yPos ||
                yPos + 0x6000 <= player->yPos) {
            if (scriptTimer < 8)
                scriptTimer++;
            frameNum = 0;
        } else { //within wakeup box
            if (xPos <= player->xPos)
                direction = 1;
            else
                direction = 0;
            frameNum = 1;
        }

        if (damageTaken) { //jump if hit
            scriptState = 2;
            frameNum = 0;
            scriptTimer = 0;
        }

        if (scriptTimer >= 8 &&
                xPos - 0xC000 < player->xPos &&
                xPos + 0xC000 > player->xPos &&
                yPos - 0xC000 < player->yPos &&
                yPos + 0x6000 < player->yPos) {
            scriptState == 2;
            frameNum = 0;
            scriptTimer = 0;
        }
        break;
    case 2: //jump
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 3;
            frameNum = 2;
            yVel = -0x5FF;
            playSound(SFX_fx_crit_jump);
            if (xPos <= player->xPos) {
                direction = 1;
                xVel = 256;
            } else {
                direction = 0;
                xVel = -256;
            }
        }
        break;
    case 3: //rising
        if (yVel > vMax) {
            targetY = yPos;
            scriptState = 4;
            frameNum = 3;
            scriptTimer = 0;
        }
        break;
    case 4:
        if (xPos >= player->xPos)
            direction = 0;
        else
            direction = 1;
        scriptTimer++;
        if (collision & 7 || scriptTimer > 100) { //done falling
            damage = 12;
            scriptState = 5;
            frameNum = 2;
            xVel /= 2;
        } else {
            if (scriptTimer % 4 == 1)
                playSound(SFX_fx_crit_fly2);
            frameTimer ^= 1;
            if (frameTimer & 1) {
                frameNum++;
                if (frameNum > 5)
                    frameNum = 3;
            }
        }
        break;
    case 5:
        if (collision & 8) {
            damage = 2;
            xVel = 0;
            scriptTimer = 0;
            frameNum = 0;
            scriptState = 1;
            playSound(SFX_fx_crash_little);
            softQuake(30);
        }
        break;
    default:
        break;
    }//switch
    if (scriptState == 4) {
        if (xPos >= player->xPos)
            xVel -= 32;
        else
            xVel += 32;

        if (yPos <= targetY)
            yVel += 16;
        else
            yVel -= 16;

        SPEEDCAP_MACRO
    } else {
        yVel += 32;
        if (yVel > 1535)
            yVel =  1535;
    }
    xPos += xVel;
    yPos += yVel;
    //frames
    frameRect.up = 64*direction;
    frameRect.down = frameRect.up + 64;
    frameRect.left = frameNum * 64;
    frameRect.right = frameRect.left + 64;
}

void Entity::npcAct25() //lift platform
{
    switch (scriptState) {
    case 0: //init
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        xPos += 4096;
    case 1://sit  bottom
        scriptTimer++;
        if (scriptTimer > 150) {
            scriptTimer = 0;
            scriptState++;
        }
        break;
    case 2: //move up
        scriptTimer++;
        if (scriptTimer > 128) {
            scriptTimer = 0;
            scriptState++;
        } else {
            yPos -= 512;
        }
        break;
    case 3: //sit top
        scriptTimer++;
        if (scriptTimer > 150) {
            scriptTimer = 0;
            scriptState++;
        }
        break;
    case 4: //move down
        scriptTimer++;
        if (scriptTimer > 128) {
            scriptTimer = 0;
            scriptState = 0;
        } else {
            yPos += 512;
        }
    default:
        break;
    }
    switch (scriptState) {
    case 2:
    case 4:
        frameTimer++;
        if (frameTimer > 1) {
            frameTimer = 0;
            frameNum ^= 1;
        }
    default:
        break;
    }
    //frames
    frameRect.left = 512;
    frameRect.right = frameRect.left + 64;
    frameRect.up = 128 + frameNum * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct26() //bat black, circling
{
    int vMax = 512;
    float angle;
    switch (scriptState) {
    case 0: //init
        angle = random(0, 360);
        xVel = (int) (512.0 * cos(angle * PI / 180));
        targetX = xPos + 8 * (int)(512.0 * cos((angle + 90) * PI / 180));
        angle = random(0, 360);
        yVel = (int) (512.0 * sin(angle * PI / 180));
        angle += 90;
        targetY = yPos + 8 * (int)(512.0 * sin(angle * PI / 180));
        scriptState = 1;
        objectTimer = 120;
    case 1: //fly?
        if (player->xPos >= xPos)
            direction = 1;
        else
            direction = 0;

        //flip around a bit
        if (targetX < xPos)
            xVel -= 16;
        else
            xVel += 16;

        if (targetY < yPos)
            yVel -= 16;
        else
            yVel += 16;

        SPEEDCAP_MACRO

        if (objectTimer >= 120) {
            if (xPos - 4096 < player->xPos &&
                    xPos + 4096 > player->xPos &&
                    yPos < player->yPos &&
                    yPos + 49152 > player->yPos) {
                //trigger dive
                xVel /= 2;
                yVel = 0;
                scriptState = 3;
                flags &= -9;
            }
        } else {
            objectTimer++;
        }
    case 2:
        break;
    case 3: //dive
        yVel += 64;
        if (yVel > 1535)
            yVel = 1535;
        if (collision & 8) {
            yVel = 0;
            xVel *= 2;
            objectTimer = 0;
            scriptState = 1;
            flags |= 8;
        }
    default:
        break;
    }//switch

    //update pos
    xPos += xVel;
    yPos += yVel;

    //frames
    if (scriptState = 3) {
        frameNum = 3;
    } else {
        frameTimer++;
        if (frameTimer > 1) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 2)
                frameNum = 0;
        }
    }
    frameRect.left = 64 + 32 * frameNum;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 160 + direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct27() //deathtrap
{
    frameRect.left = 192;
    frameRect.up = 128;
    frameRect.right = 256;
    frameRect.down = 176;
}

void Entity::npcAct28() //crit fly
{
    int vMax = 512;
    switch (scriptState) {
    case 0: //initialize
        yPos += 1536;
        scriptState = 1;
    case 1: //sit
        if (scriptTimer < 8 ||
                xPos - 0x10000 >= player->xPos ||
                xPos + 0x10000 <= player->xPos ||
                yPos - 0x10000 >= player->yPos ||
                yPos + 0x6000 <= player->yPos) {
            if (scriptTimer < 8)
                scriptTimer++;
            frameNum = 0;
        } else { //within wakeup box
            if (xPos <= player->xPos)
                direction = 1;
            else
                direction = 0;
            frameNum = 1;
        }

        if (damageTaken) { //jump if hit
            scriptState = 2;
            frameNum = 0;
            scriptTimer = 0;
        }

        if (scriptTimer >= 8 &&
                xPos - 0xC000 < player->xPos &&
                xPos + 0xC000 > player->xPos &&
                yPos - 0xC000 < player->yPos &&
                yPos + 0x6000 < player->yPos) {
            scriptState == 2;
            frameNum = 0;
            scriptTimer = 0;
        }
        break;
    case 2: //jump
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 3;
            frameNum = 2;
            yVel = -0x4CC;
            playSound(SFX_fx_crit_jump);
            if (xPos <= player->xPos) {
                direction = 1;
                xVel = 256;
            } else {
                direction = 0;
                xVel = -256;
            }
        }
        break;
    case 3: //rising
        if (yVel > 256) {
            targetY = yPos;
            scriptState = 4;
            frameNum = 3;
            scriptTimer = 0;
        }
        break;
    case 4:
        if (xPos >= player->xPos)
            direction = 0;
        else
            direction = 1;
        scriptTimer++;
        if (collision & 7 || scriptTimer > 100) { //done falling
            damage = 3;
            scriptState = 5;
            frameNum = 2;
            xVel /= 2;
        } else {
            if (scriptTimer % 4 == 1)
                playSound(SFX_fx_crit_fly);
            frameTimer ^= 1;
            if (frameTimer & 1) {
                frameNum++;
                if (frameNum > 5)
                    frameNum = 3;
            }
        }
        break;
    case 5:
        if (collision & 8) {
            damage = 2;
            xVel = 0;
            scriptTimer = 0;
            frameNum = 0;
            scriptState = 1;
            playSound(SFX_fx_crit_land);
        }
        break;
    default:
        break;
    }//switch
    if (scriptState == 4) {
        if (xPos >= player->xPos)
            xVel -= 32;
        else
            xVel += 32;

        if (yPos <= targetY)
            yVel += 16;
        else
            yVel -= 16;

        SPEEDCAP_MACRO
    } else {
        yVel += 64;
        if (yVel > 1535)
            yVel =  1535;
    }
    xPos += xVel;
    yPos += yVel;
    //frames
    frameRect.up = 128 + 32*direction;
    frameRect.down = frameRect.up + 32;
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct29() //cthulhu
{
    frameNum = xPos - 0x6000 < player->xPos &&
               xPos + 0x6000 > player->xPos &&
               yPos - 0x6000 < player->yPos &&
               yPos + 0x2000 > player->yPos;

    if (!direction) {
        frameRect.up = 384;
        frameRect.down = 432;
    } else {
        frameRect.up = 432;
        frameRect.down = 480;
    }
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct30() //hermit gunsmith
{
    if (direction) {
        if (!scriptState) {
            scriptState = 1;
            yPos += 8192;
            frameNum = 2;
        }
        scriptTimer++;
        if (scriptTimer > 100) {
            scriptTimer = 0;
            createEffect(xPos, yPos - 1024, 5, 0);
        }
    } else {
        switch (scriptState) {
        case 0:
            scriptState = 1;
            frameNum = 0;
            frameTimer = 0;
            break;
        case 1:
            break;
        case 2:
            scriptTimer++;
            if (scriptTimer > 8) {
                scriptState = 1;
                frameNum = 0;
            }
            break;
        default:
            scriptState = 1;
            frameNum = 0;
            frameTimer = 0;
            break;
        }//switch
        if (random(0,120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
    }
    //frames
    if (frameNum == 2) {
        frameRect.left = 0;
        frameRect.right = 32;
        frameRect.up =  64;
        frameRect.down = 96;
    } else {
        frameRect.left = 96;
        frameRect.right = 128;
        frameRect.up = frameNum * 32;
        frameRect.down = frameRect.up + 32;
    }
}

void Entity::npcAct31() //bat black hanging
{
    int vMax = 512;
    switch (scriptState) {
    case 0:
        scriptState = 1;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (xPos - 4096 < player->xPos &&
                xPos + 4096 > player->xPos &&
                yPos - 4096 < player->yPos &&
                yPos + 49152 > player->yPos ) {
            frameNum = 0;
            scriptState = 3;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3: //alert?
        frameNum = 0;
        if (damageTaken || xPos - 10240 > player->xPos || xPos + 10240 < player->xPos) {
            frameNum = 1;
            frameTimer = 0;
            scriptState = 4;
            scriptTimer = 0;
        }
        break;
    case 4:
        yVel += 32;
        if (yVel > 1535)
            yVel = 1535;
        scriptTimer++;
        if (scriptTimer >= 20 || collision & 8) {
            if (collision & 8 || yPos > player->yPos - 8192) {
                frameTimer = 0;
                frameNum = 2;
                scriptState = 5;
                targetY = yPos;
                if (collision & 8)
                    yVel = -512;
            }
        }
        break;
    case 5:
        frameTimer ^= 1;
        if (frameTimer & 1)
            frameNum++;
        if (frameNum > 4)
            frameNum = 2;

        if (player->xPos >= xPos)
            direction = 1;
        else
            direction = 0;

        if (player->xPos < xPos)
            xVel -= 16;
        if (player->xPos > xPos)
            xVel += 16;

        if (targetY < yPos)
            yVel -= 16;
        else
            yVel += 16;

        SPEEDCAP_MACRO

        if(collision & 8)
            yVel = -vMax;
        if (collision & 2)
            yVel = vMax;
        break;
    default:
        break;
    }
    xPos += xVel;
    yPos += yVel;

    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 160 + direction * 32;
    frameRect.down = frameRect.up + 32;

}

void Entity::npcAct32() //life capsure
{
    frameTimer++;
    if (frameTimer > 2) {
        frameTimer = 0;
        frameNum ^= 1;
    }

    frameRect.up = 192;
    frameRect.down = 224;
    frameRect.left = 64 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct33() //balrog energy bounce proj.
{

}

void Entity::npcAct34() //bed
{
    frameRect.left = 384;
    frameRect.right = 448;
    if (direction) {
        frameRect.up = 368;
        frameRect.down = 400;
    } else {
        frameRect.up = 96;
        frameRect.down = 128;
    }
}

void Entity::npcAct35() //enemy Manann
{
    if (scriptState < 3) {
        if (health < 90) {
            playSound(SFX_fx_crash_little);
            createExplosion(xPos, yPos, displayOffsetX, 8);
            spawnExperience(xPos, yPos, experience);
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 2;
            flags &= 0xFFDF;
            damage = 0;
        }
    }
    switch (scriptState) {
        int xOff;
    case 0:
    case 1:
        if (damageTaken) {
            if (direction)
                xOff = 4096;
            else
                xOff = -4096;
            createNpc(103, xPos + xOff, yPos + 4096, 0, 0, direction, NULL, 2);
            frameNum = 1;
            scriptState = 2;
            scriptTimer = 0;
        }
        break;
    case 2:
        scriptTimer ++;
        if (scriptTimer > 20) {
            scriptTimer = 0;
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptTimer++;
        if (scriptTimer == 50 || scriptTimer == 60)
            frameNum = 3;
        if (scriptTimer == 53 || scriptTimer == 63)
            frameNum = 2;
        if (scriptTimer > 100)
            scriptState = 4;
        break;
    default:
        break;
    }
    //frames
    frameRect.left = 192 + frameNum * 48;
    frameRect.right = frameRect.left + 48;
    frameRect.up = 128 + direction * 64;
    frameRect.down = frameRect.up + 64;
}

void Entity::npcAct36() //boss balrog hovering
{

}

void Entity::npcAct37() //signpost
{
    if (!scriptState) {
        scriptState = 1;
        frameRect.left = 384 + direction * 32;
        frameRect.right = frameRect.left + 32;
        frameRect.up = 128;
        frameRect.down = 160;
    }
}

void Entity::npcAct38() //fireplace fire
{
    if (scriptState == 11)
        return;
    if (scriptState == 10) {
        scriptState = 11;
        createExplosion(xPos, yPos, displayOffsetX, 8);
        frameRect.right = frameRect.left;
    }
    frameTimer++;
    if (frameTimer > 3) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 3)
            frameNum = 0;
    }

    //frames
    frameRect.left = 256 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 128;
    frameRect.down = 160;
}

void Entity::npcAct39() //HP Check
{
    if (player->currentHealth <= flagID) {
        runEvent(eventNum);
        inUse = 0;
    }
}

void Entity::npcAct40() //santa
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0,120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (xPos - 0x4000 < player->xPos &&
                xPos + 0x4000 > player->xPos &&
                yPos - 0x4000 < player->yPos &&
                yPos + 0x2000 > player->yPos ) {
            if (xPos <= player->xPos)
                direction = 1;
            else
                direction = 0;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptState = 4;
        frameNum = 2;
        frameTimer = 0;
    case 4: //walk
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 5)
                frameNum = 2;
        }
        if (direction)
            xPos += 512;
        else
            xPos -= 512;
        break;
    case 5:
        frameNum = 6;
        break;
    default:
        break;
    }
    //frames array
    char fArray[] = {0, 1, 2, 0, 3, 0, 4};
    frameRect.up = 64 + direction * 32;
    frameRect.down = frameRect.up + 32;
    frameRect.left = fArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct41() //busted doorway
{

}

void Entity::npcAct42() // Yuki
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0,120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (xPos - 0x4000 < player->xPos &&
                xPos + 0x4000 > player->xPos &&
                yPos - 0x4000 < player->yPos &&
                yPos + 0x2000 > player->yPos ) {
            if (xPos <= player->xPos)
                direction = 2;
            else
                direction = 0;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptState = 4;
        frameNum = 2;
        frameTimer = 0;
    case 4: //walk
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 5)
                frameNum = 2;
        }
        if (direction)
            xPos += 512;
        else
            xPos -= 512;
        break;
    case 5:
        frameNum = 6;
        break;
    default:
        break;
    }
    yVel += 64;
    if (xVel > 1024)
        xVel = 1024;
    if (xVel < -1024)
        xVel = -1024;
    if (yVel > 1535)
        yVel = 1535;
    xPos += xVel;
    yPos += yVel;
    //frames array
    char fArray[] = {0, 1, 2, 0, 3, 0, 4};
    frameRect.up = direction * 16;
    frameRect.down = frameRect.up + 32;
    frameRect.left = fArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct43() //blackboard
{
    if (!scriptState) {
        scriptState = 1;
        yPos -= 8192;
        frameRect.up = 160;
        frameRect.down = 224;
        frameRect.left = 256 + direction * 80;
        frameRect.right = frameRect.left + 80;
    }

}

void Entity::npcAct44() //super cannon
{
    int drift, x, y, vel;
    switch (scriptState) {
    case 0:
        frameNum = 0;
        break;
    case 10:
        frameNum = 4;
        break;
    default: //firing bullets
        frameTimer++;
        if (frameTimer < 4)
            break;
        x = xPos;
        y = yPos;
        drift = random(-0x44, 0x44);
        if (direction) {
            vel = 0x8FF;
            xPos += 0x1C00;
        } else {
            vel = -0x8FF;
        }
        y += (scriptState-2) * 0x2000;
        createNpc(0xE, x, y, vel, drift, direction, NULL, 2); //create bullet
        createNpc(50, x, y, 0, 0, direction, NULL, 3); //create flash
        frameNum = scriptState;
        break;
    }
    //frames
    frameRect.left = 0x140 + (frameNum << 6);
    frameRect.right = frameRect.left + 0x40;
    frameRect.up = 0xE0 + direction * 0x60;
    frameRect.down = frameRect.up =  0x60;
}

void Entity::npcAct45() //exploding barrels
{

}

void Entity::npcAct46() //h/v trigger
{
    flags |= 0x100;

    if (direction) { //vert
        if (yPos > player->yPos)
            yPos -= 1535;
        else
            yPos += 1535;
    } else { //horiz
        if (xPos > player->xPos)
            xPos -= 1535;
        else
            xPos += 1535;
    }
}

void Entity::npcAct47() //CAM machine gun bullet
{

}

void Entity::npcAct48() //CAM HECL proj.
{

}

void Entity::npcAct49() //CAM Gamma blast
{

}

void Entity::npcAct50() // Muzzle flash entity
{

}

void Entity::npcAct51() // shell casings
{

}

void Entity::npcAct52() //Sitting blue robot
{
    frameRect.left = 480;
    frameRect.up = 192;
    frameRect.right = 512;
    frameRect.down = 224;
}

void Entity::npcAct53() //Skullstep foot
{

}

void Entity::npcAct54() //large lift
{

}

void Entity::npcAct55() //zazuma
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        break;
    case 3:
        scriptState = 4;
        frameNum = 0;
        frameTimer = 0;
    case 4:
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 4)
                frameNum = 0;
        }
        if (direction)
            xPos += 512;
        else
            xPos -= 512;
        break;
    case 5:
        frameNum = 4;
        break;
    }
    yVel += 32;
    if (yVel > 1535)
        yVel = 1535;
    yPos += yVel;
    //frames
    char frameArray[5] = {0,1,0,2,3};
    frameRect.left = 384 + frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 384 + direction * 48;
    frameRect.down = frameRect.up + 48;
}

void Entity::npcAct56() //trolly
{

}

void Entity::npcAct57() //enemy crow
{

}

void Entity::npcAct58() //enemy basu (1)
{

}

void Entity::npcAct59() //enemy door
{

}

void Entity::npcAct60() //toroko
{
    int range = 8192;
    int hMax = 1024;
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        xVel = 0;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (playerRange(range, range, range, range)) {
            if (xPos <= player->xPos)
                direction = 1;
            else
                direction = 0;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptState = 4;
        frameNum = 1;
        frameTimer = 1;
    case 4:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 4)
                frameNum = 1;
        }

        if (collision & LEFT)
            direction = 1;
        if (collision & RIGHT)
            direction = 0;

        if (direction)
            xVel = hMax;
        else
            xVel = -hMax;
        break;
    case 6:
        scriptState = 7;
        scriptTimer = 0;
        frameNum = 0;
        frameTimer = 0;
        yVel = -1024;
    case 7:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 4)
                frameNum = 0;
        }
        if (direction)
            xVel = 256;
        else
            xVel = -256;
        if (scriptTimer++) {
            if (collision & 8)
                scriptState = 3;
        }
    case 8:
        frameNum = 0;
        scriptTimer = 0;
        scriptState = 9;
        yVel = -512;
    case 9:
        if (scriptTimer++) {
            if (collision & 8)
                scriptState = 0;
        }
        break;
    case 10:
        scriptState = 11;
        frameNum = 5;
        yVel = -1024;
        playSound(SFX_fx_mimi_squeal);
        if (direction)
            xVel = 256;
        else
            xVel = -256;
        break;
    case 11:
        if (scriptTimer++) {
            if (collision & 8) {
                scriptState = 12;
                frameNum = 6;
                flags |= 0x2000;
            }
        }
        break;
    case 12:
        xVel = 0;
        break;
    default:
        break;
    }
    yVel += 64;
    if (xVel > hMax)
        xVel = hMax;
    if (xVel < -hMax)
        xVel = -hMax;
    if (yVel > 1535)
        yVel = 1535;
    xPos += xVel;
    yPos += yVel;
    //frames
    char frameArray[] = {0,1,2,1,3,7,8};
    frameRect.left = frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 128 + direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct61() //Arthur
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        xVel = 0;
    case 1:
        if (random(0,120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 5:
        frameNum = 3;
        xVel = 0;
        break;
    case 6:
        scriptState = 7;
        scriptTimer = 0;
        frameTimer = 0;
        yVel = -1024;
    case 7:
        frameNum = 2;
        if (direction)
            xVel = 512;
        else
            xVel = -512;
        if (scriptTimer++) {
            if (collision & 8)
                scriptState = 5;
        }
        break;
    case 8:
        scriptState = 9;
        frameNum = 4;
        frameTimer = 0;
    case 9:
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 7)
                frameNum = 4;
        }
        if (direction)
            xVel = 512;
        else
            xVel = -512;
        break;
    case 10:
        scriptState = 11;
        frameNum = 4;
        frameTimer = 0;
    case 11:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 7)
                frameNum = 4;
        }
        if (direction)
            xVel = 1024;
        else
            xVel = -1024;
        break;
    case 20:
        createNpc(145, 0, 0, 0, 0, 2, this, 2);
        frameNum = 0;
        scriptState = 0;
        break;
    case 30: //flyback
        scriptState = 31;
        scriptTimer = 0;
        frameTimer = 0;
        yVel = 0;
    case 31:
        frameNum = 2;
        if (direction)
            xVel = 1536;
        else
            xVel = -1536;
        if (collision & 1) {
            direction = 1;
            scriptState = 7;
            scriptTimer = 0;
            frameTimer = 0;
            yVel = -1024;
            xVel = 512;
            playSound(SFX_fx_crash_little);
            createExplosion(xPos, yPos, 2048, 4);
        }
        break;
    case 40:
        scriptState = 42;
        scriptTimer = 0;
        frameNum = 8;
        playSound(SFX_fx_teleport);
    case 42:
        frameNum++;
        if (frameNum > 9)
            frameNum = 8;
        scriptTimer++;
        if (scriptTimer > 100) {
            for (int i = 0; i < 4; i++) {
                int smokeX = random(-1536, 0);
                int smokeY = random(-341, 341);
                int smokeB = yPos + (random(-12, 12) << 9);
                int smokeA = xPos + (random(-12, 12) << 9);
                createNpc(4, smokeA, smokeB, smokeX, smokeY, 0, 0, 3);
            }
            scriptState = 50;
            gfxNum = 20;
            frameNum = 10;
        }
        break;
    case 0x3C:
        frameNum = 6;
        scriptState = 61;
        yVel = -1535;
        xVel = 1024;
        directive = 1;
        break;
    case 0x3D:
        yVel += 64;
        if (collision & 8) {
            scriptState = 0;
            directive = 0;
            xVel = 0;
        }
        break;
    default:
        break;
    }
    if (scriptState < 30 || scriptState >= 40) {
        yVel += 64;
        if (xVel > 1024)
            xVel = 1024;
        if (xVel < -1024)
            xVel = -1024;
        if (yVel > 1535)
            yVel = 1535;
    }
    xPos += xVel;
    yPos += yVel;
    //frames
    char frameArray[] = {0, 1, 2, 3, 0, 4, 0, 5, 3, 3, 3};
    frameRect.left = 448 + frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 64 + (bool)direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct62() //zazuma @ computer
{
    switch (scriptState) {
    case 0:
        xPos -= 2048;
        yPos += 8192;
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 1)
                frameNum = 0;
        }
        if (random(0, 80) == 1) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (random(0, 120) == 10) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 40) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 2;
        }
        break;
    case 3:
        scriptTimer++;
        if (scriptTimer > 80) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    default:
        break;
    }
    //frames
    frameRect.left = frameNum * 32 + 544;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 384 + direction * 48;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct63() //toroookoooo attak
{

}

void Entity::npcAct64() //critter hopping blue
{
    switch (scriptState) {
    case 0: //initialize
        yPos += 1536;
        scriptState = 1;
    case 1: //sit
        //always face pc
        if (xPos <= player->xPos)
            direction = 2;
        else
            direction = 0;

        if (scriptTimer < 8 || !playerRange(0xE000, 0xA000, 0xE000, 0xA000)) {
            if (scriptTimer < 8)
                scriptTimer++;
            frameNum = 0;
        } else { //within wakeup box
            frameNum = 1;
            if (scriptTimer < 8)
				scriptTimer++;
        }

        if (damageTaken) { //jump if hit
            scriptState = 2;
            frameNum = 0;
            scriptTimer = 0;
        }

        if (scriptTimer >= 8 && playerRange(0x6000, 0xA000, 0x6000, 0x6000)) {
            scriptState = 2;
            frameNum = 0;
            scriptTimer = 0;
        }
        break;
    case 2: //jump
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 3;
            frameNum = 2;
            yVel = -0x5FF;
            playSound(SFX_fx_crit_jump);
            if (direction)
                xVel = 0x100;
            else
                xVel = -0x100;
        }
        break;
    case 3: //in air
        if (collision & 8) {
            xVel = 0;
            scriptTimer = 0;
            frameNum = 0;
            scriptState = 1;
            playSound(SFX_fx_crit_land);
        }
        break;
    default:
        break;
    }//switch
    yVel += 64;
    if (yVel > 0x5FF)
        yVel = 0x5FF;
    xPos += xVel;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    if (direction) {
        frameRect.up = 32;
        frameRect.down = 64;
    } else {
        frameRect.up = 0;
        frameRect.down = 32;
    }
}

void Entity::npcAct65() //bat blue
{
    switch (scriptState) {
    case 0:
        targetX = xPos;
        targetY = yPos;
        objectTimer = 120;
        scriptState = 1;
        scriptTimer = random(0, 50);
    case 1:
        scriptTimer++;
        if (scriptTimer >= 50) {
            scriptTimer = 0;
            scriptState = 2;
            yVel = 768;
        }
        break;
    case 2:
        if (player->xPos >= xPos)
            direction = 1;
        else
            direction = 0;

        if (targetY < yPos)
            yVel -= 16;
        else
            yVel += 16;

        if (yVel > 768)
            yVel = 768;
        if (yVel < -768)
            yVel = -768;
        break;
    default:
        break;
    }

    yPos += yVel;
    xPos += xVel;
    frameTimer++;
    if (frameTimer > 1) {
        frameNum++;
        if (frameNum > 2)
            frameNum = 0;
    }

    //frames
    frameRect.left = 64 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 64 + direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct66() //misery bubble
{

}

void Entity::npcAct67() //misery float
{

}

void Entity::npcAct68() //balrog running boss (form1)
{

}

void Entity::npcAct69() //enemy pignon
{

}

void Entity::npcAct70() //sparkle item
{
    frameTimer++;
    if (frameTimer > 3) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 3)
            frameNum = 0;
    }
    //frames
    frameRect.up = 96;
    frameRect.down = 128;
    frameRect.left = 192 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct71() //chinfish
{
    if (!scriptState) {
        scriptState = 1;
        targetX = xPos;
        targetY = yPos;
        yVel = 0x80;
    }
    if (scriptState == 1) {
        if (targetY < yPos)
            yVel -= 8;
        if (targetY > yPos)
            yVel += 8;
        if (yVel > 0x100)
            yVel = 0x100;
        if (yVel < -0x100)
            yVel = -0x100;
    }
    xPos += xVel;
    yPos += yVel;
    frameTimer++;
    if (frameTimer > 4) {
        frameTimer = 0;
        frameNum++;
    }
    if (frameNum > 1)
        frameNum = 0;
    if (damageTaken)
        frameNum = 2;
    frameRect.left = 128 + (frameNum * 32);
    frameRect.right = frameRect.left + 32;
    if (!direction) {
        frameRect.up = 64;
        frameRect.down = 96;
    } else {
        frameRect.up = 96;
        frameRect.down = 128;
    }
}

void Entity::npcAct72() //Spronkler
{

}

void Entity::npcAct73() //Water droplet
{
    yVel += 0x20;
    frameNum = random(0, 4);
    if (yVel > 0x5FF)
        yVel = 0x5FF;
    xPos += xVel;
    yPos += yVel;

    frameRect.up = 32;
    frameRect.down = 36;
    frameRect.left = 144 + (frameNum*4);
    frameRect.right = frameRect.left + 4;

    if (direction == 2) {
        frameRect.up += 4;
        frameRect.down += 4;
    }

    scriptTimer++;
    if (scriptTimer > 10) {
        if (collision & 0x10D)
            inUse = 0;
    }
    if (scriptTimer > 0x100)
        inUse = 0;
}

void Entity::npcAct74() //Jack
{

}

void Entity::npcAct75() //Kanpachi fisning
{

}

void Entity::npcAct76() //flowrs
{
    if (!scriptState) {
        frameRect.left = 32 * eventNum;
        frameRect.up = 0;
        frameRect.right = frameRect.left + 32;
        frameRect.down =  32;
        scriptState = 1;
    }
}

void Entity::npcAct77() //sandaime's pavillion (Akahana's rack)
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    default:
        break;
    }
    //frames
    if (direction)
        frameNum = 2;
    frameRect.left = frameNum * 96;
    frameRect.right = frameRect.left + 96;
    frameRect.up = 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct78() //Pots
{
    frameRect.up = 96;
    frameRect.down = 128;
    frameRect.left = 320 + direction * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct79() //mahin
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 2;
        frameTimer = 0;
        break;
    case 1:
        frameNum = 2;
        break;
    case 2:
        frameNum = 0;
        if (random(0, 120) == 10) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (playerRange(0x4000, 0x4000, 0x4000, 0x2000)) {
            if (xPos <= player->xPos)
                direction = 1;
            else
                direction = 0;
        }
        break;
    case 3:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 2;
            frameNum = 0;
        }
    default:
        break;
    }

    //phisicks
    yVel += 64;
    if (yVel > 1535)
        yVel = 1535;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct80() //Gravekeepre
{

}

void Entity::npcAct81() //Giagnt pignong
{

}

void Entity::npcAct82() //Mizaly stand
{

}

void Entity::npcAct83() //Igor (cutscene)
{

}

void Entity::npcAct84() //Projectile(basu 1)
{

}

void Entity::npcAct85() //Terminal
{
    if (scriptState == 0) {
        frameNum = 0;
        if (playerRange(0x1000, 0x2000, 0x1000, 0x1000)) {
            playSound(SFX_fx_computer_beep);
            scriptState = 1;
        }
    } else {
        frameNum++;
        if (frameNum > 2)
            frameNum = 1;
    }
    int fNum = frameNum;
    if (direction)
        fNum += 2;
    char frameArray[] = {0, 0, 1, 2, 3};
    fNum = frameArray[fNum];
    //frames
    frameRect.left = 512 + fNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 192;
    frameRect.down = frameRect.up + 48;
}

void Entity::npcAct86() //Missle
{

}

void Entity::npcAct87() //Heart
{
    if (!direction) {
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum ^= 1;
        }
        objectTimer++;
    }
    //frames
    frameRect.up = 160;
    frameRect.down = frameRect.up + 32;
    frameRect.left = 64 + frameNum * 32;
    if (experience == 6)
        frameRect.left += 64;
    frameRect.right = frameRect.left + 32;

    //timeouts
    if (objectTimer > 550) {
        inUse = 0;
    } else if (objectTimer > 500) {
        if (objectTimer < 457) {
            if (objectTimer / 2 % 2)
                frameRect.right = frameRect.left;
        } else { //must be between 457 and 550; appear as a blip
            frameRect.left = 32;
            frameRect.up = 0;
            frameRect.right = 64;
            frameRect.down = 32;
        }
    }
}

void Entity::npcAct88() //Boss Igor <lazer bee>
{

}

void Entity::npcAct89() //Igor defeated
{

}

void Entity::npcAct90() //background (?)
{

}

void Entity::npcAct91() //Cage
{

}

void Entity::npcAct92() //Sue computer
{

}

void Entity::npcAct93() //chaco
{

}

void Entity::npcAct94() //Kulala (giant jelly)
{

}

void Entity::npcAct95() //enemy jelly
{

}

void Entity::npcAct96() //fan L
{

}

void Entity::npcAct97() //fan U
{

}

void Entity::npcAct98() //fan R
{

}

void Entity::npcAct99() //fan D
{

}

void Entity::npcAct100() //grate
{
    if (!scriptState) {
        yPos += 8192;
        scriptState = 1;
    }
    frameRect.left = 344;
    frameRect.up = 96;
    frameRect.right = frameRect.left + 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct101() //power controls screen
{

}

void Entity::npcAct102() //power controls power flow
{

}

void Entity::npcAct103() //Projectile - Mannan
{
    if (direction)
        xVel += 32;
    else
        xVel -= 32;

    frameNum++;
    if (frameNum > 2)
        frameNum = 0;

    xPos += xVel;
    //frames
    frameRect.left = 386 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = 386 + direction * 48;
    frameRect.down = frameRect.up + 48;
}

void Entity::npcAct104() //Enemy - Frog
{

}

void Entity::npcAct105() //Balloon ('Hey!' low)
{

}

void Entity::npcAct106() //Balloon ('Hey!' high)
{

}

void Entity::npcAct107() //Malco (undamaged)
{

}

void Entity::npcAct108() //Projectile - Balfrog
{

}

void Entity::npcAct109() //Malco (damaged)
{

}

void Entity::npcAct110() //Enemy - Puchi
{

}

void Entity::npcAct111() //Quote (teleports out)
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        yPos -= 8192;
        break;
    case 1:
        scriptTimer++;
        if (scriptTimer > 20) {
            scriptTimer = 0;
            scriptState = 2;
            frameNum = 1;
            yVel = -767;
        }
        break;
    case 2:
        if (yVel > 0)
            hitRect.down = 8192;
        if (collision & 8) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 0;
        }
        break;
    case 3:
        scriptTimer++;
        if (scriptTimer > 40) {
            scriptState = 4;
            scriptTimer = 64;
            playSound(SFX_fx_teleport);
        }
        break;
    case 4:
        scriptTimer--;
        frameNum = 0;
        if (!scriptTimer)
            inUse = 0;
        break;
    default:
        break;
    }

    yVel += 64;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = player->charNum * 64 + direction * 32;
    frameRect.down = frameRect.up + 32;

    //blinky thing
    if (scriptState == 4) {
        frameRect.down = frameRect.up + scriptTimer / 2;
        if (scriptTimer / 2 % 2)
            ++frameRect.left;
    }
}

void Entity::npcAct112() //Quote (teleports in)
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        yPos += 8192;
        yPos += 4096;
        playSound(SFX_fx_teleport);
    case 1:
        scriptTimer++;
        if (scriptTimer == 64) {
            scriptTimer = 0;
            scriptState = 2;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 20) {
            scriptState = 3;
            frameNum = 1;
            hitRect.down = 4096;
        }
        break;
    case 3:
        if (collision & 8) {
            scriptState = 4;
            scriptTimer = 0;
            frameNum = 0;
        }
        break;
    default:
        break;
    }

    yVel += 64;
    yPos += yVel;
    //frames
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = player->charNum * 64 + direction * 32;
    frameRect.down = frameRect.up + 32;

    //blinky thing
    if (scriptState == 1) {
        frameRect.down = frameRect.up + scriptTimer / 2;
        if (scriptTimer / 2 % 2)
            ++frameRect.left;
    }
}

void Entity::npcAct113() //Prof. Booster
{

}

void Entity::npcAct114() //Enemy - Press
{

}

void Entity::npcAct115() //Enemy - Ravil
{

}

void Entity::npcAct116() //Red Flowers (petals)
{

}

void Entity::npcAct117() //Curly
{

}

void Entity::npcAct118() //Boss - Curly
{

}

void Entity::npcAct119() //Table & chair
{
    frameRect.left = 496;
    frameRect.up = 368;
    frameRect.right = 544;
    frameRect.down = 400;
}

void Entity::npcAct120() //Colon 1
{
    frameRect.left = 128;
    frameRect.right = 160;
    frameRect.up = direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct121() //Colon 2
{
    if (!direction) {
        switch (scriptState) {
        case 0:
            scriptState = 1;
            frameNum = 0;
            frameTimer = 0;
        case 1:
            if (random(0, 120) == 10) {
                scriptState = 2;
                scriptTimer = 0;
                frameNum = 1;
            }
            break;
        case 2:
            scriptTimer++;
            if (scriptTimer > 8) {
                scriptState = 1;
                frameNum = 0;
            }
            break;
        default:
            break;
        }
        frameRect.left = frameNum * 32;
    } else {
        scriptTimer++;
        if (scriptTimer > 100) {
            scriptTimer = 0;
            createEffect(xPos, yPos, 5, 0);
        }
        frameRect.left = 224;
    }
    //frames
    frameRect.right = frameRect.left + 32;
    frameRect.up = 0;
    frameRect.down = 32;
}

void Entity::npcAct122() //Enemy - Colon
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (playerRange(0x4000, 0x4000, 0x4000, 0x2000)) {
            if (xPos < player->xPos)
                direction = 1;
            else
                direction = 0;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 10:
        health = 1000;
        scriptState = 11;
        scriptTimer = random(0, 50);
        frameNum = 0;
        damage = 0;
    case 11:
        if (scriptTimer > 0)
            scriptTimer--;
        else
            scriptState = 13;
        break;
    case 13:
        scriptState = 14;
        scriptTimer = random(0, 50);
        if (xPos < player->xPos)
            direction = 1;
        else
            direction = 0;
    case 14:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 5)
                frameNum = 2;
        }
        if (direction)
            xVel += 64;
        else
            xVel -= 64;

        if (scriptTimer > 0) {
            scriptTimer--;
        } else {
            flags |= 0x20;
            scriptState = 15;
            frameNum = 2;
            yVel = -512;
            damage = 2;
        }
        break;
    case 15:
        if (collision & 8) {
            flags |= 0x20;
            xVel = 0;
            scriptState = 10;
            damage = 0;
        }
        break;
    case 20:
        if (collision & 8) {
            xVel = 0;
            scriptState = 21;
            damage = 0;
            if (frameNum == 6)
                frameNum = 8;
            else
                frameNum = 9;
            scriptTimer = random(300, 400);
        }
        break;
    case 21:
        if (scriptTimer > 0) {
            scriptTimer--;
        } else {
            flags |= 0x20;
            health = 1000;
            scriptState = 11;
            scriptTimer = random(0, 50);
            frameNum = 0;
        }
        break;
    default:
        break;
    }
    if ((scriptState > 10) && (scriptState < 20)) {
        if (health != 1000)
            scriptState = 20;
        yVel = -512;
        frameNum = random(6, 7);
        flags &= 0xFFDF;
    }

    //fizzkcs
    yVel += 32;
    int xMax = 511;
    if (xVel > xMax)
        xVel = xMax;
    if (xVel < -xMax)
        xVel = -xMax;
    if (yVel > 1535)
        yVel = 1535;
    xPos += xVel;
    yPos += yVel;
    //frames
    char frameArray[] = {0, 1, 2, 0, 3, 0, 5, 6, 7, 8};
    int frame = frameArray[frameNum];
    frameRect.left = frame * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct123() //Projectile - Curly
{

}

void Entity::npcAct124() //Sunstone
{

}

void Entity::npcAct125() //Hidden heart/missile
{

}

void Entity::npcAct126() //Puppy (runs away)
{

}

void Entity::npcAct127() //Glows momentarily?
{

}

void Entity::npcAct128() //Glows momentarily?
{

}

void Entity::npcAct129() //Glows momentarily?
{

}

void Entity::npcAct130() //Puppy (tail wag)
{

}

void Entity::npcAct131() //Puppy (sleeping)
{

}

void Entity::npcAct132() //Puppy (bark)
{

}

void Entity::npcAct133() //Jenka
{

}

void Entity::npcAct134() //Enemy - Armadillo
{

}

void Entity::npcAct135() //Enemy - Skeleton
{

}

void Entity::npcAct136() //Puppy (carried)
{

}

void Entity::npcAct137() //Large doorway (frame)
{

}

void Entity::npcAct138() //Large doorway (doors)
{

}

void Entity::npcAct139() //Doctor (crowned)
{

}

void Entity::npcAct140() //Boss - Frenzied Toroko
{

}

void Entity::npcAct141() //<CRASH>
{

}

void Entity::npcAct142() //Enemy - Flowercub
{

}

void Entity::npcAct143() //Jenka (collapsed)
{

}

void Entity::npcAct144() //Toroko (teleports in)
{

}

void Entity::npcAct145() //<CRASH>
{

}

void Entity::npcAct146() //Lightning
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        if (direction)
            ;//screenFlash(0, 0, 2);
        break;
    case 1:
        scriptTimer++;
        if (scriptTimer > 10) {
            scriptState = 2;
            playSound(SFX_fx_lightning);
        }
        break;
    case 2:
        frameTimer++;
        if (frameTimer > 2) {
            frameTimer = 0;
            frameNum++;
        }
        if (frameNum == 2)
            damage = 10;
        if (frameNum > 4) {
            createExplosion(xPos, yPos, 4096, 8);
            inUse = 0;
        }
        break;
    default:
        break;
    }
    //frames
    frameRect.left = 480 + frameNum * 32;
    frameRect.right = frameRect.left = 32;
    frameRect.up = 0;
    frameRect.down = 480;
    if (frameNum == 0)
        frameRect.right =  frameRect.left;
}

void Entity::npcAct147() //Enemy - Critter (hover)
{

}

void Entity::npcAct148() //Projectile - Critter
{

}

void Entity::npcAct149() //Moving block (horiz)
{

}

void Entity::npcAct150() //Quote
{
    char frameArray[] = {0, 3, 9, 2, 0, 3, 0, 10, 7};
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        if (direction > 10) {
            xPos = player->xPos;
            yPos = player->yPos;
            direction -= 10;
        }
        break;
    case 1:
        frameNum = 1;
        break;
    case 10: //fall over
        scriptState = 11;
        for (int i = 0; i < 4; i++) {
            int v1 = random(-1536, 0);
            int v2 = random(-341, 341);
            createNpc(4, xPos, yPos, v2, v1, 0, NULL, 3);
        }
        playSound(SFX_fx_explode_small);
    case 11:
        frameNum = 2;
        break;
    case 20: //teleported
        scriptState = 21;
        scriptTimer = 64;
        playSound(SFX_fx_teleport);
    case 21:
        scriptTimer--;
        if (!scriptTimer)
            inUse = 0;
        break;
    case 50: //run
        scriptState = 51;
        frameNum = 3;
        frameTimer = 0;
    case 51:
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 6)
                frameNum = 3;
        }
        if (direction)
            xPos += 512;
        else
            xPos -= 512;
        break;

    case 70: //walk
        scriptState = 51;
        frameNum = 3;
        frameTimer = 0;
    case 71:
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 6)
                frameNum = 3;
        }
        if (direction)
            xPos += 256;
        else
            xPos -= 256;
        break;

    case 80: //checking a thing
        frameNum = 3;
        break;
    }

    //frames
    frameRect.up = player->charNum * 64 + (direction & 1) * 32;
    frameRect.down = frameRect.up + 32;
    frameRect.left = frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;

    if (scriptState == 21) {
        frameRect.down = frameRect.up + scriptTimer / 2;
        if (scriptTimer / 2 % 2)
            ++frameRect.left;
    }
}

void Entity::npcAct151() //Blue robot
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (!random(0, 100)) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 16) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    default:
        break;
    }
    //frames
    frameRect.left = 384 + frameNum * 32;
    frameRect.right =  frameRect.left + 32;
    frameRect.up = direction * 32;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct152() //Shutter (stuck)
{

}

void Entity::npcAct153() //Enemy - Gaudi
{

}

void Entity::npcAct154() //Enemy - Gaudi (defeated)
{

}

void Entity::npcAct155() //Enemy - Gaudi (flying)
{

}

void Entity::npcAct156() //Projectile - Gaudi (flying)
{

}

void Entity::npcAct157() //Moving block (vert)
{

}

void Entity::npcAct158() //Projectile - Monster X
{

}

void Entity::npcAct159() //Boss - Monster X (defeated)
{

}

void Entity::npcAct160() //Boss - Pooh Black
{

}

void Entity::npcAct161() //Projectile - Pooh Black
{

}

void Entity::npcAct162() //Pooh Black (defeated)
{

}

void Entity::npcAct163() //Dr. Gero
{

}

void Entity::npcAct164() //Nurse Hasumi
{

}

void Entity::npcAct165() //Curly (collapsed)
{

}

void Entity::npcAct166() //Chaba
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
    }
    //frames
    frameRect.up = 208;
    frameRect.down = 256;
    frameRect.left = 288 + frameNum * 80;
    frameRect.right = frameRect.left + 80;
}

void Entity::npcAct167() //Prof. Booster (fall)
{

}

void Entity::npcAct168() //Boulder
{

}

void Entity::npcAct169() //Boss - Balrog (missiles)
{

}

void Entity::npcAct170() //Projectile - Balrog (missiles)
{

}

void Entity::npcAct171() //Enemy - Fire Whirrr
{

}

void Entity::npcAct172() //Projectile - Fire Whirrr
{

}

void Entity::npcAct173() //Enemy - Gaudi Armor
{

}

void Entity::npcAct174() //Projectile - Gaudi Armor
{

}

void Entity::npcAct175() //Enemy - Gaudi Egg
{

}

void Entity::npcAct176() //Enemy - Buyobuyo Base
{

}

void Entity::npcAct177() //Enemy - Buyobuyo
{

}

void Entity::npcAct178() //Projectile - Core (spinner)
{

}

void Entity::npcAct179() //Projectile - Core (wisp)
{

}

void Entity::npcAct180() //Curly (A.I.)
{

}

void Entity::npcAct181() //<nothing?>
{

}

void Entity::npcAct182() //<nothing?>
{

}

void Entity::npcAct183() //<nothing?>
{

}

void Entity::npcAct184() //Shutter (large)
{

}

void Entity::npcAct185() //Shutter (small)
{

}

void Entity::npcAct186() //Lift block
{

}

void Entity::npcAct187() //Enemy - Fuzz Core
{

}

void Entity::npcAct188() //<CRASH>
{

}

void Entity::npcAct189() //Projectile - Homing Flame
{

}

void Entity::npcAct190() //Surface robot
{

}

void Entity::npcAct191() //Water level
{

}

void Entity::npcAct192() //Scooter
{

}

void Entity::npcAct193() //Scooter (pieces)
{

}

void Entity::npcAct194() //Blue robot (pieces)
{
    if (!scriptState) {
        scriptState = 1;
        yPos += 2048;
        frameRect.left = 384;
        frameRect.up = 240;
        frameRect.right = 448;
        frameRect.down = 256;
    }
}

void Entity::npcAct195() //Grate mouth
{

}

void Entity::npcAct196() //Motion wall
{

}

void Entity::npcAct197() //Enemy - Porcupine Fish
{

}

void Entity::npcAct198() //Projectile - Ironhead
{

}

void Entity::npcAct199() //Underwater current
{

}

void Entity::npcAct200() //Enemy - Dragon Zombie
{

}

void Entity::npcAct201() //Dragon Zombie (dead)
{

}

void Entity::npcAct202() //Projectile - Dragon Zombie
{

}

void Entity::npcAct203() //Enemy - Critter (hopping, aqua)
{

}

void Entity::npcAct204() //Falling Spike (small)
{

}

void Entity::npcAct205() //Falling Spike (large)
{

}

void Entity::npcAct206() //Enemy - Counter Bomb
{

}

void Entity::npcAct207() //Balloon (countdown)
{

}

void Entity::npcAct208() //Enemy - Basu (2)
{

}

void Entity::npcAct209() //Projectile - Basu (2)
{

}

void Entity::npcAct210() //Enemy - Beetle (follow 2)
{

}

void Entity::npcAct211() //Spikes
{
    frameRect.up = 400;
    frameRect.down = 432;
    frameRect.left = 512 + eventNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct212() //Sky Dragon
{

}

void Entity::npcAct213() //Enemy - Night Spirit
{

}

void Entity::npcAct214() //Projectile - Night Spirit
{

}

void Entity::npcAct215() //Enemy - Sandcroc (white)
{

}

void Entity::npcAct216() //Debug cat
{

}

void Entity::npcAct217() //Itoh
{

}

void Entity::npcAct218() //Projectile?
{

}

void Entity::npcAct219() //Generator - Smoke/Underwater current
{

}

void Entity::npcAct220() //Shovel Brigade
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0, 120) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
    }
    //frames
    frameRect.up = 128 + direction * 32;
    frameRect.down = frameRect.up + 32;
    frameRect.left = frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct221() //Shovel Brigade (walking)
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        xVel = 0;
    case 1:
        if (random(0, 60) == 1) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (random(0, 60) == 1) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptState = 4;
        scriptTimer = random(0, 16);
        frameNum = 2;
        frameTimer = 0;
        if (random(0, 9) % 2)
            direction = 0;
        else
            direction = 1;
    case 4:
        if (direction || !(collision & 1)) {
            if ((direction) && (collision & 4))
                direction = 0;
        } else {
            direction = 1;
        }

        if (direction)
            xVel = 512;
        else
            xVel = -512;
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 5)
                frameNum = 2;
        }
        scriptTimer++;
        if (scriptTimer > 32)
            scriptState = 0;
        break;
    default:
        break;
    }
    yVel += 32;
    if (yVel > 1535)
        yVel = 1535;
    xPos += xVel;
    yPos += yVel;
    //frames
    char frameArray[] = {0, 1, 2, 0, 3, 0};
    frameRect.left = frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = direction * 32 + 128;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct222() //Prison bars
{

}

void Entity::npcAct223() //Momorin
{

}

void Entity::npcAct224() //Chie
{

}

void Entity::npcAct225() //Megane
{

}

void Entity::npcAct226() //Kanpachi
{

}

void Entity::npcAct227() //Bucket
{

}

void Entity::npcAct228() //Droll (guard)
{

}

void Entity::npcAct229() //Red Flowers (sprouts)
{

}

void Entity::npcAct230() //Red Flowers (blooming)
{

}

void Entity::npcAct231() //Rocket
{

}

void Entity::npcAct232() //Enemy - Orangebell
{

}

void Entity::npcAct233() //<CRASH>
{

}

void Entity::npcAct234() //Red Flowers (picked)
{

}

void Entity::npcAct235() //Enemy - Midorin
{

}

void Entity::npcAct236() //Enemy - Gunfish
{

}

void Entity::npcAct237() //Projectile - Gunfish
{

}

void Entity::npcAct238() //Enemy - Press (killer)
{

}

void Entity::npcAct239() //Cage bars
{

}

void Entity::npcAct240() //Mimiga (jailed)
{
    switch (scriptState) {
    case 0:
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
        xVel = 0;
    case 1:
        if (random(0, 60) == 1) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        if (random(0, 60) == 1) {
            scriptState = 3;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 8) {
            scriptState = 1;
            frameNum = 0;
        }
        break;
    case 3:
        scriptState = 4;
        scriptTimer = random(0, 16);
        frameNum = 2;
        frameTimer = 0;
        if (random(0, 9) % 2)
            direction = 0;
        else
            direction = 1;
    case 4:
        if (direction || !(collision & 1)) {
            if ((direction) && (collision & 4))
                direction = 0;
        } else {
            direction = 1;
        }

        if (direction)
            xVel = 512;
        else
            xVel = -512;
        frameTimer++;
        if (frameTimer > 4) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 5)
                frameNum = 2;
        }
        scriptTimer++;
        if (scriptTimer > 32)
            scriptState = 0;
        break;
    default:
        break;
    }
    yVel += 32;
    if (yVel > 1535)
        yVel = 1535;
    xPos += xVel;
    yPos += yVel;
    //frames
    char frameArray[] = {0, 1, 2, 0, 3, 0};
    frameRect.left = 320 + frameArray[frameNum] * 32;
    frameRect.right = frameRect.left + 32;
    frameRect.up = direction * 32 + 128;
    frameRect.down = frameRect.up + 32;
}

void Entity::npcAct241() //Enemy - Critter (hopping, red)
{

}

void Entity::npcAct242() //Enemy - Bat (red)
{

}

void Entity::npcAct243() //Generator - Bat (red)
{

}

void Entity::npcAct244() //Acid drop
{

}

void Entity::npcAct245() //Generator - Acid drop
{

}

void Entity::npcAct246() //Enemy - Press (proximity)
{

}

void Entity::npcAct247() //Boss - Misery
{

}

void Entity::npcAct248() //Boss - Misery (vanish)
{

}

void Entity::npcAct249() //Projectile - Misery (energy shot)
{

}

void Entity::npcAct250() //Projectile - Misery (lightning ball)
{

}

void Entity::npcAct251() //Projectile - Misery (lightning)
{

}

void Entity::npcAct252() //<CRASH>
{

}

void Entity::npcAct253() //Energy Capsule
{

}

void Entity::npcAct254() //Helicopter
{

}

void Entity::npcAct255() //<CRASH>
{

}

void Entity::npcAct256() //Doctor (crowned, facing away)
{

}

void Entity::npcAct257() //Red Crystal
{

}

void Entity::npcAct258() //Mimiga (sleeping)
{

}

void Entity::npcAct259() //Curly (carried, unconscious)
{

}

void Entity::npcAct260() //Shovel Brigade (caged)
{
    switch (scriptState) {
    case 0:
        xPos += 512;
        yPos -= 512;
        scriptState = 1;
        frameNum = 0;
        frameTimer = 0;
    case 1:
        if (random(0, 160) == 10) {
            scriptState = 2;
            scriptTimer = 0;
            frameNum = 1;
        }
        break;
    case 2:
        scriptTimer++;
        if (scriptTimer > 12) {
            scriptState = 1;
            frameNum = 0;
        }
    }
    if (player->xPos >= xPos)
        direction = 1;
    else
        direction = 0;
    //frames
    frameRect.up = 128 + direction * 32;
    frameRect.down = frameRect.up + 32;
    frameRect.left = 256 + frameNum * 32;
    frameRect.right = frameRect.left + 32;
}

void Entity::npcAct261() //Chie (caged)
{

}

void Entity::npcAct262() //Chaco (caged)
{

}

void Entity::npcAct263() //Boss - Doctor
{

}

void Entity::npcAct264() //Projectile - Doctor (red wave)
{

}

void Entity::npcAct265() //Projectile - Doctor (red ball - fast vanish)
{

}

void Entity::npcAct266() //Projectile - Doctor (red ball - slow vanish)
{

}

void Entity::npcAct267() //Boss - Muscle Doctor
{

}

void Entity::npcAct268() //Enemy - Igor
{

}

void Entity::npcAct269() //Enemy - Bat (red energy)
{

}

void Entity::npcAct270() //Red energy
{

}

void Entity::npcAct271() //Underwater block
{

}

void Entity::npcAct272() //Generator - Underwater block
{

}

void Entity::npcAct273() //Projectile - Droll
{

}

void Entity::npcAct274() //Enemy - Droll
{

}

void Entity::npcAct275() //Puppy (with items)
{

}

void Entity::npcAct276() //Boss - Red Demon
{

}

void Entity::npcAct277() //Projectile - Red Demon
{

}

void Entity::npcAct278() //Little family
{

}

void Entity::npcAct279() //Falling block (large)
{

}

void Entity::npcAct280() //Sue (teleported in by Misery)
{

}

void Entity::npcAct281() //Doctor (red energy form)
{

}

void Entity::npcAct282() //Mini Undead Core - floats forward
{

}

void Entity::npcAct283() //Enemy - Misery (transformed)
{

}

void Entity::npcAct284() //Enemy - Sue (transformed)
{

}

void Entity::npcAct285() //Projectile - Undead Core (orange spiral shot)
{

}

void Entity::npcAct286() //Orange Dot
{

}

void Entity::npcAct287() //Orange Smoke
{

}

void Entity::npcAct288() //Projectile - Undead Core (glowing rock thing)
{

}

void Entity::npcAct289() //Enemy - Critter (hopping, orange)
{

}

void Entity::npcAct290() //Enemy - Bat (orange)
{

}

void Entity::npcAct291() //Mini Undead Core (before fight)
{

}

void Entity::npcAct292() //Quake
{

}

void Entity::npcAct293() //Projectile - Undead Core (huge energy shot)
{

}

void Entity::npcAct294() //Quake & Generator - Falling blocks
{

}

void Entity::npcAct295() //Cloud
{

}

void Entity::npcAct296() //Generator - Cloud
{

}

void Entity::npcAct297() //<CRASH> (Sometimes)
{

}

void Entity::npcAct298() //Doctor (uncrowned)
{

}

void Entity::npcAct299() //Balrog/Misery (bubble)
{

}

void Entity::npcAct300() //Demon (blade?)
{
    if (!scriptState) {
        scriptState = 1;
        yPos += 3072;
    }
    frameTimer++;
    if (frameTimer * 8 == 1) {
        int v1 = yPos + 4096;
        int v2 = random(-8, 8);
        createEffect(xPos + (v2 << 9), v1, 13, 1);
    }
    frameRect.left = 384;
    frameRect.up = 160;
    frameRect.right = 416;
    frameRect.down = 192;
}

void Entity::npcAct301() //Enemy - Fish Missile (orange)
{

}

void Entity::npcAct302() //Something with ending Scenes
{

}

void Entity::npcAct303() //<nothing?>
{

}

void Entity::npcAct304() //Gaudi (sitting)
{

}

void Entity::npcAct305() //Puppy (small)
{

}

void Entity::npcAct306() //Balrog (nurse)
{

}

void Entity::npcAct307() //Santa (caged)
{

}

void Entity::npcAct308() //Enemy - Stumpy
{

}

void Entity::npcAct309() //Enemy - Bute
{

}

void Entity::npcAct310() //Enemy - Bute (sword)
{

}

void Entity::npcAct311() //Enemy - Bute (archer)
{

}

void Entity::npcAct312() //Projectile - Bute (archer)
{

}

void Entity::npcAct313() //Boss - Ma Pignon
{

}

void Entity::npcAct314() //Falling, Indestructible
{

}

void Entity::npcAct315() //Enemy (hopping, disappears)
{

}

void Entity::npcAct316() //Enemy - Bute (defeated)
{

}

void Entity::npcAct317() //Enemy - Mesa
{

}

void Entity::npcAct318() //Enemy - Mesa (defeated)
{

}

void Entity::npcAct319() //<CRASH>
{

}

void Entity::npcAct320() //Curly (carried, shooting)
{

}

void Entity::npcAct321() //<nothing?>
{

}

void Entity::npcAct322() //Enemy - Deleet
{

}

void Entity::npcAct323() //Enemy - Bute (generator)
{

}

void Entity::npcAct324() //Generator - Bute
{

}

void Entity::npcAct325() //Projectile - Heavy Press
{

}

void Entity::npcAct326() //Itoh/Sue (turning human)
{

}

void Entity::npcAct327() //<CRASH>
{

}

void Entity::npcAct328() //Transmogrifier
{

}

void Entity::npcAct329() //Building fan
{

}

void Entity::npcAct330() //Enemy - Rolling
{

}

void Entity::npcAct331() //Projectile - Ballos (bone)
{

}

void Entity::npcAct332() //Projectile - Ballos (shockwave)
{

}

void Entity::npcAct333() //Projectile - Ballos (lightning)
{

}

void Entity::npcAct334() //Sweat
{

}

void Entity::npcAct335() //Ika-chan
{

}

void Entity::npcAct336() //Generator - Ika-chan?
{

}

void Entity::npcAct337() //Numahachi
{

}

void Entity::npcAct338() //Enemy - Green Devil
{

}

void Entity::npcAct339() //Generator - Green Devil
{

}

void Entity::npcAct340() //Boss - Ballos
{

}

void Entity::npcAct341() //<CRASH>
{

}

void Entity::npcAct342() //<CRASH>
{

}

void Entity::npcAct343() //<CRASH>
{

}

void Entity::npcAct344() //<CRASH>
{

}

void Entity::npcAct345() //Projectile - Ballos (skull)
{

}

void Entity::npcAct346() //<CRASH>
{

}

void Entity::npcAct347() //Enemy - Hoppy
{

}

void Entity::npcAct348() //Ballos spikes (rising)
{

}

void Entity::npcAct349() //Statue
{

}

void Entity::npcAct350() //Enemy - Bute (archer, red)
{

}

void Entity::npcAct351() //Statue (can shoot)
{

}

void Entity::npcAct352() //King (sword)
{

}

void Entity::npcAct353() //Enemy - Bute (sword, red)
{

}

void Entity::npcAct354() //Invisible deathtrap wall
{

}

void Entity::npcAct355() //<CRASH> (Sometimes)
{

}

void Entity::npcAct356() //Balrog (rescue)
{

}

void Entity::npcAct357() //Puppy (ghost)
{

}

void Entity::npcAct358() //Misery (wind)
{

}

void Entity::npcAct359() //waterdroplet generator
{
    if ((player->xPos < (xPos + 0x28000)) &&
            (player->xPos > (xPos - 0x28000)) &&
            (player->yPos < (yPos + 0x28000)) &&
            (player->yPos > (yPos - 0x14000)) &&
            (random(0, 100) == 2)) {
        int localPos = random(-6, 6);
        createNpc(73, xPos + (localPos << 9), yPos - 0xE00, 0, 0, 0, NULL, 1);
    }
}

void Entity::npcAct360() //'Thank you!'
{

}
