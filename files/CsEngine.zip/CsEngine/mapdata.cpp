
#pragma once
typedef struct {
   char *filename;
   char *mapName;
   char *bgName;
   char *tileset;
   char *npc1;
   char *npc2;
   int mapX;
   int mapY;
   int scrollType;
   int bossNum;
}MapData;

MapData mapdata[16] =
{
   {"0", "Null", "bk0", "0", "Guest", "0", 21, 20, 4, 0},
   {"Pens1", "Arthur's House", "bkBlue", "Pens", "Guest", "0", 21, 16, 1, 0},
   {"Axcs", "Collapsed Tunnel", "bkBlue", "Weed", "Eggs1", "Ravil", 21, 30, 1, 0},
   {"Eggx", "Yuki's House", "bkBlack", "Pens", "Guest", "0", 21, 16, 0, 0},
   {"Egg6", "Akahana's House", "bk0", "Pens", "Guest", "0", 21, 16, 0, 0},
   {"EggR", "Housing Complex", "bk0", "Pens", "Guest", "Maze", 21, 16, 0, 0},
   {"Weed", "Grasstown", "bkBlue", "Weed", "Weed", "0", 280, 23, 1, 0},
   {"Santa", "Santa's House", "bk0", "Barr", "Weed", "0", 21, 16, 0, 0},
   {"Chako", "Chaco's House", "bkBlue", "Barr", "Guest", "0", 21, 16, 1, 0},
   {"MazeI", "Research Station", "bk0", "Store", "Maze", "0", 21, 16, 0, 0},
   {"Sand", "Crystal Caves", "bkCryst2", "Cryst", "Weed", "0", 100, 100, 1, 0},
   {"Mimi", "Mimiga Village", "bkBlue", "Mimi", "Guest", "Cent", 60, 60, 1, 0},
   {"Cave", "Hermit's Cave", "bkCave", "Cave", "Cemet", "0", 60, 45, 2, 0},
   {"Start", "Stagnant Pool", "bkCave", "Cave", "Cemet", "0", 21, 16, 2, 0},
   {"Barr", "King's House", "bkBlack", "Pens", "Regu", "Guest", 21, 16, 0, 0},
   {"Pool", "Resevoir", "bkBlue", "Mimi", "Guest", "0", 40, 20, 1, 0},
};
