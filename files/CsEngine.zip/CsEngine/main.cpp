
#include <allegro.h>
#include <time.h>
#include <stdio.h>

#include "weapon.h"
#include "profile.h"
#include "music.h"
#include "graphics.h"
#include "timers.h"
#include "defines.h"
#include "player.h"
#include "tsc.h"
#include "map.h"
#include "sfx.h"
#include "entity.h"
#include "effect.h"
#include "bullet.h"
#include "main.h"
#include "general.h"
#include "numobj.h"

#ifdef EDITOR_MODE
#define WIN_X 1280
#define WIN_Y 800
#include "debug.h"
#include "mapEdit.h"
#include "pxeEdit.h"
#else
#define WIN_X 640
#define WIN_Y 480
#endif

//variables declaration
int frames = 0;
int FPS = 0;
int is25FPS = 0;

extern int keyPressed;
extern int keyHeld;
extern char keyLock;

volatile int closeFlag = 0;
char gameState = 2;
char switchFor25 = 0;
/*
   0x1  -
   0x2  - can control
   0x4  - TSC
   0x8  -
   0x10 - PRI
   0x20 - Inventory screen
   0x40 -
   0x80 -
*/
int escHack = 0;

Player *player;

//Functions
void close_button_handler()
{
    closeFlag = 1;
#ifdef EDITOR_MODE
    forceCloseDialog();
#endif
}
END_OF_FUNCTION(close_button_handler);

void switchIn_callback()
{
    install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT, NULL);
    resumeSong();
}

void switchOut_callback()
{
    stopSong();
    remove_sound();
}

int initialize()
{
#ifdef VERBOSE
    setError("Init begin");
#endif
    allegro_init();
    install_keyboard();
    timerMain();

    //read config file
    int depth, numEntity, numParticle, volume, fullscreen;
    FILE *configFile = fopen("csengine.cfg", "rb");
    if (configFile) {
        fread(&depth, 4, 1, configFile);
        fread(&numEntity, 4, 1, configFile);
        numEntity /= 4;
        fread(&numParticle, 4, 1, configFile);
        fread(&volume, 4, 1, configFile);
        fread(&fullscreen, 4, 1, configFile);
        fread(&dataDir, 1, 64, configFile);
    } else {
        depth = 24;
        numEntity = 400;
        numParticle = 500;
        volume = 45;
        fullscreen = 0;
        sprintf(dataDir, "data/");
    }
    fclose(configFile);
    //setup window
    set_color_depth(depth);
    if (fullscreen) {
        set_gfx_mode(GFX_AUTODETECT, WIN_X, WIN_Y, 0, 0);
    } else {
        set_gfx_mode( GFX_AUTODETECT_WINDOWED, WIN_X, WIN_Y, 0, 0);
    }
    set_window_title("King ~ Strife and Sacrifice");

    //setup callbacks
    LOCK_FUNCTION(close_button_handler);
    set_close_button_callback(close_button_handler);
    set_display_switch_callback(SWITCH_IN, switchIn_callback);
    set_display_switch_callback(SWITCH_OUT, switchOut_callback);

    //initialize game
    initializeGraphics();
    int MusicErr = musicInit(volume);
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
    loadSfx();
    loadMapdata();
    entityInit(numEntity);
    bulletInit();
    numObjInit();
    effectInit();
    loadGlobalTsc();
    srand(time(NULL));

#ifdef EDITOR_MODE
    install_mouse();
    gui_fg_color = 0x9FA7C6;
    gui_mg_color = 0x475489;
    gui_bg_color = 0x192142;
    debugInit();
#endif

#ifdef VERBOSE
    char buffer[80] = "Init Success: ";
    time_t rawtime;
    time(&rawtime);
    strcat(buffer, ctime(&rawtime));
    buffer[strlen(buffer) - 1] = 0; //we don't want the newline here
    setError(buffer);
#endif

    return 1;
}

int escapeMenu()
{
    int escapeFlag = 0;
    updateKeys();
    //loop
    int invoTimer = 10;
    while (!closeFlag && !escapeFlag) {
        while (timer_4 > 0) {
            if ((keyPressed & KEYESC) && !escHack){
                closeFlag = 1;
                return 1; //close game
            }
            if ((keyPressed & KEYF1) && !escHack){
                return 0; //resume game
            }
            if ((keyPressed & KEYF2) && !escHack){
                return 1; //go to title
            }
            if ((keyPressed & KEYF3) && !escHack){
                optionsMenu(); //go to title
            }
            if (invoTimer > 0)
                invoTimer--;
            updateKeys();
            blackBuffer();
            Rect currentRect = {0,256,572,288};
            mainBlit(26, currentRect, 34, 224);
            updateScreen();
            frames++;
            timer_4--;
            if (timer_4 > 10) {
                setError("Can't keep up! (escMain)");
                timer_4 = 1;
                break;
            }
        }
        rest(1);
        while (timer_1 > 0) {
            FPS = frames;
            frames = 0;
            timer_1--;
        }
    }
    return 0;
}

int gameMain(Profile *prof)
{
    //initalize stuff
    player = NULL;
    if (prof) {
        player = new Player(prof);
        loadMap(prof->currentMap);
        playSong(prof->currentMusic);
    } else {
        player = new Player();
        clearFlags();
        loadMap(15);
        runEvent(200);
    }
    player->giveCamera(16);
    gameState = 2;
    timer_4 = 0;
    timer_1 = 0;
    int escapeFlag = 0;
    //loop
    while (!closeFlag && !escapeFlag) {
        while (timer_4 > 0) {
            escapeFlag = oneFrame();
            frames++;
            timer_4--;
            if (timer_4 > 10) {
                setError("Can't keep up! (gameMain)");
                timer_4 = 1;
                break;
            }
        }
        rest(1);
        while (timer_1 > 0) {
            FPS = frames;
            frames = 0;
            timer_1--;
        }
    }
    //delete what was initialized
    if (player)
        delete player;
    clearNpcList();
    player = NULL;
    runEvent(0);
    return 0;
}

int oneFrame()
{
    int escapeFlag = 0;
    updateKeys();

    if ((keyPressed & KEYESC) && !escHack){
        rest(1);
        return escapeMenu();//escape menu
    }

    updateCamera();
    scriptParser();
    if (!(gameState & 0x10)) {
        player->act(gameState & 2);
        updateAllNpc();
        updateAllBullet();
        updateAllEffect();
        updateAllNumObj();
    }


    if (timer_4 <= 2)
        drawAll();

    if ((gameState &2) && (keyPressed & KEYQ)) {
        player->selectingItems = false;
        gameState &= -3; //remove "Can control" state
        gameState |= 0x20; //add "In inventory" state
        player->runArmsScript();
        invoMain();
        gameState &= -0x21; //remove "in inventory" state
        gameState |= 2; //add "Can control" state
        runEvent(0);
    }

#ifdef EDITOR_MODE
    updateKeys_a();
    if (keyPressed & KEYU)
        do_dbg1();
    if (keyPressed & KEYI)
        mapEditLoop();
    if (keyPressed & KEYO)
        pxeLoop();
    if (escHack > 0)
        escHack--;
    checkTabs();
#endif
    return 0;
}

void drawAll()
{
    const fish = FALSE;
    if(is25FPS){
        switchFor25 ^= 1;
    }
    if(switchFor25){
        player->draw(gameState & 2);//this is only here since the player's frame counter is in its draw function
        return;
    }
    blackBuffer();
    renderBG();
    updateTileAnim();
    drawTiles(0);
    drawTiles(1);
    drawAllNpc();
    player->draw(gameState & 2);
    drawAllBullet();
    drawTiles(2);
    drawTiles(3);
    drawAllEffect();
    drawAllNumObj();
    player->renderHud();
    renderImgOverlay();
    renderFade();
    drawMNA();
    renderTextbox();
#ifdef EDITOR_MODE
    updateFramePos();
    drawDebugFrame();
    drawTabs();
#endif

    updateScreen();
}

void optionsMenu()
{
    updateKeys();
    int cursorPos = 0;
    int change = 0; //for changing things, will be -1,0, or 1
    int change2 = 0;
    //loop
    int invoTimer = 10;
    while (!closeFlag) {
        while (timer_4 > 0) {
            change = 0;
            change2 = 0;
            if (keyPressed & KEYDOWN){
                cursorPos++;
                playSound(SFX_menu_move);
            }
            else if (keyPressed & KEYUP){
                cursorPos--;
                playSound(SFX_menu_move);
            }
            else if (keyPressed & KEYRIGHT){
                change = 1;
            }
            else if (keyPressed & KEYLEFT){
                change = -1;
            }
            if(keyHeld & KEYRIGHT){
                change2 = 1;
            }
            else if(keyHeld & KEYLEFT){
                change2 = -1;
            }
            if ((keyPressed & KEYESC)||(keyPressed & KEYSHOOT)){
                return;
            }
            if(cursorPos<0){
                cursorPos = 5; //max number of options
            }
            else if(cursorPos>5){
                cursorPos = 0;
            }
            switch (cursorPos){
            case 0://Music volume
                setMusicVol(getMusicVol() + change2);
                if(change2&&(getMusicVol()!=100)&&(getMusicVol()!=0)){
                    playSound(SFX_fx_msg);
                }
                break;
            case 1://Mute music
                if(change){
                    playSound(SFX_menu_select);
                    toggleMusic();
                }
                break;
            case 2://SFX volume
                setSoundVol(getSoundVol() + change2);
                if(change2&&(getSoundVol()!=100)&&(getSoundVol()!=0)){
                    playSound(SFX_fx_msg);
                }
                break;
            case 3://SFX mute
                if(change){
                    toggleSound();
                    playSound(SFX_menu_select);
                }
                break;
            case 4://FPS
                if(change){
                    is25FPS ^= 1;
                    playSound(SFX_menu_select);
                }
                break;
            case 5://Done
                if (keyPressed & KEYJUMP){
                    playSound(SFX_menu_select);
                    return;
                }
                break;
            }
            if (invoTimer > 0)
                invoTimer--;
            drawOptionsMenu(cursorPos);
            updateKeys();
            frames++;
            timer_4--;
            if (timer_4 > 10) {
                setError("Can't keep up! (invoMain)");
                timer_4 = 1;
                break;
            }
            change = 0;
        }
        rest(1);
        while (timer_1 > 0) {
            FPS = frames;
            frames = 0;
            timer_1--;
        }
    }
}

void drawOptionsMenu(int cursorPos){
    blackBuffer();
    Rect frameRect = {0,0,488,16};
    //get xBase and yBase
    int xBase = 77;
    int yBase, i;
    yBase = 140;
    //render the upper box
    mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase);
    frameRect.up += 16;
    frameRect.down += 16;
    for (i = 1; i < 10; i++)
        mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + i*16);
    frameRect.up += 16;
    frameRect.down += 16;
    mainBlit(BMP_TEXTBOX, frameRect, xBase, yBase + 0xa0);
    //render the options text
    frameRect.left = 0;
    frameRect.right = 128;
    frameRect.up = 288;
    frameRect.down = 360;
    mainBlit(BMP_TEXTBOX, frameRect, 128,154);
    frameRect.left = 128;
    frameRect.right = 228;
    mainBlit(BMP_TEXTBOX, frameRect, 128, 226);
    //draw the Music & SFX volume numbers
    drawNumb2(260,158,getMusicVol(),0,3);
    drawNumb2(260,206,getSoundVol(),0,3);
    drawNumb2(244,254,(2-is25FPS)*25,0,2);
    //draw the Music & SFX volume bars
    frameRect.left = 304;
    frameRect.right = 508;
    frameRect.up = 176;
    frameRect.down = 192;
    mainBlit(BMP_TEXTBOX, frameRect, 320, 158);
    mainBlit(BMP_TEXTBOX, frameRect, 320, 206);
    frameRect.left = 304;
    frameRect.right = getMusicVol()*2+304;
    frameRect.up = 192;
    frameRect.down = 204;
    mainBlit(BMP_TEXTBOX, frameRect, 322, 160);
    frameRect.right = getSoundVol()*2+304;
    mainBlit(BMP_TEXTBOX, frameRect, 322, 208);
    //draw the Music & SFX Mute on/off
    frameRect.left = 480 + 28*isMusicMuted();
    frameRect.right = frameRect.left + 28;
    frameRect.up = 152;
    frameRect.down = 166;
    mainBlit(BMP_TEXTBOX, frameRect, 192,184);
    frameRect.left = 480 + 28*isSoundMuted();
    frameRect.right = frameRect.left + 28;
    mainBlit(BMP_TEXTBOX, frameRect, 192,232);
    //draw the cursor
    frameRect.left = 224;
    frameRect.right = 256;
    frameRect.up = 176;
    frameRect.down = 208;
    mainBlit(BMP_TEXTBOX, frameRect, 90, 150+cursorPos*24);
    updateScreen();
}

void invoMain()
{
    int escapeFlag = 0;
    //loop
    int invoTimer = 10;
    while (!closeFlag && !escapeFlag) {
        while (timer_4 > 0) {
            if ((keyPressed & KEYESC) && !escHack)
                escapeFlag = 1;
            if (invoTimer > 0)
                invoTimer--;
            else if (keyPressed & KEYQ)
                escapeFlag = 1;

            updateKeys();
            player->inventoryControl();
            scriptParser();
            invoDraw();
            frames++;
            timer_4--;
            if (timer_4 > 10) {
                setError("Can't keep up! (invoMain)");
                timer_4 = 1;
                break;
            }
        }
        rest(1);
        while (timer_1 > 0) {
            FPS = frames;
            frames = 0;
            timer_1--;
        }
    }
}

void invoDraw()
{
    clearBitmap(-1); //make buffer transparent
    //draw the inventory box
    renderInvoFrame();
    renderTextbox();
    player->renderInventory();

    updateScreen();
}

DWORD WINAPI titleMain(LPVOID lpParam)
{
    playSong(24);
    Profile *prof1 = new Profile(1);
    Profile *prof2 = new Profile(2);
    Profile *prof3 = new Profile(3);
    Profile *profArray[3] = {prof1, prof2, prof3};
    int menuState = 0;
    int cursorPos;
    int fileCursor;
    if (prof1->exists) {
        cursorPos = 1;
        fileCursor = 0;
    } else if (prof2->exists) {
        cursorPos = 1;
        fileCursor = 1;
    } else if (prof3->exists) {
        cursorPos = 1;
        fileCursor = 2;
    } else {
        cursorPos = 0;
        fileCursor = 0;
    }
    Rect titleRect = {0, 0, 640, 480};
    Rect hideRectBig = {148, 206, 308, 334};
    Rect hideRectSmall = {0, 0, 32, 32};
    Rect arrowRect = {448, 0, 480, 32};
    Rect boxRect = {480, 0, 640, 128};
    timer_4 = 0;
    timer_1 = 0;
    int escapeFlag = 0;
    while (!escapeFlag && !closeFlag) {
        while (timer_4 > 0) {
            updateKeys();
            blackBuffer();
            if (keyPressed & KEYESC)
                escapeMenu();
            mainBlit(0, titleRect, 0, 0); //render the whole thing
            mainBlit(0, hideRectBig, 480, 0); //clean up the corner
            mainBlit(0, hideRectSmall, 448, 0); //clean up the cursor too
            mainBlit(0, arrowRect, 0x10, 240+(cursorPos*0x28));
            switch (menuState) {
            case 0: { //base menu
                if ((keyPressed & KEYUP) || (keyPressed & KEYDOWN)) {
                    cursorPos ^= 1;
                    playSound(SFX_menu_move);
                }
                if (keyPressed & KEYJUMP) {
                    menuState = 1;
                    playSound(SFX_menu_select);
                    break;
                }
            }
            break;
            case 1: { //File select menu
                if (keyPressed & KEYUP) {
                    fileCursor--;
                    if (fileCursor < 0)
                        fileCursor = 2;
                    playSound(SFX_menu_move);
                }
                if (keyPressed & KEYDOWN) {
                    fileCursor++;
                    if (fileCursor > 2)
                        fileCursor = 0;
                    playSound(SFX_menu_move);
                }
                if (keyPressed & KEYSHOOT) {
                    menuState = 0;
                    playSound(SFX_menu_select);
                }
                if (keyPressed & KEYJUMP) {
                    setActiveProfileNum(fileCursor+1);
                    if ((cursorPos == 0) || (!profArray[fileCursor]->exists)) {
                        playSound(SFX_fx_teleport);
                        gameMain(NULL);
                    } else {
                        gameMain(profArray[fileCursor]);
                    }
                    if (closeFlag)
                        return 1;
                    //reload the profile array
                    delete profArray[0];
                    profArray[0] = new Profile(1);
                    delete profArray[1];
                    profArray[1] = new Profile(2);
                    delete profArray[2];
                    profArray[2] = new Profile(3);
                    //reload title bitmap
                    loadOverlayImage("Title");
                }
                mainBlit(0, boxRect, 146, 210); //render profiles box
                mainBlit(0, arrowRect, 154, 220 +(0x26 * fileCursor)); //render profiles cursor
                Rect textBox = {0, 0, 488, 32};
                mainBlit(26, textBox, 76, 16); //render top box
                textBox.up += 16;
                textBox.down += 16;
                mainBlit(26, textBox, 76, 48);

                //render all that file info
                if (profArray[fileCursor]->exists) {
                    char character = profArray[fileCursor]->flagArray[996];
                    char location = profArray[fileCursor]->flagArray[998];
                    int healthMax = profArray[fileCursor]->maxHealth;
                    int healthCurrent = profArray[fileCursor]->currentHealth;
                    Rect currentRect = {0, 32, 32, 64};
                    currentRect.up = (character << 6)+ 0x20;
                    currentRect.down = currentRect.up + 32;
                    //render character
                    mainBlit(BMP_MYCHAR, currentRect, 0x58, 0x1E);
                    //render character's hand
                    currentRect.left = 0;
                    currentRect.up = 0;
                    currentRect.right = 48;
                    currentRect.down = 32;
                    mainBlit(BMP_ARMS, currentRect, 78, 30);
                    //render location
                    currentRect.up = 0x120;
                    currentRect.down = currentRect.up + 0x20;
                    currentRect.left = location*0x20;
                    currentRect.right = currentRect.left + 0x20;
                    mainBlit(26, currentRect, 208, 0x20);
                    //render HP bar
                    currentRect.left = 48;
                    currentRect.right = 128;
                    currentRect.up = 80;
                    currentRect.down = 96;
                    mainBlit(26, currentRect, 122, 49);
                    currentRect.up -= 32;
                    currentRect.down -= 32;
                    currentRect.right = (healthCurrent*78)/healthMax;
                    currentRect.left = 0;
                    mainBlit(26, currentRect, 122, 49);
                    writeNum_r(168, 30, healthCurrent);
                    writeText("/", 168, 29);
                    writeNum_l(177, 30, healthMax);
                    currentRect.left = 112;
                    currentRect.up = 96;
                    currentRect.right = currentRect.left + 16;
                    currentRect.down = currentRect.up + 16;
                    mainBlit(26, currentRect, 124, 29);
                    //render weapon icons
                    int iconCount = 0;
                    for (int i = 0; i < 8; i++) {
                        Weapon *currentWep = &profArray[fileCursor]->weaponArray[i];
                        if (currentWep->ID) {
                            currentWep->renderIcon_large(245 + iconCount*30, 34);
                            iconCount++;
                        }
                    }
                } else { //render NO DATA
                    Rect nopeRect = {288, 160, 352, 192};
                    mainBlit(26, nopeRect, 288, 0x20);
                }
                break;
            }
            default:
                break;
            }// switch
            /*
                 #ifdef EDITOR_MODE
                 updateKeys_a();
                 checkTabs();
                 drawTabs();
                 #endif
               */
            updateScreen();
            timer_4--;
        }//while (timer)
        rest(1);
    }//while
    closeFlag = 1;
    return 0;
}


int main()
{
    initialize();
#ifdef EDITOR_MODE
    HANDLE threadHandle[NUMTAB];
    DWORD threadID[NUMTAB];
    DebugState *state[NUMTAB];
    loadMap(0);
    for (int i = 0; i < NUMTAB; i++) {
        threadHandle[i] = CreateThread(NULL, 0, titleMain, NULL, CREATE_SUSPENDED, &threadID[i]);
        state[i] = new DebugState();
        state[i]->getState();
    }
    extern int currentTab;
    int lastTab = 0;
    ResumeThread(threadHandle[0]);
    while (!closeFlag) {

        if (currentTab != lastTab) {
            SuspendThread(threadHandle[lastTab]);
            state[lastTab]->getState();
            state[currentTab]->setState();
            ResumeThread(threadHandle[currentTab]);
            lastTab = currentTab;
        }
        rest(1);
    }
    //allow the threads to close?
    for (int i = 0; i < NUMTAB; i++) {
        ResumeThread(threadHandle[currentTab]);
        rest(10);
    }
#else
    titleMain(0);
#endif
    //close stuff
    musicClose();
    destroyGraphics();

    char buffer[80] = "Execution finished: ";
    time_t rawtime;
    time(&rawtime);
    strcat(buffer, ctime(&rawtime));
    setError(buffer);

    allegro_exit();
    return 0;
}
END_OF_MAIN();


