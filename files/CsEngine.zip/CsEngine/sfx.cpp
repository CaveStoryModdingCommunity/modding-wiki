
#include <allegro.h>
#include <stdio.h>
#include "sfx.h"
#include "general.h"
#include "defines.h"

#include "SFX/sfxHeader.h"

//n+1 sounds

DATAFILE *soundData;
SAMPLE *sampleArray[SFX_COUNT] = {0};
int soundVolume = 100;
int soundMute = 0;
static unsigned char fxTable[0x76] = {
    SFX_fx_null, SFX_menu_move, SFX_fx_msg, SFX_fx_headbonk, SFX_fx_weapon_switch, SFX_menu_prompt, SFX_fx_jump_tiny, SFX_fx_null,
    SFX_fx_08, SFX_fx_null, SFX_fx_null, SFX_fx_door, SFX_fx_block_destroy, SFX_fx_null, SFX_fx_get_xp, SFX_fx_jump,
    SFX_fx_pc_hurt, SFX_fx_pc_die, SFX_menu_select, SFX_fx_null, SFX_fx_health_refill, SFX_fx_bubble, SFX_fx_chest_open, SFX_fx_thud,
    SFX_fx_pc_walk, SFX_fx_explode_funny, SFX_env_quake, SFX_fx_level_up, SFX_fx_shot_hit, SFX_fx_teleport, SFX_fx_crit_jump, SFX_fx_shot_ting,
    SFX_fx_pstar_l2, SFX_fx_fwoosh, SFX_fx_fireball, SFX_fx_explode1, SFX_fx_null, SFX_fx_gun_empty, SFX_fx_get_item, SFX_fx_enemy_fire,
    SFX_fx_stream1, SFX_fx_null, SFX_fx_get_missle, SFX_fx_computer_beep, SFX_fx_missle_hit, SFX_fx_xp_bounce, SFX_fx_ironh_shot, SFX_fx_explode2,
    SFX_fx_bubble2, SFX_fx_pstar_l3, SFX_fx_mimi_squeal, SFX_fx_enemy_hurt, SFX_fx_enemy_hurt_big, SFX_fx_enemy_hurt_small, SFX_fx_enemy_hurt_cool, SFX_fx_enemy_squeak,
    SFX_fx_splash, SFX_fx_enemy_damage, SFX_env_copter, SFX_fx_spur_charge0, SFX_fx_spur_charge1, SFX_fx_spur_charge2, SFX_fx_spur_fire_l2, SFX_fx_spur_fire_max,
    SFX_fx_spur_fire_max, SFX_fx_spur_charged, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_explode_small, SFX_fx_crash_little,
    SFX_fx_crash_big, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null,
    SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null,
    SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null,
    SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_null, SFX_fx_bubble_pop, SFX_fx_lightning, SFX_fx_jaws, SFX_fx_curly_charge,
    SFX_fx_hidden_hit, SFX_fx_bark, SFX_fx_blade, SFX_fx_block_move, SFX_fx_jump_big, SFX_fx_crit_fly, SFX_fx_crit_fly2, SFX_fx_6F,
    SFX_fx_70, SFX_fx_boost, SFX_fx_core_hurt, SFX_fx_core_thrust, SFX_fx_core_lazor, SFX_fx_nemesis
};

void loadSfx()
{
    packfile_password("fx_null");
    soundData = load_datafile("SFX/soundData3.dat");
    if (!soundData)
        fatalError("Failed to load sound effects");
    for (int i = 0; i < SFX_COUNT; i++)
        sampleArray[i] = (SAMPLE *) soundData[i].dat;
    packfile_password(NULL);
#ifdef VERBOSE
    printf("Loaded %d sound effects\n", SFX_COUNT);
#endif
}

void playSound(int sfxNum)
{
    if(soundMute)
        return;
    if ((sfxNum < SFX_COUNT) && (sfxNum >= 0)){
        stop_sample(sampleArray[sfxNum]);
        play_sample(sampleArray[sfxNum], (soundVolume*255/100), 127, 1000, 0);
    }
}

int convertFxNum(int old)
{
    return fxTable[old];
}

void stopSounds(){
    for (int i = 0; i < SFX_COUNT; i++)
        stop_sample(sampleArray[i]);
}

int getSoundVol(){
    return soundVolume;
}
void setSoundVol(int newVol){
    soundVolume = newVol;
    if (soundVolume > 100)
        soundVolume = 100;
    if (soundVolume < 0)
        soundVolume = 0;
    return;
}
void toggleSound(){
    soundMute ^= 1;
    return;
}
int isSoundMuted(){
    return soundMute;
}
