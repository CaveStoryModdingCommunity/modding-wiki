#pragma once
#ifndef SFX_H
#define SFX_H

#include "SFX/sfxHeader.h"
void loadSfx();
void unloadSfx();
void playSound(int soundNum);
int convertFxNum(int oldNum);
void stopSounds();
int getSoundVol();
void setSoundVol(int newVol);
void toggleSound();
int isSoundMuted();
#endif
