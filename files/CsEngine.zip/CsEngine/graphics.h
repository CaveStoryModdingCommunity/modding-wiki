#pragma once
#ifndef GRAPHICS_H
#define GRAPHICS_H


#include "rect.h"
#include "object.h"

void initializeGraphics(); //Load main graphic resources for game
void loadImgSlot(int slot, const char *filename, int format);

void loadTileset(const char *filename); //loads file to bitmap slot 6
void loadBG(const char *filename); //load file to bitmap slot 0
void loadNpcSets(const char *file1, const char *file2); //loads to slots 7, 8
void loadOverlayImage(const char *filename); //loads file to title bitmap slot
void renderBG(); //Update Background with current Background image and mode
void setBgMode(int mode);
void drawFade(int out, int fadeDirection, int fadeTimer);
int getBgMode();

void getCamera(int &x, int &y); //get camera position by ref.
bool isCamera(int *x, int *y);
void setCamera(int x, int y); //set absolute camera position
void setCamera(int *x, int *y, int speed); //set camera focus pointers
void setCamera(Object *obj, int speed); //assign an object to the camera
void updateCamera(); //update camera position
void setCamLimit(int tileX, int tileY); //set camera limit based on map size

void blackBuffer(); //makes the buffer  black
void clearBitmap(int bitmapNum); //Make the selected bitmap transparent.
void renderFPS(int x, int y, int ShowFPS); //Draw the number in the upper-left of the screen
void updateScreen(); //Display teh buffer to the screen
void destroyGraphics(); //Release memory allocated for graphics.

void mainBlit (int GfxNum, Rect &Rect, int Xpos, int Ypos); //blit w/ absolute pixels
void clipBlit (int gfxNum, Rect &srcRect, int xPos, int yPos, Rect &clipRect); //absolute blit w/ forced clipping
void screenBlit (int gfxNum, Rect &rect, int xPos, int yPos); //blit to screen directly
void cameraBlit (int gfxNum, Rect &rect, int xPos, int yPos); //blit w/ camera units
void clipCameraBlit (int gfxNum, Rect &srcRect, int xPos, int yPos, Rect &clipRect); //relative blit w/ relative clipping
void cameraBlit_scale (int gfxNum, Rect &rect, int xPos, int yPos, float scale);
void cameraBlit_trans_scale (int gfxNum, Rect &rect, int xPos, int yPos, int alpha, float scale); //deadly slow
void transBlit (int gfxNum, Rect &rect, int xPos, int yPos, int alpha); //translucent blit
void cameraBlit_trans(int gfxNum, Rect &rect, int xPos, int yPos, int alpha); //trans blit w/camera
void noMaskBlit (int gfxNum, Rect &rect, int xPos, int yPos); //blit w/ no mask colour

void drawCircle (int x, int y, int radius, int colour); //draw circle to buffer
void drawRectangle(int x, int y, int x2, int y2, int colour); //draws a solid rectangle

void fontCol(int colour); //set font colour;
void writeText (const char* String, int X, int Y); //Write white text to the screen at position
void writeTextTo(int bmpNum, const char *string, int x, int y); //write text to another memory bitmap
void writeNum_l(int x, int y, int num); //write numbers, left-align
void writeNum_r(int x, int y, int num); //write numbers, right-align
void writeText_al(const char* string, int x, int y); //use allegro font
void writeNum_l_al(int x, int y, int num);
void writeNum_r_al(int x, int y, int num);
void writeNum_l_al_hex(int x, int y, int num);
void drawNumb2(int x, int y, int lNum, int isNeg, int digits);

#ifdef EDITOR_MODE
void drawMapBounds(int grid); //draws solid lines to indicate the maximum map size
void drawMapCursor (Rect &rect);
int getTilesetHeight(); //returns # tiles
#endif

#define FONT_WIDTH 11
#define LINE_SPACING 32

#define NUMBITMAP 34
#define IMGTYPE_BMP 0
#define IMGTYPE_PNG 1
#define BMP_TITLE 0
#define BMP_IMG 0
#define BMP_PARTICLE 1
#define BMP_TILESET 2
#define BMP_DBG1 3
#define BMP_DBG2 4
#define BMP_DBG3 5
#define BMP_FADE 6
#define BMP_PXEBUF 7
#define BMP_ITEM 8
#define BMP_MAP 9
#define BMP_BUF2 10
#define BMP_ARMS 11
#define BMP_ARMSITEM 12
#define BMP_MNABUF 13
#define BMP_STAGEIMAGE 14
#define BMP_LOADING 15
#define BMP_MYCHAR 16
#define BMP_BULLET 17
#define BMP_FADEBUF 18
#define BMP_CARET 19
#define BMP_SYM 20
#define BMP_NPC1 21
#define BMP_NPC2 22
#define BMP_REGU 23
#define BMP_XXX 24
#define BMP_XXXX 25
#define BMP_TEXTBOX 26
#define BMP_FACE 27
#define BMP_BG 28
#define BMP_XXXXX 29
#define BMP_TEXT1 30
#define BMP_TEXT2 31
#define BMP_TEXT3 32
#define BMP_TEXT4 33

#endif
