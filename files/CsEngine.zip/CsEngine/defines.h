//defines.h
#define KEYLEFT 1
#define KEYRIGHT 4
#define KEYUP 2
#define KEYDOWN 8
#define KEYJUMP 0x10
#define KEYSHOOT 0x200
#define KEYESC 0x400
#define KEYF1 0x800
#define KEYF2 0x1000
#define KEYF3 0x2000

#define KEYA 0x1
#define KEYB 0x2
#define KEYC 0x4
#define KEYD 0X8
#define KEYE 0x10
#define KEYF 0x20
#define KEYG 0x40
#define KEYH 0x80
#define KEYI 0x100
#define KEYJ 0x200
#define KEYK 0x400
#define KEYL 0x800
#define KEYM 0x1000
#define KEYN 0x2000
#define KEYO 0x4000
#define KEYP 0x8000
#define KEYQ 0x10000
#define KEYR 0x20000
#define KEYS 0x40000
#define KEYT 0x80000
#define KEYU 0x100000
#define KEYV 0x200000
#define KEYW 0x400000
#define KEYX 0x800000
#define KEYY 0x1000000
#define KEYZ 0x2000000

#define KEY0 0x1
#define KEY1 0x2
#define KEY2 0x4
#define KEY3 0x8
#define KEY4 0x10
#define KEY5 0x20
#define KEY6 0x40
#define KEY7 0x80
#define KEY8 0x100
#define KEY9 0x200
#define KEYBKSP 0x400
#define KEYDEL 0x800
#define KEYMINUS 0x1000
#define KEYEQUALS 0x2000

#define LEFT 1
#define UP 2
#define RIGHT 4
#define DOWN 8
#define LEFT_REL 0x10
#define RIGHT_REL 0x40

#define SCREENW 0x28000
#define SCREENH 0x1E000
#define SCREENHALFW 0x14000
#define SCREENHALFH 0xF000
#define VISIBLE_TILES_X 20
#define VISIBLE_TILES_Y 15

#define FADE_DURATION 40

#define COL_TRANS 0xFF00FF
#define COL_BLACK 0x000020
#define COL_WHITE 0xFFFFFF

#define PI 3.14159

//#define EDITOR_MODE
#define VERBOSE
#define NUMTAB 6
#define DBG_DEFAULT 0
#define DBG_CHEAT 1
#define DBG_MAP 2
#define DBG_MAP_TYPE 4
#define DBG_PXE 8
#define DBG_TSC 0x10
#define MAX_REDO 20

#define SPEEDCAP_MACRO if (xVel < -vMax) xVel = -vMax; if (xVel > vMax) xVel = vMax; if (yVel < -vMax) yVel = -vMax; if (yVel > vMax) yVel = vMax;
