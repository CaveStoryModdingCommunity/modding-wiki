#pragma once
#ifndef PXEEDIT_H
#define PXEEDIT_H
/*pxe file format
byte 0-3 header "PXE"
byte 4-5 numEntities
byte 6-7 padding
for each entity:
short xPos (tile)
short yPos (tile)
short flagID
short eventNum
short entity type
short flags
12b per entity
*/

#include <vector>
#include <list>
#include <allegro.h>
#include "entity.h"

int entitySelector(int msg, DIALOG *d, int c);
int custom_list_proc(int msg, DIALOG *d, int c);
int pxe_save_button(int msg, DIALOG *d, int c);
char *categoryProc(int index, int *list_size);
char *subcatProc(int index, int *list_size);

void fillPxeList();
void renderEntityIcons();
void pxeLoop();
void pxeDraw();
void doPxeGuiLogic();
void pxe_mapInteract();
void addUndo_pxe();
void sendPxeMessage(int msg, int c);
int isSelected_pxe(int filePos);
void fillGuiInfo(const PxeEntry &entry);
void getGuiInfo(PxeEntry *entry);

void pxeInit();
void savePxe();
void drawEntryList();

class MouseList_pxe
{
public:
    std::list<PxeEntry*> entityList;
    int x, y, w, h;

    void draw();
    PxeEntry getEntry(int index);
};

class DebugEntity
{
public:
    Rect frameRect;
    char *name;

    DebugEntity();
    ~DebugEntity();
};

class EntitySubcat
{
public:
    char *name;
    std::vector<int> entityList;

    EntitySubcat();
    EntitySubcat(const char *name);
    EntitySubcat(const EntitySubcat &other);
    EntitySubcat& operator=(const EntitySubcat &other);
    ~EntitySubcat();
};

class EntityCategory
{
public:
    char *name;
    std::vector<EntitySubcat> subCats;

    EntityCategory(const char *name);
    EntityCategory();
    EntityCategory(const EntityCategory &other);
    EntityCategory& operator=(const EntityCategory &other);
    ~EntityCategory();
};
#endif
