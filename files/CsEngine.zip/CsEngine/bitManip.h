
void writeBits(char buf[], int value, int numBits, long pos);
int readBits(char buf[], int numBits, long pos);
