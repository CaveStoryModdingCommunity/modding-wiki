
#include "bullet.h"
#include "effect.h"
#include "sfx.h"
#include "player.h"
#include "general.h"
#include "map.h"
#include "tsc.h"
#include <list>
#include <cstring>

using namespace std;
list<Bullet> bulletList;

extern Player *player;

/**************************
   Global var declarations
**************************/

static BulletInfo bulletDatArray[NUMWEAPON*LEVELPERWEAPON] = {
//    hitRect,       dOffX,   dOffY,   flags,   hits, damage,  lifespan
//weapon 0 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 1 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 2 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 3 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//    hitRect,       dOffX,   dOffY,   flags,   hits, damage,  lifespan
//weapon 4 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 5 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 6 bullets
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 1,       1,       0,       1,    1,       32 },
    { {0, 0, 16, 16}, 4,       4,       0,       1,    1,       32 },

//weapon 7 bullets {bubbler}
    { {0x600, 0x600, 0x600, 0x600},   8,   8,   0x80,  1,    1, 40 },
    { {0x600, 0x600, 0x600, 0x600},   8,   8,   0x80,  1,    1, 60 },
    { {0x800, 0x800, 0x800, 0x800},   8,   8,   0x80,  1,    1, 32 },

//    hitRect,       dOffX,   dOffY,   flags,   hits, damage,  lifespan
};

void (Bullet::*bulletAction[NUMWEAPON*LEVELPERWEAPON]) () = {
    NULL, NULL, NULL,
    NULL, NULL, NULL,
    NULL, NULL, NULL,
    NULL, NULL, NULL,
    NULL, NULL, NULL,
    NULL, NULL, NULL,
    NULL, &Bullet::sixTwo, NULL,
    &Bullet::Bubbler1, &Bullet::Bubbler2, &Bullet::Bubbler3
};

/*************************
   Bullet class functions
*************************/
Bullet::Bullet()
{

}

Bullet::Bullet(int x, int y, int dir, int id)
{
    inUse = 0x80;
    collision = 0;
    gfxNum = BMP_BULLET;
    xPos = x;
    yPos = y;
    xVel = 0;
    yVel = 0;
    direction = dir;
    ID = id;
    BulletInfo &inf = bulletDatArray[id];
    flags = inf.flags;
    nHits = inf.hits;
    lifespan = inf.lifespan;
    memcpy(&hitRect, &inf.hitRect, sizeof(hitRect));
    displayOffsetX = inf.displayOffX;
    displayOffsetY = inf.displayOffY;
    damage = inf.damage;
    timeElapsed = 0;
    scriptState = 0;
    frameNum = 0;
    frameTimer = 0;

}

Bullet::~Bullet()
{
    inUse = 0;
}

void Bullet::draw()
{
    cameraBlit(gfxNum, frameRect, xPos - displayOffsetX*0x100, yPos - displayOffsetY*0x100);
}

/*****************************
   Bullet utility functions
*****************************/
void bulletInit()
{

}

void clearAllBullet()
{
    bulletList.clear();
}

void updateAllBullet()
{
    list<Bullet>::iterator bIt;

    for (bIt = bulletList.begin(); bIt != bulletList.end(); bIt++) {
        Bullet *tempBullet = &*bIt;
        tempBullet->timeElapsed++;
        if (tempBullet->timeElapsed > tempBullet->lifespan)
            tempBullet->inUse = 0;
		tempBullet->tileCollisions();
        (tempBullet->*bulletAction[tempBullet->ID])();
    }

    bulletList.remove_if(bulletExpired);
}

void drawAllBullet()
{
    list<Bullet>::iterator bIt;

    for (bIt = bulletList.begin(); bIt != bulletList.end(); bIt++) {
        Bullet *tempBullet = &*bIt;
        tempBullet->draw();
    }
}

void createBullet(int x, int y, int dir, int ID)
{
    bulletList.push_front(Bullet(x, y, dir, ID));
}

void checkBulletCollision(Entity &entity)
{
    list<Bullet>::iterator bIt;

    for (bIt = bulletList.begin(); bIt != bulletList.end(); bIt++) {
        Bullet &tempBullet = *bIt;

        if ( (tempBullet.xPos - tempBullet.hitRect.left < entity.xPos + entity.hitRect.right) &&
                (tempBullet.xPos + tempBullet.hitRect.right > entity.xPos - entity.hitRect.left) &&
                (tempBullet.yPos - tempBullet.hitRect.up < entity.yPos + entity.hitRect.down) &&
                (tempBullet.yPos + tempBullet.hitRect.down > entity.yPos - entity.hitRect.up) ) {
			if (entity.flags & 0x20) {
				//if entity is shootable
				entity.health -= tempBullet.damage;
				if (entity.health >= 1)	{
					if (entity.hitTimer < 14)
					{
						int effectX = (entity.xPos + tempBullet.xPos)/2;
						int effectY = (entity.yPos + tempBullet.yPos)/2;
						createEffect(effectX, effectY, 10, 0);
						createEffect(effectX, effectY, 10, 0);
						createEffect(effectX, effectY, 10, 0);
						playSound(convertFxNum(entity.hurtSound));
						entity.hitTimer = 16;
					}
					if (entity.flags & 0x8000)
						entity.damageTaken -= tempBullet.damage;
				} else {
					entity.health = 0;
					if (entity.flags & 0x8000)
						entity.damageTaken -= tempBullet.damage;
					if (player->stateFlags & 0x80 & entity.flags & 0x200)
						runEvent(entity.eventNum);
					else
						entity.inUse |= 0x8;
				}

			} else if (entity.flags & 0x4) {
				//else if entity is invincible
				int bulletID = tempBullet.ID;
				if (bulletID != 13
					&& bulletID != 14
					&& bulletID != 15
					&& bulletID != 28
					&& bulletID != 29
					&& bulletID != 30
					&& !(tempBullet.flags & 0x10)) {
					createEffect((entity.xPos + tempBullet.xPos)/2,(entity.yPos + tempBullet.yPos)/2, 2, 2);
					playSound(convertFxNum(31));
					tempBullet.nHits = 0;
					continue;
				}
			}
			tempBullet.nHits--;
		}
    }
    if (entity.inUse & 0x8)
		entity.kill();
}

bool bulletExpired(const Bullet &b)
{
    return ((b.inUse == 0) || (b.nHits <= 0));
}

int countBullets()
{
    return bulletList.size();
}

int countBulletsOfType(int type)
{
	int nBullet = 0;
	list<Bullet>::iterator bIt;
	for (bIt = bulletList.begin(); bIt != bulletList.end(); bIt++) {
		Bullet &currentBullet = *bIt;
		if (currentBullet.ID == type)
			nBullet++;
	}
	return nBullet;
}

void Bullet::tileCollisions()
{
    int startX = xPos >> 13;
    int startY = yPos >> 13;
    collision = 0;
    char xArray[4] = {0,1,0,1};
    char yArray[4] = {0,0,1,1};

    int tileX, tileY, tileType;
    for (int i = 0; i < 4; i++) {
        tileX = startX + xArray[i];
        tileY = startY + yArray[i];
        tileType = getType(tileX, tileY);

        switch (tileType) {
        case 0x44:
        case 0x4C:
            if (flags & 2)
                break;
        case 0x03:
        case 0x0B:
        case 0x04:
        case 0x0C:
        case 0x41:
        case 0x49:
        case 0x43:
        case 0x4B:
        case 0x61:
        case 0x69:
        case 0x63:
        case 0x6B:
        case 0x64:
        case 0x6C:
            if (!(flags & 8))
                tileSolid(tileX, tileY);
            break;
        case 0x50:
        case 0x58:
        case 0x51:
        case 0x59:
        case 0x52:
        case 0x5A:
        case 0x53:
        case 0x5B:
        case 0x54:
        case 0x5C:
        case 0x55:
        case 0x5D:
        case 0x56:
        case 0x5E:
        case 0x57:
        case 0x5F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        break;
        case 0x60:
        case 0x68:
            tileWater(tileX, tileY);
            break;
        case 0x70:
        case 0x78:
        case 0x71:
        case 0x79:
        case 0x72:
        case 0x7A:
        case 0x73:
        case 0x7B:
        case 0x74:
        case 0x7C:
        case 0x75:
        case 0x7D:
        case 0x76:
        case 0x7E:
        case 0x77:
        case 0x7F: {
            //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*, 0 = _
            char typeArray[8] = {1,2,4,5,4,5,1,2};
            tileType &= 7;
            if (tileType < 4)
                tileSlopeRoof(tileX, tileY, typeArray[tileType]);
            else //types: 1-2 = /, 3 = /45*, 4-5 = \, 6 = \45*,
                tileSlopeFloor(tileX, tileY, typeArray[tileType]);
        }
        tileWater(tileX, tileY);
        break;
        default:
            break;

        } //switch

    } //for each tile
    //delete[] xArray;
    //delete[] yArray;
}

/*******************************
   BULLET AI FUNCTIONS
*******************************/

void Bullet::sixTwo()
{
    frameRect.left = 20;
    frameRect.up = 116;
    frameRect.right = 22;
    frameRect.down = 118;
}

void Bullet::Bubbler1()
{
    if (collision & 0x2FF) {
        inUse = 0;
        createEffect(xPos, yPos, 2, 0);
    } else {
        if (!scriptState) {
            scriptState = 1;
            switch (direction) {
            case 0:
                xVel = -0x600;
                break;
            case 2:
                xVel = 0x600;
                break;
            case 1:
                yVel = -0x600;
                break;
            case 3:
                yVel = 0x600;
                break;
            default:
                break;
            }
        }
        switch (direction) {
        case 0:
            xVel += 42;
            break;
        case 2:
            xVel -= 42;
            break;
        case 1:
            yVel += 42;
            break;
        case 3:
            yVel -= 42;
            break;
        default:
            break;
        }
        xPos += xVel;
        yPos += yVel;
        if (timeElapsed > lifespan)
            createEffect(xPos, yPos, 14, 0);
        frameTimer++;
        if (frameTimer > 3) {
            frameTimer = 0;
            frameNum++;
            if (frameNum > 3)
                frameNum = 3;
        }
        frameRect.left = frameNum * 16;
        frameRect.up = 0;
        frameRect.down = frameRect.up + 16;
        frameRect.right = frameRect.left + 16;
    }
}

void Bullet::Bubbler2()
{
    int hitWall = 0;
    if (!scriptState) {
        scriptState = 1;
        switch (direction) {
        case 0:
            xVel = -0x600;
            yVel = random(-256, 256);
            break;
        case 2:
            xVel = 0x600;
            yVel = random(-256, 256);
            break;
        case 1:
            yVel = -0x600;
            xVel = random(-256, 256);
            break;
        case 3:
            yVel = 0x600;
            xVel = random(-256, 256);
            break;
        default:
            break;
        }
    }
    switch (direction) {
    case 0:
        xVel += 16;
        if (collision & 1)
            hitWall = true;
        break;
    case 2:
        xVel -= 16;
        if (collision & 4)
            hitWall = true;
        break;
    case 1:
        yVel += 16;
        if (collision & 2)
            hitWall = true;
        break;
    case 3:
        yVel -= 16;
        if (collision & 8)
            hitWall = true;
        break;
    default:
        break;
    }
    if (hitWall) {
        inUse = 0;
        createEffect(xPos, yPos, 2, 0);
    }
    xPos += xVel;
    yPos += yVel;
    if (timeElapsed > lifespan)
        createEffect(xPos, yPos, 15, 0);
    frameTimer++;
    if (frameTimer > 3) {
        frameTimer = 0;
        frameNum++;
        if (frameNum > 3)
            frameNum = 3;
    }
    frameRect.left = frameNum * 16;
    frameRect.up = 16;
    frameRect.down = frameRect.up + 16;
    frameRect.right = frameRect.left + 16;
}

void Bullet::Bubbler3()
{
    frameRect.left = 496;
    frameRect.up = 48;
    frameRect.down = frameRect.up + 16;
    frameRect.right = frameRect.left + 16;
}
