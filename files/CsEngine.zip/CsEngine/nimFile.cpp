
/*
 * Nim files structure:
 * Byte 0-3 "NIM1" identifier
 * Byte 4-5 flag information
 * Byte 6 Bits Per Pixel
 * Byte 7 Transparency bits (unused)
 * Byte 8-B img. width
 * Byte C-F img. height
 * Byte 10-13 number of events
 * Palette; Size is 2^BPP or 0 if BPP > 8
 * Event data; Size is (Number of events) * (BPP+8)... give or take.
 * 	There may be some padding 0's at the back for odd bit sizes
 */

#include <math.h>
#include <stdio.h>
#include <string.h>
#include "nimFile.h"
#include "bitManip.h"

int NimFile::getFileSize()
{
   int result = 0x14 + (1 << BPP) * 4;
	//read event data
	int eventPerBlock;
	if (8%BPP == 0)
		eventPerBlock = 8/BPP;
	else
		eventPerBlock = 8*BPP;
	//make a bit manipulator
	int bitsPerEvent = BPP + 8;
	int numBlock = (int) ceil(numEvents/ (double) eventPerBlock);
	result += (bitsPerEvent * eventPerBlock * numBlock)/8;
	return result;
}

NimFile::NimFile(const char* filename)
{
   FILE *theFile = fopen(filename, "rb");
   //read header
   char headerBuf[0x14];
   fread(&headerBuf, 1, 0x14, theFile);
   memcpy(&imgTag[0], &headerBuf[0], 4);
   memcpy(&flags, &headerBuf[4], 2);
   BPP = headerBuf[6];
   transBits = headerBuf[7];
   memcpy(&nimWidth, &headerBuf[8], 4);
   memcpy(&nimHeight, &headerBuf[0xC], 4);
   memcpy(&numEvents, &headerBuf[0x10], 4);
   //read palette
   int palSize;
   if (BPP <= 8)
      palSize = 2 << BPP;
   else
      palSize = 0;
   if (palSize)
   {
      char *palBuf = new char[palSize * 4];
      fread(palBuf, 1, (palSize * 4), theFile);
      //get each palette entry
      palette = new RGB[PAL_SIZE];
      for (int i = 0; i < palSize; i++)
      {
         int bufLoc = i*4;
         RGB theRGB = {palBuf[bufLoc], palBuf[bufLoc+1], palBuf[bufLoc+2]};
         palette[i] = theRGB;
      }
   } else {
      palette = NULL;
   }

   //read event data
   int eventPerBlock;
   if (8%BPP == 0)
      eventPerBlock = 8/BPP;
   else
      eventPerBlock = 8*BPP;
   // making bitmanipulator not required in C++ ^_^
   int bitsPerEvent = BPP + 8;
   int numBlock = (int) ceil(numEvents/(double) eventPerBlock);
   char *eventBuf = new char[numBlock*bitsPerEvent*eventPerBlock/8];
   fread(eventBuf, 1, sizeof(eventBuf), theFile);
   long pos = 0;
   //setup array of events
   eventData = new NimEvent[numEvents];
   for (int i = 0; i < numEvents; i++)
   {
      int eventCol = readBits(eventBuf, BPP, pos);
      int eventLen = readBits(eventBuf, 8, pos+BPP);
      eventData[i] = NimEvent(eventCol, eventLen);
      pos += bitsPerEvent;      
   }
   fclose(theFile);
}

NimFile::~NimFile()
{
}
