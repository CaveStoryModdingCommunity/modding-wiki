#pragma once
#ifndef PLAYER_H
#define PLAYER_H

#include "weapon.h"
#include "profile.h"
#include "graphics.h"
class Player: public PhysicalObject
{

public:
    int stateFlags;
    /*
       0x1   - Inspecting
       0x2   - Removed
       0x4   - Walking
       0x8   -
       0x10  -
       0x20  -
       0x40  -
       0x80  - InUse
       0x100 - inWater (?)
       0x200 -
       0x400 -
       0x800 -
       0x1000- Facing left
       0x2000- Facing up
       0x4000- Facing right
       0x8000- Facing down
    */
    //int collision; super
    /*
       0x1   ---- Solid left
       0x2   ---- Solid up
       0x4   ---- Solid right
       0x8   ---- Solid down
       0x10  ---- Slope Up Left
       0x20  ---- Slope Up Right
       0x40  ---- (Slope down left?)
       0x80  ---- (Slope down right?)
       0x100 ---- Water
       0x200 ---- unused?
       0x400 ---- Spike
       0x800 ---- (spike water?)
       0x1000   - Wind Left
       0x2000   - Wind up
       0x4000   - Wind right
       0x8000   - Wind down
       0x10000
       0x20000
       0x40000
       0x80000
    */
    int equipFlags;

    int currentHealth;
    int maxHealth;
    int invincTimer;
    int healthBarPos;
    int xpFlashTimer;

    int frameNum;
    unsigned int frameTimer;
    int charNum;
    //Rect hitRect; super

    int generateQmark;
    int worldMode;

	/* super
    int xVel;
    int yVel;
    */

    int camX;
    int camY;
    int focusOffsetX;
    int focusOffsetY;

    //inventory related
    Weapon weaponArray[8];
    int itemArray[32];
    char currentWeapon;
    char selectedItem;
    char invoFlash;
    char selectingItems;
    int expGained;

    //constructor
    Player();
    Player(Profile *prof);

    //render functions
    void draw(int canControl);
    void renderHud();
    void renderInventory();

    //input operations
    void act(int canControl);
    void agility(int canControl);
    void simpleAgility();
    void inventoryControl();
    void moveTo(int x, int y);
    void airManagement(); //breathe
    //player management operations
    void addWeaponExp(int amount);
    void removeWeaponExp(int amount);
    void addAmmo(int weapon, int amount);
    bool hasWeapon(int ID);
    void addHealth(int amount);
    void heal(int amount);
    void takeDamage(int amount);
    void addItem(int itemNum);
    void removeItem(int itemNum);
    bool hasItem(int itemNum);
    void addEquip(int flag);
    void removeEquip(int flag);
    bool checkEquip(int flag);
    //tile operations
    void tileCollisions();
    void tileSolid(int x, int y);
    void tileSlopeFloor(int x, int y, int type);
    void tileSlopeRoof(int x, int y, int type);
    void tileWater(int x, int y);
    void headBump();
    //misc operations
    void giveCamera(int speed);
    void runArmsScript();
};

#define HPBAR_PX 85
#define XPBAR_PX 70
#endif
