#pragma once
#ifndef OBJECT
#define OBJECT

#include "rect.h"
class Object
{
public:
    int xPos;
    int yPos;
    int gfxNum;
    Rect frameRect;
    Object();
    void draw();
};

class PhysicalObject: public Object
{
	public:
	int xVel;
	int yVel;
	Rect hitRect;
	unsigned int collision;

	void tileCollisions();
	void tileSolid(int x, int y);
	void tileWater(int x, int y);
    void tileSlopeFloor(int x, int y, int type);
    void tileSlopeRoof(int x, int y, int type);
};
#endif
