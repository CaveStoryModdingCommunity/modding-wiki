Installation instructions (two methods, pick one or the other):

1) As a standalone DLL:
   Rename layers.dll to dinput.dll and place next to Doukutsu.exe.

2) With Clownacy's mod loader:
   Place the 'layers' folder inside the 'mods' folder and then add "layers"
   (without quotes) to your mods.txt.


Source code:
https://github.com/periwinkle9/CSCustomDLLTemplate/tree/main/patches/sample_patches/layers
